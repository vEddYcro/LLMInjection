"""Reproduce aggregate MFLP analyses from the two supplied ZIP archives.

Usage: python analyze_mflp.py --responses responses.zip --private private.zip --out output
Requires Python 3.10+, numpy, pandas, scipy, matplotlib. No network access.
Private input bytes, assignment keys and case-level scored data are never exported.
"""
import argparse, csv, hashlib, io, itertools, json, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import norm

PROFILES = ['L0','L1','A_noE3','L2','A_noE2','L3','L4']
FAMILIES = ['D','I','R','T','X','F','B']
FAMILY_NAMES = dict(D='Direct injection',I='Indirect retrieved document',R='Poisoned RAG corpus',T='Malicious tool output',X='Exfiltration attempt',F='Failed or partial attack',B='Benign controls')
CLASSES = {p:set('E'+str(i) for i in range(int(p[-1])+1)) for p in ['L0','L1','L2','L3','L4']}
CLASSES.update(A_noE2={'E0','E1','E3'},A_noE3={'E0','E1','E2'})
SEED = 20260912
B = 2000

def split_ids(s):
    return [x.strip() for x in str(s).split(',') if x.strip()]

def lcs(a,b):
    d=[0]*(len(b)+1)
    for x in a:
        prev=d[:]
        for j,y in enumerate(b,1):
            d[j]=prev[j-1]+1 if x==y else max(prev[j],d[j-1])
    return d[-1]

def path_scores(r,s):
    assert len(s)==len(set(s)) and len(s)>0
    assert len(r)==len(set(r)), 'Repeated reported IDs require a frozen duplicate policy'
    m=len(set(r)&set(s)); rho=m/len(s); pi=m/len(r) if r else 0.
    k=lcs(r,s)/m if m else 0.
    prs=k*2*pi*rho/(pi+rho) if pi+rho else 0.
    return rho,pi,k,prs

def ratio(a,b):
    a,b=np.broadcast_arrays(np.asarray(a,dtype=float),np.asarray(b,dtype=float))
    return np.divide(a,b,out=np.full(a.shape,np.nan),where=b!=0)

def ci(v):
    v=np.asarray(v); v=v[np.isfinite(v)]
    return tuple(np.quantile(v,[.025,.975])) if len(v) else (np.nan,np.nan)

def wilson(k,n):
    if not n:return (np.nan,np.nan)
    z=norm.ppf(.975);p=k/n;d=1+z*z/n
    h=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    c=(p+z*z/(2*n))/d
    return c-h,c+h

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--responses',required=True);ap.add_argument('--private',required=True);ap.add_argument('--out',required=True)
    args=ap.parse_args();out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    zr=zipfile.ZipFile(args.responses);zt=zipfile.ZipFile(args.private)
    rr=[]
    for n in sorted(zr.namelist()):
        if n.endswith('.csv'):
            f=pd.read_csv(io.BytesIO(zr.read(n)),keep_default_na=False)
            f['investigator']=Path(n).stem[-2:];rr.append(f)
    raw=pd.concat(rr,ignore_index=True)
    assignment=pd.read_csv(io.BytesIO(zt.read('runtime/study_team_private/assignment_opaque_map.csv')))
    assert len(raw)==len(assignment)==1176
    assert not raw.duplicated(['investigator','opaque_case_token']).any()
    d=raw.merge(assignment,on=['investigator','opaque_case_token'],how='outer',validate='one_to_one',indicator=True)
    assert d._merge.eq('both').all()
    truth={Path(n).stem:json.loads(zt.read(n)) for n in zt.namelist() if '/ground_truth_private/' in n and n.endswith('.json')}
    canonical={Path(n).stem:[json.loads(x) for x in zt.read(n).decode().splitlines() if x.strip()] for n in zt.namelist() if '/canonical/' in n and n.endswith('.jsonl')}
    cases=sorted(truth); assert len(cases)==168
    assert set(cases)==set(d.case_id)
    for columns in [['case_id','profile'],['case_id','investigator']]:
        assert d.groupby(columns).size().eq(1).all()
    assert d.groupby('profile').size().eq(168).all()
    assert d.groupby('investigator').size().eq(168).all()
    derived=[]
    for q in d.itertuples():
        t=truth[q.case_id];r=split_ids(q.ordered_event_ids);s=t['ordered_ground_truth_steps']
        rho,pi,k,prs=path_scores(r,s)
        ev={x['event_id'] for x in canonical[q.case_id] if x['_class'] in CLASSES[q.profile]};support=split_ids(q.supporting_event_ids)
        mal=bool(t['malicious']);elig=mal and bool(t['injection_delivered'])
        pred=q.incident_class=='malicious';dec=q.incident_class!='indeterminate'
        correct=(q.incident_class==('malicious' if mal else 'benign'))
        ch=q.injection_channel==t['injection_source']['channel']
        obj=q.injection_object_id==t['injection_source']['object_id']
        derived.append(dict(family=t['family'],malicious=mal,eligible=elig,predicted=pred,decisive=dec,correct=correct,
            tp=pred and mal,fp=pred and not mal,tn=q.incident_class=='benign' and not mal,
            exact=ch and obj,exact_protocol=ch and (obj or not mal),channel_only=ch and not obj and mal,
            source_unknown=q.injection_channel=='unknown' or q.injection_object_id=='unknown',
            object_only=obj,channel_correct=ch,coverage=rho,path_precision=pi,order_factor=k,prs=prs,
            path_n=len(r),matched_n=len(set(r)&set(s)),support_n=len(support),support_valid=sum(x in ev for x in support),
            support_any_valid=bool(set(support)&ev),support_all_valid=bool(support) and all(x in ev for x in support),
            elapsed_seconds=(pd.Timestamp(q.submit_time_utc)-pd.Timestamp(q.start_time_utc)).total_seconds()))
    d=pd.concat([d.reset_index(drop=True),pd.DataFrame(derived)],axis=1)
    assert d.groupby(['family','investigator','profile']).size().eq(d.groupby(['family','investigator','profile']).size().index.get_level_values('family').map(lambda f:6 if f=='B' else 3)).all()
    assert d.confidence_0_100.between(0,100).all()
    rng=np.random.default_rng(SEED)
    weights=rng.multinomial(len(cases),np.ones(len(cases))/len(cases),size=B)
    all_weights=np.vstack([np.ones(len(cases)),weights])
    metrics={
      'precision':('tp','predicted'),
      'recall_decided':('tp','malicious_decided'),
      'recall_all_malicious':('tp','malicious'),
      'specificity_all_benign':('tn','benign'),
      'false_positive_rate':('fp','benign'),
      'classification_accuracy':('correct','one'),
      'binary_accuracy_protocol':('correct_binary','one'),
      'specificity_protocol':('tn_binary','benign'),
      'f1_protocol':('twotp','f1_denominator'),
      'decision_rate':('decisive','one'),
      'exact_attribution_protocol_all':('exact_protocol','one'),
      'exact_attribution_delivered':('exact_eligible','eligible'),
      'exact_attribution_all_malicious':('exact_malicious','malicious'),
      'object_only_delivered':('object_eligible','eligible'),
      'channel_attribution_delivered':('channel_eligible','eligible'),
      'channel_only_delivered':('channel_only_eligible','eligible'),
      'source_unknown_rate':('source_unknown','one'),
      'path_coverage_all':('coverage','one'),
      'prs_all':('prs','one'),
      'path_coverage_malicious':('coverage_malicious','malicious'),
      'prs_malicious':('prs_malicious','malicious'),
      'path_precision_macro':('path_precision','one'),
      'order_consistency_macro':('order_factor','one'),
      'unsupported_path_fraction_macro':('unsupported_macro','one'),
      'unsupported_path_fraction_micro':('unsupported_n','path_n'),
      'support_valid_fraction_micro':('support_valid','support_n'),
      'response_grounding_proxy':('support_any_valid','one'),
      'support_all_valid_rate':('support_all_valid','one')}
    d['one']=1;d['benign']=~d.malicious;d['malicious_decided']=d.malicious&d.decisive
    d['tn_binary']=~d.predicted&~d.malicious;d['fn_binary']=~d.predicted&d.malicious
    d['correct_binary']=d.predicted.eq(d.malicious);d['twotp']=2*d.tp.astype(int)
    d['f1_denominator']=d.twotp+d.fp.astype(int)+d.fn_binary.astype(int)
    d['channel_only_eligible']=d.channel_only&d.eligible
    d['unsupported_macro']=1-d.path_precision
    for new,a,b in [('exact_eligible','exact','eligible'),('exact_malicious','exact','malicious'),('object_eligible','object_only','eligible'),('channel_eligible','channel_correct','eligible'),('coverage_malicious','coverage','malicious'),('prs_malicious','prs','malicious')]:d[new]=d[a]*d[b]
    d['unsupported_n']=d.path_n-d.matched_n
    results=[];boots={}
    def metric_rows(g,label,ww):
        for name,(num,den) in metrics.items():
            a=g[num].to_numpy(float);b=g[den].to_numpy(float)
            vals=ratio(ww@a,ww@b);lo,hi=ci(vals[1:]);count=b.sum()
            wlo,whi=wilson(a.sum(),count) if np.isin(a,[0,1]).all() and np.isin(b,[0,1]).all() else (np.nan,np.nan)
            results.append(dict(**label,metric=name,estimate=vals[0],ci_low=lo,ci_high=hi,numerator=a.sum(),denominator=count,
                                valid_bootstrap_replicates=np.isfinite(vals[1:]).sum(),wilson_low=wlo,wilson_high=whi))
            if label['scope']=='profile':boots[(label['profile'],name)]=vals
        tp=ww@g.tp.to_numpy(float);tn=ww@g.tn_binary.to_numpy(float);fp=ww@g.fp.to_numpy(float);fn=ww@g.fn_binary.to_numpy(float)
        v=ratio(tp*tn-fp*fn,np.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)));lo,hi=ci(v[1:])
        results.append(dict(**label,metric='mcc_protocol',estimate=v[0],ci_low=lo,ci_high=hi,numerator=np.nan,denominator=len(g),valid_bootstrap_replicates=np.isfinite(v[1:]).sum(),wilson_low=np.nan,wilson_high=np.nan))
    for p in PROFILES:
        g=d[d.profile.eq(p)].set_index('case_id').loc[cases]
        metric_rows(g,dict(scope='profile',profile=p,family='ALL'),all_weights)
    for f in FAMILIES:
        ids=[c for c in cases if truth[c]['family']==f];w=rng.multinomial(len(ids),np.ones(len(ids))/len(ids),size=B)
        ww=np.vstack([np.ones(len(ids)),w])
        for p in PROFILES:
            g=d[d.profile.eq(p)].set_index('case_id').loc[ids]
            metric_rows(g,dict(scope='family',profile=p,family=f),ww)
    pd.DataFrame(results).to_csv(out/'performance_intervals.csv',index=False)
    counts=d.groupby(['profile','family','incident_class']).size().unstack(fill_value=0).reset_index()
    counts.to_csv(out/'classification_counts.csv',index=False)
    contrasts=[('E2 without E3','A_noE3','L1'),('E3 without E2','A_noE2','L1'),('E3 with E2','L3','L2'),('E2 with E3','L3','A_noE2'),('E4 beyond L3','L4','L3'),('Equivalent evidence arms','A_noE3','L2')]
    con=[]
    for label,p,q in contrasts:
        for m in ['precision','recall_decided','recall_all_malicious','exact_attribution_delivered','path_coverage_all','prs_all']:
            v=boots[(p,m)]-boots[(q,m)];lo,hi=ci(v[1:]);con.append(dict(contrast=label,profile_plus=p,profile_minus=q,metric=m,estimate=v[0],ci_low=lo,ci_high=hi))
    pd.DataFrame(con).to_csv(out/'paired_contrasts.csv',index=False)
    family_con=[]
    for name,fams,p,q in [('H1 direct',['D'],'L1','L0'),('H2a retrieval',['I','R'],'L2','L1'),('H2b tool',['T'],'L3','L2'),('H3 exfiltration',['X'],'L4','L3')]:
        ids=[c for c in cases if truth[c]['family'] in fams];w=rng.multinomial(len(ids),np.ones(len(ids))/len(ids),size=B);ww=np.vstack([np.ones(len(ids)),w])
        for m in ['recall_all_malicious','exact_attribution_delivered','channel_attribution_delivered','path_coverage_all','prs_all']:
            num,den=metrics[m];v=[]
            for pp in [p,q]:
                g=d[d.profile.eq(pp)].set_index('case_id').loc[ids];v.append(ratio(ww@g[num].to_numpy(float),ww@g[den].to_numpy(float)))
            v=v[0]-v[1];lo,hi=ci(v[1:]);family_con.append(dict(contrast=name,families=','.join(fams),profile_plus=p,profile_minus=q,metric=m,estimate=v[0],ci_low=lo,ci_high=hi,n_cases=len(ids)))
    pd.DataFrame(family_con).to_csv(out/'family_contrasts.csv',index=False)
    gates=[]
    for p in PROFILES:
        for m in ['exact_attribution_delivered','path_coverage_all','recall_decided']:
            v=boots[(p,m)];diff=boots[('L4',m)]-v
            lower=float(np.quantile(v[1:],.05));upper=float(np.quantile(diff[1:],.95))
            gates.append(dict(profile=p,metric=m,estimate=v[0],adequacy_lower95=lower,reference_minus_profile=diff[0],difference_upper95=upper,
                              passes_floor=lower>=.9,passes_ni_bound=upper<.1,bootstrap_tail_diagnostic=(1+sum(diff[1:]>=.1))/(B+1)))
    gates=pd.DataFrame(gates);order=np.argsort(gates.bootstrap_tail_diagnostic.to_numpy());adj=np.empty(len(gates));adj[order]=np.minimum(1,np.maximum.accumulate((len(gates)-np.arange(len(gates)))*gates.bootstrap_tail_diagnostic.to_numpy()[order]))
    gates['holm_adjusted_tail_diagnostic']=adj;gates.to_csv(out/'selection_rule_reconstruction.csv',index=False)
    # Nominal agreement: observations on the same case but different evidence conditions.
    agreement=[];pairwise=[]
    def agreements(matrix,ww,label):
        cats=sorted(set(matrix.ravel()));nrat=matrix.shape[1]
        cnt=np.column_stack([(matrix==c).sum(axis=1) for c in cats]).astype(float)
        po=ww@((cnt*(cnt-1)).sum(axis=1)/(nrat*(nrat-1)))/ww.sum(axis=1)
        totals=ww@cnt;N=totals.sum(axis=1);pe=(totals/N[:,None])**2;pe=pe.sum(axis=1)
        fl=ratio(po-pe,1-pe);de=ratio(N*N-(totals*totals).sum(axis=1),N*(N-1));alpha=1-ratio(1-po,de)
        for metric,v in [('pairwise_agreement',po),('fleiss_kappa',fl),('krippendorff_alpha_nominal',alpha)]:
            lo,hi=ci(v[1:]);agreement.append(dict(**label,metric=metric,estimate=v[0],ci_low=lo,ci_high=hi,n_cases=matrix.shape[0],n_ratings_per_case=nrat))
    for field in ['incident_class','injection_channel','tool_action','external_effect']:
        mat=d.pivot(index='case_id',columns='investigator',values=field).loc[cases]
        agreements(mat.to_numpy(),all_weights,dict(scope='all_profiles',field=field,family='ALL'))
        if field=='incident_class':
            for f in FAMILIES:
                ids=[c for c in cases if truth[c]['family']==f];w=rng.multinomial(len(ids),np.ones(len(ids))/len(ids),size=B)
                agreements(mat.loc[ids].to_numpy(),np.vstack([np.ones(len(ids)),w]),dict(scope='family_all_profiles',field=field,family=f))
            m=d[d.profile.ne('L0')].pivot(index='case_id',columns='profile',values=field).loc[cases]
            agreements(m.to_numpy(),all_weights,dict(scope='excluding_L0',field=field,family='ALL'))
            for axis in ['investigator','profile']:
                m=d.pivot(index='case_id',columns=axis,values=field).loc[cases]
                for a,b in itertools.combinations(m.columns,2):
                    x=m[a].to_numpy();y=m[b].to_numpy();cats=sorted(set(x)|set(y));ww=all_weights
                    po=ww@(x==y)/len(cases);pe=sum((ww@(x==c)/len(cases))*(ww@(y==c)/len(cases)) for c in cats)
                    kap=ratio(po-pe,1-pe)
                    for metric,v in [('agreement',po),('cohen_kappa',kap)]:
                        lo,hi=ci(v[1:]);pairwise.append(dict(axis=axis,left=a,right=b,metric=metric,estimate=v[0],ci_low=lo,ci_high=hi,n_cases=len(cases)))
    pd.DataFrame(agreement).to_csv(out/'agreement_intervals.csv',index=False)
    pd.DataFrame(pairwise).to_csv(out/'pairwise_agreement_intervals.csv',index=False)
    icc=[]
    for axis in ['investigator','profile']:
        x=d.pivot(index='case_id',columns=axis,values='prs').loc[cases].to_numpy(float);n,k=x.shape;w=all_weights
        row=x.mean(axis=1);col=w@x/n;grand=(w@row)/n
        msr=k*((w@(row*row))-n*grand*grand)/(n-1)
        msc=n*((col-grand[:,None])**2).sum(axis=1)/(k-1)
        sst=w@(x*x).sum(axis=1)-n*k*grand*grand
        mse=(sst-(n-1)*msr-(k-1)*msc)/((n-1)*(k-1))
        for name,v in [('ICC_A1_absolute',ratio(msr-mse,msr+(k-1)*mse+k*(msc-mse)/n)),('ICC_C1_consistency',ratio(msr-mse,msr+(k-1)*mse))]:
            lo,hi=ci(v[1:]);icc.append(dict(axis=axis,metric=name,estimate=v[0],ci_low=lo,ci_high=hi,n_cases=n,n_columns=k))
    pd.DataFrame(icc).to_csv(out/'prs_icc_intervals.csv',index=False)
    # Calibration interpretations are analysis assumptions, not a recovered handbook definition.
    calibration=[];bins=[]
    def calibrate(g,ww,label,mode,nbins=10):
        if mode!='correctness_all':g=g[g.decisive]
        inds=np.array([cases.index(c) for c in g.case_id]);w=ww[:,inds];total=w.sum(axis=1)
        c=g.confidence_0_100.to_numpy(float)/100;y=g.correct.to_numpy(float);prob=c.copy()
        if mode=='malicious_decided':prob=np.where(g.predicted,c,1-c);y=g.malicious.to_numpy(float)
        bs=ratio(w@((prob-y)**2),total);meanp=ratio(w@prob,total);meany=ratio(w@y,total)
        rel=np.zeros(len(w));res=rel.copy();ece=rel.copy();binned_bs=rel.copy()
        bid=np.minimum((prob*nbins).astype(int),nbins-1) if nbins else np.searchsorted(np.unique(prob),prob)
        nlevels=nbins if nbins else len(np.unique(prob))
        for k in range(nlevels):
            idx=bid==k
            if not idx.any():continue
            count=w[:,idx].sum(axis=1);fp=ratio(w[:,idx]@prob[idx],count);oy=ratio(w[:,idx]@y[idx],count);frac=ratio(count,total)
            rel+=np.nan_to_num(frac*(fp-oy)**2);res+=np.nan_to_num(frac*(oy-meany)**2);ece+=np.nan_to_num(frac*np.abs(fp-oy))
            binned_bs+=np.nan_to_num(frac*(oy*(1-fp)**2+(1-oy)*fp**2))
            if nbins==10:
                lo,hi=ci(oy[1:]);bins.append(dict(**label,interpretation=mode,bin=k,lower=k/10,upper=(k+1)/10,n=int(count[0]),mean_confidence=fp[0],observed_frequency=oy[0],frequency_ci_low=lo,frequency_ci_high=hi))
        unc=meany*(1-meany);residual=bs-(rel-res+unc)
        assert np.nanmax(np.abs(binned_bs-(rel-res+unc)))<1e-12
        if nbins==0:assert np.nanmax(np.abs(residual))<1e-12
        for metric,v in [('brier',bs),('reliability',rel),('resolution',res),('uncertainty',unc),('ece',ece),('decomposition_residual',residual),('mean_confidence',meanp),('observed_frequency',meany)]:
            lo,hi=ci(v[1:]);calibration.append(dict(**label,interpretation=mode,bin_count=nbins,metric=metric,estimate=v[0],ci_low=lo,ci_high=hi,n=int(total[0])))
    for mode in ['correctness_decided','correctness_all','malicious_decided']:
        for p in ['ALL']+PROFILES:
            calibrate(d if p=='ALL' else d[d.profile.eq(p)],all_weights,dict(scope='profile',group=p),mode)
        for inv in sorted(d.investigator.unique()):calibrate(d[d.investigator.eq(inv)],all_weights,dict(scope='investigator',group=inv),mode)
        for nbin in [5,20,0]:calibrate(d,all_weights,dict(scope='profile',group='ALL'),mode,nbin)
    pd.DataFrame(calibration).to_csv(out/'calibration_intervals.csv',index=False);pd.DataFrame(bins).to_csv(out/'calibration_bins.csv',index=False)
    audit=[]
    for inv,g in d.groupby('investigator'):
        audit.append(dict(investigator=inv,n=len(g),malicious_responses=sum(g.incident_class.eq('malicious')),benign_responses=sum(g.incident_class.eq('benign')),indeterminate_responses=sum(g.incident_class.eq('indeterminate')),mean_confidence=g.confidence_0_100.mean(),elapsed_seconds_unique=','.join(str(x) for x in sorted(g.elapsed_seconds.unique()))))
    pd.DataFrame(audit).to_csv(out/'response_audit.csv',index=False)
    pd.DataFrame([dict(family=f,family_name=FAMILY_NAMES[f],n_cases=sum(t['family']==f for t in truth.values()),injection_delivered=sum(t['family']==f and t['injection_delivered'] for t in truth.values()),attack_success=sum(t['family']==f and t['attack_success'] for t in truth.values())) for f in FAMILIES]).to_csv(out/'family_inventory.csv',index=False)
    checks={'n_responses':len(d),'n_cases':len(cases),'n_profiles':7,'n_investigators':7,'all_joins_one_to_one':True,'profile_case_and_investigator_case_unique':True,'factorial_balance':True,'seed':SEED,'bootstrap_replicates':B,'elapsed_time_invalid_or_constant':True,'duplicate_reported_path_ids':0,'empty_reported_paths':int(d.path_n.eq(0).sum()),'support_valid':int(d.support_valid.sum()),'support_total':int(d.support_n.sum()),'exact_delivered_denominator':int(d[d.profile.eq('L4')].eligible.sum()),'input_sha256':{Path(p).name:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in [args.responses,args.private]},'software':{'numpy':np.__version__,'pandas':pd.__version__}}
    (out/'validation.json').write_text(json.dumps(checks,indent=2))
    # Small, meaningful mathematical checks for scoring and bootstrap implementation.
    s=['a','b','c','d'];expected=[1,8/9,.8,2/3,.5]
    for n,e in zip([0,1,2,4,8],expected):assert np.isclose(path_scores(s+[f'x{i}' for i in range(n)],s)[3],e)
    assert path_scores(s[::-1],s)[3]==.25 and path_scores([],s)[3]==0
    assert np.all(weights.sum(axis=1)==168)
    assert all(np.isclose(gates[gates.profile.eq('L4')].reference_minus_profile,0))
    # Plots contain aggregate data only.
    import matplotlib;matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    res=pd.DataFrame(results)
    fig,ax=plt.subplots(figsize=(8,4))
    for m,label,offset,color in [('path_coverage_all','Coverage',-.18,'#486a89'),('prs_all','PRS',0,'#a34f37'),('exact_attribution_delivered','Exact attribution',.18,'#638052')]:
        a=res[(res.scope=='profile')&(res.metric==m)].set_index('profile').loc[PROFILES]
        xx=np.arange(7)+offset;ax.errorbar(xx,a.estimate,yerr=[a.estimate-a.ci_low,a.ci_high-a.estimate],fmt='o',capsize=3,label=label,color=color)
    ax.set_xticks(range(7),PROFILES);ax.set_ylim(-.03,1);ax.set_ylabel('Score with 95% case bootstrap interval');ax.legend(ncol=3,frameon=False,loc='upper left');fig.tight_layout();fig.savefig(out/'performance.png',dpi=200);plt.close(fig)
    bb=pd.DataFrame(bins);fig,axes=plt.subplots(1,2,figsize=(8,3.6))
    for ax,p in zip(axes,['ALL','L4']):
        a=bb[(bb.scope=='profile')&(bb.group==p)&(bb.interpretation=='correctness_decided')]
        ax.plot([0,1],[0,1],'--',color='gray');ax.scatter(a.mean_confidence,a.observed_frequency,s=20+1.5*a.n,alpha=.65,color='#486a89')
        ax.set(xlim=(-.03,1.03),ylim=(-.03,1.03),xlabel='Mean stated confidence',ylabel='Classification correctness',title=f'{p} decisive responses')
    fig.tight_layout();fig.savefig(out/'calibration.png',dpi=200);plt.close(fig)
    print(json.dumps(checks,indent=2))
    print(res[res.scope.eq('profile') & res.metric.isin(['recall_decided','exact_attribution_delivered','path_coverage_all','prs_all'])][['profile','metric','estimate','ci_low','ci_high']].to_string(index=False))

if __name__=='__main__':main()
