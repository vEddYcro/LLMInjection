from pathlib import Path
import json, math
import pandas as pd
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'analysis_results'
OUT=ROOT/'deliverables';OUT.mkdir(exist_ok=True)
P=['L0','L1','A_noE3','L2','A_noE2','L3','L4']
F=['D','I','R','T','X','F','B']
perf=pd.read_csv(DATA/'performance_intervals.csv')
cal=pd.read_csv(DATA/'calibration_intervals.csv')
con=pd.read_csv(DATA/'paired_contrasts.csv')
ag=pd.read_csv(DATA/'agreement_intervals.csv')
pw=pd.read_csv(DATA/'pairwise_agreement_intervals.csv')
icc=pd.read_csv(DATA/'prs_icc_intervals.csv')
gate=pd.read_csv(DATA/'selection_rule_reconstruction.csv')
fc=pd.read_csv(DATA/'family_contrasts.csv')

def val(x,d=3):return '—' if pd.isna(x) else f'{x:.{d}f}'
def interval(r,d=3):return '—' if pd.isna(r['estimate']) else f'{r["estimate"]:.{d}f}\n[{r["ci_low"]:.{d}f}, {r["ci_high"]:.{d}f}]'
def get(p,m,f='ALL'):
    return perf[(perf.profile==p)&(perf.metric==m)&(perf.family==f)].iloc[0]
def cg(p,m,mode='correctness_decided',bins=10):
    return cal[(cal.scope=='profile')&(cal.group==p)&(cal.metric==m)&(cal.interpretation==mode)&(cal.bin_count==bins)].iloc[0]

d=Document();sec=d.sections[0]
sec.page_width=Inches(8.5);sec.page_height=Inches(11)
sec.top_margin=sec.bottom_margin=Inches(.65);sec.left_margin=sec.right_margin=Inches(.65)
sec.header_distance=sec.footer_distance=Inches(.25)
for style in ['Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3']:
    d.styles[style].font.name='Calibri';d.styles[style].font.color.rgb=RGBColor(0,0,0)
for border in d.styles.element.xpath('.//w:pBdr'):
    border.getparent().remove(border)
d.styles['Normal'].font.size=Pt(10.5)
d.styles['Normal'].paragraph_format.space_after=Pt(7)
d.styles['Normal'].paragraph_format.line_spacing=1.08
d.styles['Title'].font.size=Pt(24)
d.styles['Heading 1'].font.size=Pt(17)
d.styles['Heading 2'].font.size=Pt(12)
head=sec.header.paragraphs[0];head.text='MFLP  |  Statistical supplement  |  12 September 2026';head.runs[0].font.size=Pt(8)
foot=sec.footer.paragraphs[0];foot.alignment=WD_ALIGN_PARAGRAPH.RIGHT
foot.add_run('Statistical supplement  •  ')
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');foot._p.append(fld)
for r in foot.runs:r.font.size=Pt(8)

def para(text,style=None):return d.add_paragraph(text,style)
def heading(text):d.add_heading(text,1)
def page(title):
    p=d.add_heading(title,1);p.paragraph_format.page_break_before=True
def table(headers,rows,widths=None,size=9):
    t=d.add_table(rows=1,cols=len(headers));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
    widths=widths or [7.2/len(headers)]*len(headers)
    for i,w in enumerate(widths):t.columns[i].width=Inches(w)
    for i,h in enumerate(headers):t.rows[0].cells[i].text=str(h)
    for r in rows:
        cells=t.add_row().cells
        for i,x in enumerate(r):cells[i].text=str(x)
    for ri,row in enumerate(t.rows):
        pr=row._tr.get_or_add_trPr();nosplit=OxmlElement('w:cantSplit');pr.append(nosplit)
        if ri==0:
            repeat=OxmlElement('w:tblHeader');pr.append(repeat)
        for i,c in enumerate(row.cells):
            c.width=Inches(widths[i]);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tcpr=c._tc.get_or_add_tcPr();mar=OxmlElement('w:tcMar')
            for side,n in [('top','60'),('bottom','60'),('left','80'),('right','80')]:
                e=OxmlElement('w:'+side);e.set(qn('w:w'),n);e.set(qn('w:type'),'dxa');mar.append(e)
            tcpr.append(mar)
            borders=OxmlElement('w:tcBorders')
            for side in ['top','bottom','left','right']:
                e=OxmlElement('w:'+side);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
            tcpr.append(borders)
            shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'243C50' if ri==0 else ('F2F5F7' if ri%2==0 else 'FFFFFF'));tcpr.append(shade)
            for p in c.paragraphs:
                p.paragraph_format.space_after=Pt(0);p.paragraph_format.line_spacing=1
                p.alignment=WD_ALIGN_PARAGRAPH.LEFT if i==0 else WD_ALIGN_PARAGRAPH.CENTER
                for r in p.runs:r.font.size=Pt(size);r.bold=ri==0;r.font.color.rgb=RGBColor(255,255,255) if ri==0 else RGBColor(0,0,0)
    spacer=para('');spacer.paragraph_format.space_after=Pt(3);spacer.paragraph_format.line_spacing=1
    spacer.add_run(' ').font.size=Pt(2)
    return t
def note(text):
    p=para(text)
    for r in p.runs:r.font.size=Pt(9)
def equation(text):
    p=para('');p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    math=OxmlElement('m:oMath');r=OxmlElement('m:r');tx=OxmlElement('m:t');tx.text=text;r.append(tx);math.append(r);p._p.append(math)

para('MFLP statistical analysis', 'Title')
para('Confidence intervals family results agreement calibration and path reconstruction', 'Subtitle')
para('Analysis of 1,176 responses from seven investigators across 168 canonical cases. Prepared against the full v3.95 protocol, the v3.96 statistical insert, the investigator workbooks and the private assignment and ground-truth archive.')
heading('The empirical result')
para('The reconstructed decision is ABSTAIN. No profile reaches the insert’s absolute adequacy requirement on all three gating outcomes. Full telemetry reaches an exact delivered-attack attribution rate of 0.176, path coverage of 0.698 and PRS of 0.658. Detection recall is much higher, at 0.921. These observations support a detection–attribution gap but do not establish a minimum sufficient profile.')
table(['L4 outcome','Estimate and 95% interval'],[[label,interval(get('L4',m))] for label,m in [('Exact attribution on delivered attacks','exact_attribution_delivered'),('Path coverage over all cases','path_coverage_all'),('Path Reconstruction Score over all cases','prs_all'),('Recall over all malicious cases','recall_all_malicious')]],widths=[4.7,2.5],size=10)
para('The supplied main-table estimates are reproducible, but their definitions differ from the original protocol. The insert excludes indeterminate classifications from recall and restricts attribution to delivered attacks. This supplement preserves those estimates for reconciliation and also supplies the protocol-defined alternatives.')
para('Agreement can be computed across investigators observing the same case under different profiles. Agreement within a fixed case and profile cannot be estimated because each such unit has only one rating. Confidence is recorded once per response, rather than per conclusion; calibration below therefore has a stated interpretation and is exploratory.')
note('The accompanying analysis archive contains aggregate CSV tables with unrounded estimates, intervals and denominators, figures, validation checks and the reproducible analysis script. It contains no private traces, ground truth or assignment key.')

page('1 Data validation and statistical methods')
para('All 1,176 workbook rows join one-to-one to the assignment map, with no missing or duplicated assigned responses. Each case has exactly one observation at every profile and exactly one observation from every investigator. Each profile and investigator contributes 168 observations. Family × investigator × profile cells contain three cases for each attack family and six for benign controls.')
table(['Family','Description','Cases','Delivered'],[[r.family,r.family_name,r.n_cases,r.injection_delivered] for r in pd.read_csv(DATA/'family_inventory.csv').itertuples()],widths=[.55,4.55,1,1.1],size=9.5)
para('Unless otherwise stated, intervals are two-sided 95% percentile intervals from 2,000 bootstrap resamples, using canonical cases as clusters and retaining all associated investigator responses. Seed: 20260912. Profile contrasts use the same resample on both sides. The overall bootstrap resamples 168 cases without stratification; family analyses resample within the family or stated family group. Denominators are recomputed in every replicate.')
para('These intervals describe case-sampling uncertainty for the observed investigator panel and application. They do not estimate uncertainty over a new population of investigators or model configurations. The analysis follows the insert’s bootstrap specification; it is not a reimplementation of the original protocol’s CR2 estimator or mixed model.')
para('Family cells have only 21 cases, except benign controls with 42; delivered-attack attribution in T has 20 eligible cases. All intervals are pointwise, not simultaneous. Bootstrap intervals can collapse to [0, 0] or [1, 1] at observed boundaries; this is not evidence of a population certainty. The CSV includes Wilson intervals for eligible binary proportions as a boundary sensitivity check.')
note('A missing denominator is reported as unavailable rather than zero. This applies, for example, to malicious-case recall in benign controls and to L0 precision and MCC. Family-restricted effects are descriptive estimates with intervals; no unverified confirmatory significance claims are assigned.')

page('2 Reproduction of the supplied results')
para('Table S1 reproduces Table 12 in the statistical insert and adds confidence intervals and PRS. Precision uses TP/(TP + FP). “Recall decided” uses TP/(TP + FN) after dropping indeterminate responses. Exact attribution requires the correct channel and object, restricted to 125 delivered malicious cases. Coverage and PRS average over all 168 cases per profile.')
table(['Profile','Precision','Recall\ndecided','Exact\nattribution','Coverage','PRS'],[[p]+[interval(get(p,m)) for m in ['precision','recall_decided','exact_attribution_delivered','path_coverage_all','prs_all']] for p in P],widths=[.75,1.29,1.29,1.29,1.29,1.29],size=8.5)
note('Table S1. Point estimate followed by [95% case-bootstrap CI]. All 27 populated performance values in the source table agree at its three-decimal precision. Intervals are newly computed; no original bootstrap seed or scorer was supplied.')
d.add_heading('Indeterminate classifications affect the denominator',2)
rows=[]
counts=pd.read_csv(DATA/'classification_counts.csv')
for p in P:
    n=int(counts[counts.profile.eq(p)].indeterminate.sum())
    rows.append([p,str(n)+'/168',interval(get(p,'recall_all_malicious')),val(get(p,'recall_decided')['denominator'],0)])
table(['Profile','Indeterminate','Recall all 126 malicious cases','Decided malicious denominator'],rows,widths=[.8,1.3,2.7,2.4],size=9)
para('At L1, excluding 19 indeterminate malicious responses changes recall from 70/126 = 0.556 to 70/107 = 0.654. At A_noE2, dropping five changes recall from 88/126 = 0.698 to 88/121 = 0.727. L3 and L4 contain no indeterminate responses. The insert’s recall should be labelled conditional recall, with unconditional recall and abstention reported alongside it.')

page('3 Outcomes under the original protocol')
para('Section 5.1 of the full manuscript maps indeterminate to a non-malicious prediction. Table S2 uses that rule for F1 and MCC. Precision is unchanged from Table S1 and unconditional recall is reported on the preceding page. MCC is mathematically undefined at L0 because every binary prediction is non-malicious.')
table(['Profile','F1','MCC','Binary accuracy','Specificity'],[[p]+[interval(get(p,m)) for m in ['f1_protocol','mcc_protocol','binary_accuracy_protocol','specificity_protocol']] for p in P],widths=[.8,1.6,1.6,1.6,1.6],size=9)
para('Section 5.2 credits benign controls when the channel is “none” and does not require an object match for them. Its primary all-case attribution outcome is therefore different from the insert’s attack-only outcome. Both are shown below; channel-only credit remains separate.')
table(['Profile','Exact all cases\noriginal protocol','Exact delivered attacks\nstatistical insert','Channel only\ndelivered attacks'],[[p]+[interval(get(p,m)) for m in ['exact_attribution_protocol_all','exact_attribution_delivered','channel_only_delivered']] for p in P],widths=[.8,2.15,2.15,2.1],size=9)
note('Table S3. Channel-only means correct channel with an incorrect object, not inclusive channel accuracy. At L4, inclusive channel accuracy is 0.688, consisting of 0.176 exact and 0.512 channel-only. Exact all-case attribution is 54/168 = 0.321. Neither attribution definition approaches 0.90.')

page('4 Path Reconstruction Score and grounding')
para('The ordered sequence is scored against the private ordered ground-truth steps. No reported sequence contains duplicate identifiers, so the manuscript’s distinct-match definition and its order factor can be implemented without a duplicate-resolution convention. Empty or completely unmatched sequences receive PRS zero.')
equation('ρ = |M| / |S|      π = |M| / |R|')
equation('κ = LCS(R|S, S|R) / length(R|S)')
equation('PRS = κ × 2πρ / (π + ρ)')
note('R|S denotes the reported subsequence retained in the truth; S|R denotes the truth subsequence retained in the report. The order-factor denominator is the length of R|S. Empty-path precision and order factor are assigned zero for macro summaries.')
table(['Profile','Coverage','Path precision\nmacro','Order factor\nmacro','PRS','Unsupported\nstep fraction'],[[p]+[val(get(p,m)['estimate']) for m in ['path_coverage_all','path_precision_macro','order_consistency_macro','prs_all','unsupported_path_fraction_micro']] for p in P],widths=[.8,1.1,1.4,1.3,1.1,1.5],size=9)
note('Table S4. Component point estimates; full intervals are in performance_intervals.csv. Unsupported fraction here pools reported steps within profile. Macro mean PRS is computed per response, not from the averaged components.')
d.add_picture(str(DATA/'performance.png'),width=Inches(5.0))
para('L4 recovers more ground-truth steps than L3, but its unsupported-step fraction is also higher (0.177 versus 0.157). The paired PRS increment is only 0.011 [−0.038, 0.060]. PRS can exceed coverage when path precision exceeds coverage; it is not constrained to lie below coverage.')
para('All 3,490 supporting event citations refer to canonical events in the event classes retained by the assigned profile. Every response cites at least one such event. This yields a response-level grounding proxy of 1.000 at every profile, not the conclusion-level EGR promised by Section 5.4: the workbooks supply one shared citation list, not one list per conclusion. Event presence does not establish that an event substantively supports a conclusion; actual released package bytes were not supplied.')

page('5 Family breakdown of detection and attribution')
para('The family matrices retain the full seven-profile design. Values below are point estimates; every defined cell has a bootstrap interval and denominator in performance_intervals.csv. D, I, R, T, X and F contain 21 cases each. T has 20 delivered injections; B contains 42 benign controls.')
def matrix(metric,benign_metric=None):
    return [[f]+[val(get(p,benign_metric if f=='B' and benign_metric else metric,f)['estimate']) for p in P] for f in F]
d.add_heading('Recall across all malicious cases',2)
table(['Family']+P,matrix('recall_all_malicious'),widths=[.6]+[6.6/7]*7,size=9)
note('Table S5. Indeterminate counts as a missed detection. Recall is not defined for B. B false-positive rates across L0, L1, A_noE3, L2, A_noE2, L3 and L4 are '+', '.join(val(get(p,'false_positive_rate','B')['estimate']) for p in P)+'.')
d.add_heading('Exact attribution on delivered attacks',2)
table(['Family']+P,matrix('exact_attribution_delivered'),widths=[.6]+[6.6/7]*7,size=9)
note('Table S6. Correct channel and exact object match. The benign-control outcome is separately available as exact_attribution_protocol_all in the CSV; it is not mixed into this attack-only matrix.')
para('The aggregate attribution deficit is heterogeneous. At L4, malicious-tool-output attribution is 0.700 [0.500, 0.900], compared with 0.095 for indirect-document incidents, 0.143 for poisoned RAG, and zero for direct injection. It is therefore misleading to describe every family as having approximately one-in-six attribution success.')
para('The direct-injection result requires a scoring interpretation. Its ground-truth object identifier is “user_input”. At L4, 18/21 responses correctly identify the user channel, but none reports that exact object label: 15 give an event identifier, five answer unknown, and one leaves it blank. In family I at L4, 12/21 answers use “rag_corpus” where truth requires “retrieved_document”. These are exact-schema mismatches; the present analysis does not silently merge channel labels or map event IDs to objects.')

page('6 Family breakdown of path reconstruction')
d.add_heading('Coverage by family and profile',2)
table(['Family']+P,matrix('path_coverage_all'),widths=[.6]+[6.6/7]*7,size=9)
d.add_heading('PRS by family and profile',2)
table(['Family']+P,matrix('prs_all'),widths=[.6]+[6.6/7]*7,size=9)
note('Tables S7 and S8. Point estimates; full cell-level intervals are included in the analysis archive. Coverage and PRS include benign cases because the manifests define ordered sequences for them.')
d.add_heading('Full telemetry reference with intervals',2)
table(['Family','Coverage at L4','PRS at L4'],[[f,interval(get('L4','path_coverage_all',f)),interval(get('L4','prs_all',f))] for f in F],widths=[.8,3.2,3.2],size=9)

page('7 Paired evidence contrasts')
para('Each contrast subtracts the two profile estimates within the same case-bootstrap replicate. Intervals are unadjusted two-sided 95% intervals and are not a claim that the full protocol’s omnibus gate, mixed model and multiplicity sequence have been executed.')
names=['E2 without E3','E3 without E2','E3 with E2','E2 with E3','E4 beyond L3','Equivalent evidence arms']
labels=['A_noE3 − L1','A_noE2 − L1','L3 − L2','L3 − A_noE2','L4 − L3','A_noE3 − L2']
metrics=['exact_attribution_delivered','path_coverage_all','recall_decided','prs_all']
table(['Contrast','Exact attribution','Coverage','Recall decided','PRS'],[[label]+[interval(con[(con.contrast==name)&(con.metric==m)].iloc[0]) for m in metrics] for name,label in zip(names,labels)],widths=[1.4,1.45,1.45,1.45,1.45],size=8.5)
note('Table S9. Contrast estimates are computed from unrounded data. Several insert values were obtained by subtracting rounded inputs: for example, A_noE3 − L1 recall rounds to 0.147, not 0.148, and L3 − A_noE2 coverage rounds to 0.233, not 0.232.')
d.add_heading('Family restricted effects linked to H1 to H3',2)
table(['Hypothesis and cases','Exact attribution','Coverage','PRS'],[[label]+[interval(fc[(fc.contrast==name)&(fc.metric==m)].iloc[0]) for m in ['exact_attribution_delivered','path_coverage_all','prs_all']] for name,label in [('H1 direct','H1  D  L1 − L0'),('H2a retrieval','H2a  I + R  L2 − L1'),('H2b tool','H2b  T  L3 − L2'),('H3 exfiltration','H3  X  L4 − L3')]],widths=[2,1.73,1.73,1.74],size=8.5)
para('Tool telemetry has a large observed attribution increment within T: 0.700 [0.500, 0.895]. In contrast, the X-family E4 increment in PRS is 0.046 [−0.080, 0.173]. Neither the overall nor X-family PRS comparison establishes an E4 benefit at this sample size. Direct-family detection improves strongly at L1, but exact source attribution does not, so H1 cannot be claimed in full.')
para('A_noE3 = {E0, E1, E2} is the same evidence set as L2. It is a separately assigned arm, not a second distinct non-nested evidence set. Its differences from L2 are compatible with zero. E2 without E3 is already identified by L2 − L1; only A_noE2 supplies the missing combination needed for E3 without E2.')

page('8 Agreement across investigators and evidence')
para('The seven ratings of each canonical case are linked before computing agreement. Incident classification retains malicious, benign and indeterminate as three nominal categories. Unknown values in the other categorical fields are retained as categories, not discarded as missing observations.')
table(['Outcome','Observed agreement','Krippendorff alpha','Fleiss kappa'],[[label]+[interval(ag[(ag.scope=='all_profiles')&(ag.field==field)&(ag.metric==m)].iloc[0]) for m in ['pairwise_agreement','krippendorff_alpha_nominal','fleiss_kappa']] for field,label in [('incident_class','Incident class'),('injection_channel','Injection channel'),('tool_action','Tool action'),('external_effect','External effect')]],widths=[1.8,1.8,1.8,1.8],size=9)
para('For incident classification, pooled alpha is 0.149 [0.098, 0.193]. Excluding L0 raises it to 0.312 [0.237, 0.381]. This is consistent with disagreement driven partly by deliberately different evidence availability. It cannot be used as an estimate of investigator reproducibility under identical information.')
d.add_heading('Pairwise investigator Cohen kappa for incident class',2)
inv=['I1','I2','I3','I4','I5','I6','I7'];rows=[]
for a in inv:
    row=[a]
    for b in inv:
        if a==b:row.append('1.000');continue
        aa,bb=sorted([a,b]);z=pw[(pw.axis=='investigator')&(pw.left==aa)&(pw.right==bb)&(pw.metric=='cohen_kappa')].iloc[0];row.append(val(z['estimate']))
    rows.append(row)
table(['Rater']+inv,rows,widths=[.6]+[6.6/7]*7,size=9)
note('Table S11. These paired comparisons are also confounded with differing evidence profiles. All 21 pairwise intervals and all profile-pair intervals are in pairwise_agreement_intervals.csv.')
para('For L3 versus L4, incident-class agreement is 0.839 [0.786, 0.893] and Cohen kappa is 0.587 [0.444, 0.722]. These compare different investigators assigned to the two profiles on each case.')
para('PRS absolute-agreement ICC(A,1), treating investigators as fixed columns, is 0.194 [0.139, 0.245]. Treating profiles as fixed columns gives 0.227 [0.179, 0.272]. Both are descriptive agreement across heterogeneous evidence conditions. The requested per-profile alpha and ICC are not identifiable from one rating per case–profile cell; a replication needs at least two independent ratings of the same package.')

page('9 Confidence calibration')
para('The full manuscript specifies confidence per conclusion, but the workbooks contain only one confidence_0_100 field per response. Its target is not stated in a supplied handbook. We therefore compute an explicitly exploratory classification-confidence diagnostic: confidence/100 is treated as the probability that the selected malicious or benign classification is correct. The main diagnostic excludes indeterminate responses and reports their frequency separately.')
table(['Profile','Decisive n','Mean confidence','Accuracy','Brier and 95% CI','ECE and 95% CI'],[[p,str(cg(p,'brier')['n']),val(cg(p,'mean_confidence')['estimate']),val(cg(p,'observed_frequency')['estimate']),interval(cg(p,'brier')),interval(cg(p,'ece'))] for p in ['ALL']+P],widths=[.8,.8,1.2,1,1.7,1.7],size=9)
note('Table S12. Brier is the mean squared probability error. ECE uses ten equal-width bins [0, 0.1), …, [0.9, 1]. Lower values are better for these diagnostics. “ALL” pools 991 decisive responses while bootstrap resampling remains by canonical case.')
para('L4 has Brier 0.104 [0.073, 0.139] and ECE 0.080 [0.039, 0.125]. Its average stated confidence is 0.839 versus classification accuracy 0.893, so it is underconfident in the aggregate. This does not imply that every confidence bin is underconfident or that source-attribution confidence is calibrated.')
para('Two sensitivity interpretations are also provided. First, all 1,176 responses can be retained and indeterminate treated as an incorrect classification, producing Brier 0.153 [0.137, 0.169]. This can reward appropriately low confidence in abstentions and must not be confused with better diagnostic performance. Second, among decisive responses, probability of maliciousness can be reconstructed as c for malicious answers and 1 − c for benign answers. Its Brier score equals the main diagnostic algebraically, but its bins and decomposition differ.')
para('Confidence intervals are resampling intervals for the observed confidence values; no recalibration model was fitted and no held-out calibration performance is claimed. Per-investigator diagnostics and bin-level observed frequencies are included in the archive. Source-attribution, tool-action and external-effect calibration cannot be recovered as originally specified without separate confidence fields for those conclusions.')

page('10 Calibration decomposition and reliability diagrams')
equation('B = REL − RES + UNC + εbin')
para('REL measures squared bin-level confidence–accuracy gaps, RES measures variation in bin-level outcome frequencies, and UNC is the outcome variance. The residual εbin is computed explicitly as the observed Brier score minus REL − RES + UNC. Omitting it makes the three-term identity inexact when distinct forecasts are grouped into the same bin.')
table(['Profile','REL','RES','UNC','Residual'],[[p]+[val(cg(p,m)['estimate'],5) for m in ['reliability','resolution','uncertainty','decomposition_residual']] for p in ['ALL']+P],widths=[1.2,1.5,1.5,1.5,1.5],size=9)
note('Table S13. Ten-bin decomposition of confidence in correct classification among decisive responses. Full component intervals are in calibration_intervals.csv.')
para('For all decisive responses, B = 0.175019, REL = 0.009039, RES = 0.002262, UNC = 0.169884 and residual = −0.001643. The absolute residual is 0.94% of B, not the insert’s stated approximately 0.3%. Its magnitude need not decrease monotonically as bin count increases: with 5, 10 and 20 bins it is 0.001569, 0.001643 and 0.000825. Grouping by each exact observed confidence value makes the residual zero up to floating-point precision.')
d.add_picture(str(DATA/'calibration.png'),width=Inches(6.9))
note('Figure S2. Reliability diagrams under the stated classification-confidence interpretation. Marker area increases with bin count. The diagonal represents perfect calibration. Empty bins are omitted. Bin counts and bootstrap intervals for observed frequencies are supplied as CSV.')

page('11 Reconstructed selection rule')
para('The later insert specifies δ = 0.10, τ = 0.90 on exact delivered-attack attribution, all-case coverage and conditional recall, with one-sided 95% bootstrap bounds. The original manuscript instead uses an attribution point-estimate feasibility screen and a different multiplicity plan. Neither original scoring code nor the locked configuration bytes were supplied, so this is a transparent reconstruction of the insert’s written rule, not independent verification of preregistration.')
table(['Profile','Upper loss bound\nattribution','Upper loss bound\ncoverage','Upper loss bound\nrecall','All NI bounds\nbelow 0.10'],[[p]+[val(gate[(gate.profile==p)&(gate.metric==m)].iloc[0].difference_upper95) for m in ['exact_attribution_delivered','path_coverage_all','recall_decided']]+['Yes' if gate[gate.profile.eq(p)].passes_ni_bound.all() else 'No'] for p in P],widths=[.8,1.6,1.6,1.6,1.6],size=9)
table(['L4 outcome','Point estimate','Lower one-sided 95% bound','Meets 0.90 floor'],[[label,val(gate[(gate.profile=='L4')&(gate.metric==m)].iloc[0].estimate),val(gate[(gate.profile=='L4')&(gate.metric==m)].iloc[0].adequacy_lower95),'No'] for label,m in [('Exact attribution','exact_attribution_delivered'),('Path coverage','path_coverage_all'),('Conditional recall','recall_decided')]],widths=[2,1.3,2.4,1.5],size=9)
para('All three reference-profile lower bounds fail the 0.90 floor, including recall: its point estimate is 0.921 but its lower bound is 0.880. ABSTAIN therefore follows even before comparing profile costs. Under the original protocol’s attribution definition, the reference point estimate is only 0.321, so that feasibility screen also fails.')
para('L3 passes the three unadjusted non-inferiority bounds. However, applying the insert’s stated Holm correction over all 21 profile × outcome bootstrap tail quantities produces adjusted L3 values of 0.110, 0.296 and 0.072 for attribution, coverage and recall. None is below 0.05. Thus L3 should not be called multiplicity-adjusted non-inferior on the basis of this procedure.')
para('The script preserves the stated (1 + count of bootstrap losses ≥ δ)/(B + 1) calculation and its Holm transformation as diagnostics. An uncentered bootstrap tail proportion is not, merely by construction, a validated frequentist p-value under the non-inferiority null. The original test implementation and intended role of Holm must be reconciled before making a confirmatory non-inferiority claim. This issue cannot overturn the floor failure in these data.')
note('Observed L4 performance is not a proof that a floor is unreachable under every possible data realization, nor that full telemetry is a ceiling on observed human performance. Replace those universal claims with a statement about failure in the observed sample and under the specified bounds.')

page('12 Text for the results section')
d.add_heading('Confidence intervals and path reconstruction',2)
para('All 1,176 investigator–case responses were joined to the private assignment map and ground truth. Confidence intervals were obtained using 2,000 canonical-case bootstrap resamples, retaining the paired profile observations for each sampled case. At L4, exact source attribution on the 125 delivered attacks was 0.176 (95% CI 0.113–0.246), all-case path coverage was 0.698 (0.637–0.757), and PRS was 0.658 (0.601–0.713). L3 PRS was 0.647 (0.591–0.702), giving a paired L4–L3 difference of 0.011 (−0.038 to 0.060). These data do not establish an incremental PRS benefit from E4.')
d.add_heading('Family variation and agreement',2)
para('Performance varied substantially by family. At L4, exact attribution was 0.700 (0.500–0.900) for malicious tool output, but 0.095 for indirect-document incidents and 0.143 for poisoned RAG. Direct-injection object attribution was zero despite 18/21 correct channel identifications; this reflects a mismatch between reported event identifiers and the required object identifier and must not be interpreted as evidence that investigators could not identify the entry channel. Across the seven ratings per case, incident-class Krippendorff alpha was 0.149 (0.098–0.193). Because each rating used a different evidence profile, this coefficient describes agreement across investigator and evidence conditions. Per-profile reliability could not be estimated from the single rating available per case–profile unit.')
d.add_heading('Confidence and the selection outcome',2)
para('The workbooks contained one confidence value per response. Treating it exploratorily as confidence in the selected incident classification, the 991 decisive responses yielded Brier score 0.175 (0.157–0.193) and ECE 0.057 (0.040–0.090). At L4, the corresponding values were 0.104 (0.073–0.139) and 0.080 (0.039–0.125). The ten-bin decomposition included an explicit discretisation residual. These diagnostics do not establish calibration of the separate source, path or external-effect conclusions.')
para('The reconstructed selection rule returned ABSTAIN. At the reference profile, the one-sided 95% lower bounds for exact delivered-attack attribution, path coverage and conditional detection recall were 0.123, 0.646 and 0.880, respectively; all were below the specified 0.90 floor. The result is a failure of the adequacy requirement in this sample, not a demonstration that the floor is theoretically unattainable. No minimum sufficient logging profile is recommended.')
d.add_heading('Integration notes',2)
para('Use Tables S1–S3 to replace the profile summaries after reconciling Sections 5.1 and 5.2 with the insert. Add the family matrices, paired contrasts, agreement and calibration tables to the results or supplement. Replace “analyses pending” only for the outputs completed here; retain the limitations on per-profile reliability, per-conclusion calibration, conclusion-level grounding, timing, realized costs and robustness replication. The manuscript’s Stage-1 status, abstract and conclusion also need to be updated when these empirical results are integrated.')

page('13 Data quality and limits of completion')
table(['Investigator','Rows','Elapsed seconds in every row'],[[r.investigator,r.n,val(float(r.elapsed_seconds_unique),0)] for r in pd.read_csv(DATA/'response_audit.csv').itertuples()],widths=[1.6,1,4.6],size=9.5)
para('Elapsed times are constant within each investigator, including three zero-duration series and one negative-duration series. This contradicts the insert’s statement that every response has zero elapsed time. Positive constants are also unsuitable as measured reconstruction times. No timing estimate or time-based efficiency claim is made; the files alone do not establish how the corruption arose.')
para('Protocol integrity cannot be independently certified. The archive includes a run manifest with configuration and source-code hashes, but not the configuration bytes, original scorer, deviation log, released package manifests or ethics record. Those hashes are evidence of recorded identifiers, not a verified before-unsealing lock. The empirical response counts are verified; historical claims about blinding, lock timing and pilot decisions are not established by these files.')
para('The original per-profile agreement design is not estimable. A_noE3 duplicates L2’s declared evidence set. The canonical E1 records contain context_component_ids in all 302 E1 events, so the theorem’s assumption of absent block identity cannot automatically be treated as satisfied by the realized traces. Poor exact attribution is not itself a validation of the theorem or proof of structural non-identifiability.')
para('Not computed or claimed: conclusion-specific calibration or grounding, same-package inter-rater reliability, the original CR2 or generalized mixed-model tests, independently verified preregistration, a second-model replication, a redacted-E3 comparison, or empirical cost-frontier estimates. The latter require the actual projection/serialization and sensitivity schema used to generate the delivered packages; the original manuscript’s reference costs are not measurements of this corpus.')
d.add_heading('Methodological references',2)
note('Murphy, A.H. A New Vector Partition of the Probability Score. Journal of Applied Meteorology 1973, 12, 595–600. DOI: 10.1175/1520-0450(1973)012<0595:ANVPOT>2.0.CO;2. Included as reference 30 in the supplied full manuscript. The binning residual in this supplement is calculated directly, not assumed from that source.')
note('Krippendorff, K. Computing Krippendorff’s Alpha-Reliability. 2011, literature updated 2013. University of Pennsylvania. https://www.asc.upenn.edu/sites/default/files/2021-03/Computing%20Krippendorff%27s%20Alpha-Reliability.pdf. Nominal alpha is calculated from observed disagreement and finite-sample expected disagreement; observed agreement is also reported to show the effect of marginal category frequencies.')
note('All numeric results in this supplement derive from the supplied archives. External sources are methodological references, not substitutes for the private ground truth. The reproducible package contains only aggregate outputs and analysis code, with input-archive SHA-256 hashes for version identification.')

d.core_properties.title='MFLP statistical analysis'
d.core_properties.subject='Confidence intervals family breakdowns agreement calibration and PRS'
d.core_properties.author=''
d.save(OUT/'MFLP_Statistical_Supplement.docx')
print(OUT/'MFLP_Statistical_Supplement.docx')
