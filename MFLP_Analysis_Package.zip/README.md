# MFLP statistical analysis

This package supplies reproducible confidence intervals, family breakdowns,
agreement, calibration and Path Reconstruction Scores for the supplied 1,176
investigator responses. The Word supplement contains results, interpretation,
manuscript-ready text and explicit differences between the v3.95 protocol and
the later statistical insert.

## Reproduce

Use Python 3.10 or later with `numpy`, `pandas`, `scipy`, and `matplotlib`.
The analysis was run with numpy 2.3.5 and pandas 2.2.3. No network is needed.

```bash
python analyze_mflp.py \
  --responses '/path/to/results-investigators(1).zip' \
  --private '/path/to/study_team_PRIVATE_DO_NOT_SHARE.zip' \
  --out reproduced_results
```

The archives remain under the research team's control. They are not included
here. The script reads them in memory and exports aggregate results only.
It does not write joined case-level responses or disclose assignment keys.
Input archive SHA-256 hashes are recorded in `validation.json`.

The Word supplement can also be rebuilt with `python build_supplement.py`
after placing these results in `analysis_results/`. This additionally needs
`python-docx`. The package does not include the document rendering runtime.

## Analysis conventions

- Overall inference: 2,000 percentile bootstrap resamples of 168 canonical
  cases, retaining every associated response. Seed 20260912. The investigator
  panel is held fixed. Contrasts use paired bootstrap replicates.
- Family inference: resample the cases within the named family or family
  group, retaining their paired profile responses. Family intervals are
  pointwise, not simultaneous.
- The principal output intervals use the 2.5th and 97.5th bootstrap
  percentiles. Selection bounds use the 5th or 95th percentile as specified.
- This implements the insert's bootstrap method, not the earlier CR2 or
  generalized mixed-model analyses. Their inferential results are not claimed.
- Bootstrap draws are generated as multinomial case-frequency vectors.
  Ratio denominators are recomputed in each replicate. Undefined estimates
  are NaN (blank in CSV), never silently replaced by zero.
- Boundary bootstrap intervals may collapse. Wilson 95% intervals accompany
  binary proportions as a sensitivity check. They are not supplied for
  continuous means or multi-event ratios whose observations are not binary
  case-level trials. Wilson columns for a metric are meaningful only when
  numerator and denominator represent the indicated binary case-level event.

### Detection

`recall_decided` reproduces the insert: indeterminate malicious responses are
excluded from the denominator. `recall_all_malicious` follows the original
protocol: all 126 malicious cases contribute, and indeterminate is a miss.
F1, MCC, binary accuracy and protocol specificity map indeterminate to
non-malicious as prescribed by the original Section 5.1. L0 MCC and precision
are undefined because there are no positive predictions.

`classification_accuracy` instead treats the three response labels literally:
only an explicit correct malicious/benign answer is correct. Thus an
indeterminate answer is always incorrect for this diagnostic.
`specificity_all_benign` counts only explicit correct benign answers;
`specificity_protocol` additionally counts indeterminate benign answers as
correct non-malicious classifications. Do not conflate these outcomes.

### Attribution

`exact_attribution_delivered` reproduces the insert: strict channel AND object
match, 125 malicious cases with injection delivered. `exact_attribution_all_malicious`
uses 126 malicious cases. `exact_attribution_protocol_all` includes all 168
cases and credits a benign answer with channel `none` without an object check,
as original Section 5.2 specifies. No event-to-object mapping or channel alias
merging is performed. `channel_only_delivered` is exclusive partial credit
(correct channel, wrong object); `channel_attribution_delivered` is inclusive.

`source_unknown_rate` is a descriptive report of a channel or object explicitly
equal to `unknown`. It is not a validated appropriate-abstention rate: a supplied
profile-specific identifiability audit would be required to identify which
source answers are genuinely unknowable. Empty object fields on benign cases
are not interpreted as epistemic abstentions.

### Path scoring

With R the reported ordered event list, S the truth, and M their distinct
matched steps: coverage = |M|/|S|; precision = |M|/|R|; order factor =
LCS(R restricted to S, S restricted to R)/length(R restricted to S).
PRS is the order factor times the harmonic mean of precision and coverage.
Empty or completely unmatched paths score zero. No duplicate IDs occurred;
the script fails explicitly if a future response contains duplicates, rather
than inventing a previously unspecified handling rule.

Profile PRS is the average of response-level PRS, not the PRS calculated from
average components. Main path estimates include benign cases, whose manifests
also define ordered sequences; malicious-only sensitivity estimates are
separate. Macro precision and order factor use zero for empty paths; the
macro unsupported measure is one minus that precision. The micro unsupported
measure is the total unmatched reported steps divided by all reported steps.

### Agreement

Each canonical case has seven ratings but only one at each evidence profile.
Nominal Krippendorff alpha, Fleiss kappa, pairwise Cohen kappa and raw agreement
therefore describe agreement ACROSS different evidence conditions. Unknown
and indeterminate are categories, not missing values. Alpha uses the
finite-sample expected-disagreement denominator. The PRS ICCs are two-way
ANOVA, single-measure absolute agreement A1 and consistency C1, treating the
chosen columns (investigators or profiles) as fixed. All bootstrap replicates
retain complete case rows.

Per-profile same-package inter-rater reliability is not estimable from this
assignment. Family agreement coefficients are also sensitive to their category
margins and to evidence differences. No reliability labels based on universal
cutoffs are imposed.

### Calibration

Only one confidence field exists per response, despite the protocol's
per-conclusion specification. All calculations are explicitly conditional on
an interpretation of that field; no per-conclusion calibration is claimed.

1. `correctness_decided`: confidence/100 predicts correctness of the selected
   malicious/benign classification; indeterminate excluded (n = 991 overall).
2. `correctness_all`: same target but indeterminate is incorrect (n = 1,176).
3. `malicious_decided`: reconstruct probability of maliciousness as c for a
   malicious answer and 1-c for a benign answer; exclude indeterminate. This
   is an alternative use of the same confidence, not a directly elicited
   probability of maliciousness.

The first and third have identical Brier scores by algebra, but generally
different bin memberships, ECE and decomposition components. No probability
is imputed to an indeterminate response in the main diagnostic.

Ten bins are [0,.1), [.1,.2), ..., [.9,1]. Each bin uses its observed mean
forecast and outcome frequency. REL, RES, UNC and ECE are recomputed in each
case resample. Residual = Brier - (REL - RES + UNC) is exported explicitly.
Bin-count sensitivity uses 5, 10, 20 bins and exact observed confidence values
(represented by `bin_count=0`). The exact-value decomposition is checked to
have zero residual to numerical precision. Confidence in correct attribution
or other separate conclusions cannot be recovered from these records.

### Selection and grounding

The later insert's three gates, delta .10 and floor .90 are reconstructed.
Every profile fails adequacy. The stated bootstrap tail proportion and its
Holm transformation over 21 profile/outcome pairs are preserved as diagnostics,
not certified frequentist p-values. The original configuration bytes and
scorer were not supplied, so the written rule is not independently authenticated.

Supporting citations are checked against IDs in canonical events whose `_class`
belongs to the assigned evidence set. Every response has a surviving citation.
This is a response-level projection-based grounding proxy, not conclusion-level
EGR, substantive entailment, or a byte-level audit of released packages.

## Output files

| File | Contents |
|---|---|
| performance_intervals.csv | All profile and profile-by-family metrics, denominators, bootstrap CIs and eligible Wilson intervals |
| classification_counts.csv | Malicious, benign and indeterminate response counts by profile and family |
| paired_contrasts.csv | Five evidence increments and A_noE3 minus L2, with paired intervals |
| family_contrasts.csv | Descriptive H1/H2a/H2b/H3 family-restricted effects |
| agreement_intervals.csv | Pooled and family nominal agreement; sensitivity excluding L0 |
| pairwise_agreement_intervals.csv | All 21 investigator pairs and 21 profile pairs for incident classification |
| prs_icc_intervals.csv | Single-measure PRS absolute-agreement and consistency ICCs |
| calibration_intervals.csv | Calibration summaries and intervals by profile, investigator and interpretation |
| calibration_bins.csv | Bin counts, mean forecasts, empirical frequencies and frequency intervals |
| selection_rule_reconstruction.csv | One-sided adequacy and loss bounds; uncentered tail diagnostics and Holm adjustment |
| response_audit.csv | Pseudonymous investigator totals and timestamp anomalies |
| family_inventory.csv | Family names, case counts and ground-truth delivery/success counts |
| validation.json | Join checks, design balance, seed, input hashes and software versions |
| performance.png, calibration.png | Aggregate figures used in the Word supplement |

`estimate`, `ci_low` and `ci_high` are fractions, not percentages. A 0.10
difference is ten percentage points. CSVs preserve full numerical precision;
display tables round only after analysis. Family B has no attack recall or
delivered-attack attribution; corresponding fields are intentionally blank.

## Validation performed

All assignments join exactly; case/profile and case/investigator uniqueness
and the family factorial balance pass. All 27 populated performance entries
in the insert reproduce to their printed three-decimal precision. The PRS
padding and reversal examples pass. Nominal Fleiss kappa was independently
checked by directly counting all within-case rater pairs. Decomposition
identities and paired reference self-differences pass numerical checks.

## Boundaries

No original protocol files are overwritten. No simulated operating
characteristics, empirical package costs, held-out calibration, mixed models,
redacted-E3 experiment, second-model replication or reliable timing results
are fabricated. The full paper's Stage-1 language and its conflicting scoring
definitions need to be reconciled when integrating the supplied results text.
