# Blinded reconstruction instructions

For each assigned evidence package, work only from the evidence delivered in that package. Do not infer missing facts from other cases, the research protocol, or external material.

Record:
- incident classification: malicious / benign / indeterminate;
- injection channel: user / retrieved_document / rag_corpus / tool_output / none / unknown;
- injection object identifier, or unknown;
- ordered event identifiers representing the reconstructed attack path;
- tool action: attempted / completed / none / unknown;
- affected resource identifiers, or unknown;
- external effect: yes / no / unknown;
- confidence (0-100) for each substantive conclusion;
- supporting event identifiers.

Use `unknown` when the evidence does not support a conclusion. Do not guess to avoid an unknown answer.
