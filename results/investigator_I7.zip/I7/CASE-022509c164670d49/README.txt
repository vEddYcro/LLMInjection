Blinded MFLP evidence package. Work only from files in this directory.
Do not infer missing telemetry. Cite event IDs in the workbook.
