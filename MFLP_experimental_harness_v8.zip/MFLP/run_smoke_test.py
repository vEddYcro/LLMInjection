
import subprocess,sys
cmd=[sys.executable,"-m","harness.run_experiment","--adapter","mock","--limit","14","--overwrite"]
subprocess.check_call(cmd)
subprocess.check_call([sys.executable,"-m","harness.validate_release"])
print("Smoke test complete. Mock outputs are for pipeline validation only.")
