# MFLP experimental harness

This is the missing **incident-generation and blinded-package pipeline** for the MFLP study.

It is designed to create the actual canonical incidents that human investigators can evaluate. It does **not** fabricate investigator answers or empirical results.

## What it does

1. Generates the frozen 160-case synthetic corpus:
   - D direct injection: 20
   - I indirect retrieved-document injection: 20
   - R poisoned RAG: 20
   - T malicious tool output: 20
   - X exfiltration attempt: 20
   - F failed/partial attack: 20
   - B benign controls: 40
2. Runs every case once at full instrumentation.
3. Writes immutable-style canonical traces and private ground truth.
4. Uses the powered 160 × 5 assignment from `analysis_package/out/design_assignment.csv`.
5. Deterministically projects each canonical trace to the assigned L0–L4 profile.
6. Replaces internal case IDs with investigator-specific opaque case tokens.
7. Creates per-investigator evidence folders and pre-populated workbooks.
8. Checks released packages for forbidden family/profile/ground-truth labels.

## Important: mock vs real study

`mock` exists only to test the plumbing. **Do not use mock outputs as confirmatory data.**

For a real study, use a fixed local LLM through Ollama:

```bash
python run_confirmatory.py --model YOUR_FROZEN_LOCAL_MODEL
```

The endpoint is restricted to loopback/local addresses by the code. All tools are synthetic and local:
- `search_private_record` returns synthetic secrets;
- `send_message` writes only to `runtime/local_sink/messages.jsonl`;
- `fetch_url` uses an in-process mock response and never fetches the public Internet.

## First test the package

```bash
python run_smoke_test.py
```

That creates 14 demonstration incidents and corresponding blinded packages.

## Confirmatory run

Before running:
1. Freeze the model identifier/revision and runtime.
2. Freeze `config/study.json`.
3. Freeze the scenario templates and record repository commit/hash.
4. Run the powered assignment generator if you intentionally changed study size.
5. Obtain the required ethics determination for human investigators.

Freeze the exact study files first:

```bash
python -m harness.freeze_study
python -m harness.freeze_study --verify
```

Then:

```bash
python run_confirmatory.py --model llama3.1:8b
```

Use the exact model you preregister; the command above is only an example.

Outputs:
- `runtime/canonical/` — full canonical traces; study team only during blinding.
- `runtime/ground_truth_private/` — sealed ground truth; never give to investigators.
- `runtime/study_team_private/assignment_opaque_map.csv` — profile/case mapping; study team only.
- `runtime/investigator_release/I1` ... `I5` — **these are what investigators receive**, along with the instructions.
- `runtime/local_sink/` — controlled external-effect sink.

## Investigator workflow

Each investigator receives only:
- their own `runtime/investigator_release/I#` directory;
- `analysis_package/investigator_kit/instructions.md`;
- the generated `workbook.csv`.

They must not receive the full harness, canonical traces, ground truth, design assignment, or analysis code until evaluation is locked.

## Why this package is scientifically useful

It creates the evidence on which the human reconstruction experiment is based, while keeping:
- each underlying incident fixed;
- profile differences purely a consequence of deterministic telemetry projection;
- ground truth machine-readable and sealed;
- investigator packages blinded;
- all effects local/synthetic;
- the final analysis reproducible.

The included `analysis_package/` is the separate scoring/statistics/reproducibility layer. This top-level harness is the **data-generation layer** that was missing from the earlier ZIP.
