#!/usr/bin/env python3
"""Score returned investigator workbooks against the sealed ground truth.

This is the step that turns collected human responses into the numbers that populate
Section 9 of the manuscript. It is deliberately a SEPARATE command from the data
generation run: it must only ever be executed after every investigator response is
locked, because it is the point at which blinding is broken.

Usage:
    python3 score_study.py --responses collected/ --out deliverables/results

`--responses` is a directory containing one subdirectory per investigator (I1..I5),
each holding that investigator's completed workbook.csv.
"""
import argparse, csv, json, sys, hashlib, datetime, statistics
from pathlib import Path
from collections import defaultdict, Counter

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "analysis_package" / "code"))
import metrics  # noqa: E402
sys.path.insert(0, str(ROOT))
from harness import decision_rule as dr  # noqa: E402


def check_lock(root):
    """Refuse to unseal unless the protocol AND the section 15A rule are frozen."""
    import subprocess
    lock = root / "study_lock.json"
    if not lock.exists():
        raise SystemExit(
            "No study_lock.json: the protocol was never frozen.\n"
            "Scoring would break the blind against an unfrozen protocol. Stopping.")
    r = subprocess.run([sys.executable, "-m", "harness.freeze_study", "--verify"],
                       cwd=root, capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(
            "Study lock does NOT verify - a tracked file changed since freezing:\n"
            + (r.stdout or "") + (r.stderr or "")
            + "\nResolve and document the change before unsealing results.")
    return dr.load_rule(root)

PROFILES = ["L0", "L1", "L2", "L3", "L4", "A_noE2", "A_noE3"]
CHANNELS = {"user", "retrieved_document", "rag_corpus", "tool_output", "none", "unknown"}


def load_assignment(root):
    p = root / "runtime/study_team_private/assignment_opaque_map.csv"
    with open(p, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def load_truth(root):
    truth = {}
    for p in (root / "runtime/ground_truth_private").glob("*.json"):
        truth[p.stem] = json.loads(p.read_text())
    return truth


def read_workbooks(resp_dir):
    rows = []
    for wb in sorted(Path(resp_dir).glob("*/workbook.csv")):
        inv = wb.parent.name
        with open(wb, newline="", encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                r["_investigator"] = inv
                rows.append(r)
    return rows


def split_ids(s):
    if not s:
        return []
    return [x.strip() for x in str(s).replace(";", ",").split(",") if x.strip()]


def norm(s):
    return (s or "").strip().lower()


def minutes(row):
    try:
        a = datetime.datetime.fromisoformat(row["start_time_utc"].replace("Z", "+00:00"))
        b = datetime.datetime.fromisoformat(row["submit_time_utc"].replace("Z", "+00:00"))
        return max(0.0, (b - a).total_seconds() / 60.0)
    except Exception:
        return None


def score_row(row, gt, delivered_ids):
    """Score one investigator response against one sealed ground-truth record."""
    out = {}
    truth_malicious = bool(gt["malicious"])
    cls = norm(row.get("incident_class"))
    out["reported_class"] = cls
    out["truth_malicious"] = truth_malicious

    # detection outcome (indeterminate is scored separately, never as a silent error)
    if cls == "malicious":
        out["detection"] = "TP" if truth_malicious else "FP"
    elif cls == "benign":
        out["detection"] = "FN" if truth_malicious else "TN"
    else:
        out["detection"] = "IND"

    # source attribution
    t_ch = norm(gt["injection_source"].get("channel"))
    t_obj = gt["injection_source"].get("object_id")
    r_ch = norm(row.get("injection_channel"))
    r_obj = (row.get("injection_object_id") or "").strip()
    if r_ch and r_ch not in CHANNELS:
        out["channel_valid"] = False
    else:
        out["channel_valid"] = True
    out["channel_correct"] = int(r_ch == t_ch)
    out["object_correct"] = int(bool(t_obj) and r_obj == t_obj)
    out["attribution_exact"] = int(out["channel_correct"] and out["object_correct"])
    # partial credit reported separately, per Action Plan section 10
    out["attribution_channel_only"] = int(out["channel_correct"] and not out["object_correct"])
    out["attribution_scorable"] = int(bool(gt.get("injection_delivered", truth_malicious)) and bool(t_obj))

    # appropriate abstention: saying unknown when the profile cannot support attribution
    out["abstained"] = int(r_ch == "unknown" or r_obj.lower() == "unknown")

    # path reconstruction
    reported_steps = split_ids(row.get("ordered_event_ids"))
    truth_steps = gt.get("ordered_ground_truth_steps", [])
    prs = metrics.path_reconstruction_score(reported_steps, truth_steps)
    out.update({f"path_{k}": v for k, v in (prs.items() if isinstance(prs, dict) else [("score", prs)])})
    matched = len(set(reported_steps) & set(truth_steps))
    out["path_completeness"] = matched / len(truth_steps) if truth_steps else None
    out["unsupported_step_rate"] = (
        (len(reported_steps) - matched) / len(reported_steps) if reported_steps else 0.0)

    # outcome accuracy
    t_ext = "yes" if gt.get("external_effect") else "no"
    out["outcome_correct"] = int(norm(row.get("external_effect")) == t_ext)
    t_tool = ("completed" if gt["tool_calls_completed"]
              else "attempted" if gt["tool_calls_attempted"] else "none")
    out["tool_action_correct"] = int(norm(row.get("tool_action")) == t_tool)

    # evidence grounding: cited event ids must exist in the delivered package
    cited = split_ids(row.get("supporting_event_ids"))
    out["grounding_rate"] = (
        sum(1 for c in cited if c in delivered_ids) / len(cited) if cited else None)
    out["ungrounded_citations"] = sum(1 for c in cited if c not in delivered_ids)

    # confidence / calibration input
    try:
        out["confidence"] = float(row.get("confidence_0_100"))
    except (TypeError, ValueError):
        out["confidence"] = None
    out["minutes"] = minutes(row)
    return out


def delivered_event_ids(root, investigator, token):
    p = root / "runtime/investigator_release" / investigator / token / "events.jsonl"
    if not p.exists():
        return set()
    return {json.loads(l)["event_id"] for l in p.read_text().splitlines() if l.strip()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--responses", required=True,
                    help="directory with I1/workbook.csv ... I5/workbook.csv")
    ap.add_argument("--root", default=str(ROOT))
    ap.add_argument("--out", default=str(ROOT / "deliverables/results"))
    ap.add_argument("--allow-incomplete", action="store_true",
                    help="score even if some assigned cases have no response")
    ap.add_argument("--skip-decision-rule", action="store_true",
                    help="produce descriptive tables only; do NOT apply the section 15A rule")
    a = ap.parse_args()

    root = Path(a.root)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)

    # Gate: unsealing requires a frozen, verifying protocol and a frozen 15A rule.
    rule = None
    if a.skip_decision_rule:
        print("WARNING: --skip-decision-rule set; descriptive tables only, "
              "no primary endpoint will be produced.")
    else:
        try:
            rule = check_lock(root)
        except dr.DecisionRuleError as e:
            raise SystemExit(f"Cannot unseal results:\n{e}")
        print(f"Protocol lock verified; decision rule frozen "
              f"(delta={rule['delta']}, alpha={rule['alpha']}).")

    assignment = load_assignment(root)
    truth = load_truth(root)
    responses = read_workbooks(a.responses)
    if not responses:
        raise SystemExit(f"No workbook.csv files found under {a.responses}")

    index = {(r["investigator"], r["opaque_case_token"]): r for r in assignment}
    seen = set()
    scored = []
    problems = []

    for row in responses:
        key = (row["_investigator"], (row.get("opaque_case_token") or "").strip())
        meta = index.get(key)
        if meta is None:
            problems.append(f"response with unknown token {key}")
            continue
        if not (row.get("incident_class") or "").strip():
            continue  # unanswered line
        seen.add(key)
        gt = truth[meta["case_id"]]
        s = score_row(row, gt, delivered_event_ids(root, key[0], key[1]))
        s.update(investigator=key[0], opaque_case_token=key[1], case_id=meta["case_id"],
                 family=meta.get("family") or meta["case_id"][0], profile=meta["profile"])
        scored.append(s)

    missing = [k for k in index if k not in seen]
    if missing and not a.allow_incomplete:
        raise SystemExit(
            f"{len(missing)} assigned cases have no response (e.g. {missing[:3]}). "
            f"Re-run with --allow-incomplete to score anyway, and report the response rate.")

    # ---- per-response table
    fields = sorted({k for s in scored for k in s})
    with open(out / "scored_responses.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(scored)

    # ---- aggregate by profile (the primary endpoint table)
    def agg(rows):
        det = Counter(r["detection"] for r in rows)
        tp, fp, fn, tn = det["TP"], det["FP"], det["FN"], det["TN"]
        prec = tp / (tp + fp) if tp + fp else None
        rec = tp / (tp + fn) if tp + fn else None
        f1 = (2 * prec * rec / (prec + rec)) if prec and rec else None
        scorable = [r for r in rows if r["attribution_scorable"]]
        pc = [r["path_completeness"] for r in rows if r["path_completeness"] is not None]
        gr = [r["grounding_rate"] for r in rows if r["grounding_rate"] is not None]
        mn = [r["minutes"] for r in rows if r["minutes"] is not None]
        return {
            "n": len(rows), "TP": tp, "FP": fp, "FN": fn, "TN": tn,
            "indeterminate": det["IND"],
            "precision": prec, "recall": rec, "f1": f1,
            "attribution_exact": (sum(r["attribution_exact"] for r in scorable) / len(scorable)
                                  if scorable else None),
            "attribution_channel_only": (sum(r["attribution_channel_only"] for r in scorable) / len(scorable)
                                         if scorable else None),
            "abstention_rate": sum(r["abstained"] for r in rows) / len(rows) if rows else None,
            "path_completeness_median": statistics.median(pc) if pc else None,
            "unsupported_step_rate_mean": (sum(r["unsupported_step_rate"] for r in rows) / len(rows)
                                           if rows else None),
            "outcome_accuracy": sum(r["outcome_correct"] for r in rows) / len(rows) if rows else None,
            "tool_action_accuracy": sum(r["tool_action_correct"] for r in rows) / len(rows) if rows else None,
            "grounding_rate_mean": (sum(gr) / len(gr)) if gr else None,
            "ungrounded_citations": sum(r["ungrounded_citations"] for r in rows),
            "median_minutes": statistics.median(mn) if mn else None,
        }

    by_profile = {p: agg([s for s in scored if s["profile"] == p]) for p in PROFILES}
    with open(out / "results_by_profile.csv", "w", newline="", encoding="utf-8") as f:
        cols = ["profile"] + sorted(next(iter(by_profile.values())).keys())
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for p in PROFILES:
            w.writerow({"profile": p, **by_profile[p]})

    # ---- profile x family
    with open(out / "results_by_profile_family.csv", "w", newline="", encoding="utf-8") as f:
        fams = sorted({s["family"] for s in scored})
        cols = ["profile", "family"] + sorted(agg(scored).keys())
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for p in PROFILES:
            for fam in fams:
                sub = [s for s in scored if s["profile"] == p and s["family"] == fam]
                if sub:
                    w.writerow({"profile": p, "family": fam, **agg(sub)})

    # ---- per-investigator, for inter-rater and fatigue checks
    with open(out / "results_by_investigator.csv", "w", newline="", encoding="utf-8") as f:
        invs = sorted({s["investigator"] for s in scored})
        cols = ["investigator"] + sorted(agg(scored).keys())
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for i in invs:
            w.writerow({"investigator": i, **agg([s for s in scored if s["investigator"] == i])})

    endpoint = None
    if rule is not None:
        endpoint = dr.apply_rule(scored, rule)
        (out / "primary_endpoint.json").write_text(json.dumps(endpoint, indent=2, default=str))
        report = dr.format_report(endpoint)
        (out / "primary_endpoint.txt").write_text(report)

    summary = {
        "primary_endpoint": (endpoint or {}).get("primary_endpoint"),
        "scored_responses": len(scored),
        "assigned_cases": len(index),
        "response_rate": round(len(seen) / len(index), 4) if index else None,
        "unanswered": len(missing),
        "problems": problems[:20],
        "by_profile": by_profile,
        "scored_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "ground_truth_digest": hashlib.sha256(
            json.dumps(truth, sort_keys=True).encode()).hexdigest(),
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2, default=str))

    print(f"Scored {len(scored)} responses "
          f"({summary['response_rate']:.1%} of assigned cases)" if summary["response_rate"]
          else f"Scored {len(scored)} responses")
    print(f"{'profile':<8}{'n':>5}{'precision':>11}{'recall':>9}"
          f"{'attrib':>9}{'path':>8}{'min':>7}")
    for p in PROFILES:
        r = by_profile[p]
        fmt = lambda v, d=3: ("%.*f" % (d, v)) if isinstance(v, float) else "-"
        print(f"{p:<8}{r['n']:>5}{fmt(r['precision']):>11}{fmt(r['recall']):>9}"
              f"{fmt(r['attribution_exact']):>9}{fmt(r['path_completeness_median']):>8}"
              f"{fmt(r['median_minutes'],1):>7}")
    if endpoint is not None:
        print()
        print(dr.format_report(endpoint))
    print(f"\nWrote: {out}/results_by_profile.csv, results_by_profile_family.csv, "
          f"results_by_investigator.csv, scored_responses.csv, summary.json")
    if problems:
        print(f"WARNING: {len(problems)} response rows could not be matched; see summary.json")


if __name__ == "__main__":
    main()
