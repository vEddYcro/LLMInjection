"""
figures.py -- Publication figures for the MFLP manuscript.
All inputs come from the CSVs written by design.py, schema_and_cost.py,
sizing.py and curves.py.  No figure contains invented empirical data; figures
showing performance are explicitly labelled as design calculations.
"""
import os, sys, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Rectangle, FancyBboxPatch

HERE = os.path.dirname(__file__)
OUT = os.path.join(HERE, "..", "out")
FIG = os.path.join(HERE, "..", "figs")
os.makedirs(FIG, exist_ok=True)

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8.5,
    "axes.labelsize": 9, "axes.titlesize": 9.5, "legend.fontsize": 8,
    "xtick.labelsize": 8, "ytick.labelsize": 8,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.alpha": 0.25, "grid.linewidth": 0.5,
    "figure.dpi": 200, "savefig.dpi": 300, "savefig.bbox": "tight",
})
PC = ["#2b3a67", "#1f6f8b", "#2e8b6f", "#c77b30", "#a33b3b"]
PROFS = ["L0", "L1", "L2", "L3", "L4"]


def save(fig, name):
    p = os.path.join(FIG, name)
    fig.savefig(p)
    plt.close(fig)
    print("wrote", name)


# ---------------------------------------------------------------- Figure 1
def fig_evidence_lattice():
    """Instrumented execution, evidence classes, and the projection operator."""
    fig = plt.figure(figsize=(7.2, 3.6))
    gs = fig.add_gridspec(1, 2, width_ratios=[1.55, 1], wspace=0.12)
    ax, ax2 = fig.add_subplot(gs[0]), fig.add_subplot(gs[1])

    ax.set_xlim(0, 12.2); ax.set_ylim(0, 9.2); ax.axis("off")
    BW, BH = 1.62, 0.86
    nodes = {
        "req":   (1.0, 7.6, "request", "E0", 0),
        "ret":   (3.5, 7.6, "retrieval", "E2", 2),
        "chunk": (3.5, 5.9, "poisoned chunk", "E2", 2),
        "llm":   (6.3, 6.75, "model invocation", "E1", 1),
        "tool":  (9.0, 7.6, "tool call", "E3", 3),
        "sec":   (9.0, 5.9, "secret read", "E3", 3),
        "net":   (11.2, 6.75, "egress", "E4", 4),
    }
    for k, (x, y, lab, cls, c) in nodes.items():
        ax.add_patch(FancyBboxPatch((x - BW / 2, y - BH / 2), BW, BH,
                                    boxstyle="round,pad=0.03,rounding_size=0.10",
                                    fc=PC[c], ec="none", alpha=0.9))
        ax.text(x, y + 0.13, lab, ha="center", va="center", color="w", fontsize=6.2)
        ax.text(x, y - 0.20, cls, ha="center", va="center", color="w",
                fontsize=6.0, weight="bold", alpha=0.85)

    def arrow(a, b, rad=0.0):
        x1, y1, *_ = nodes[a]; x2, y2, *_ = nodes[b]
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
                                     mutation_scale=7, lw=0.85, color="#666",
                                     shrinkA=30, shrinkB=30,
                                     connectionstyle=f"arc3,rad={rad}"))
    for a, b, r in [("req", "ret", 0), ("ret", "chunk", 0), ("chunk", "llm", 0.05),
                    ("ret", "llm", -0.05), ("llm", "tool", 0.05),
                    ("tool", "sec", 0), ("tool", "net", 0.05)]:
        arrow(a, b, r)

    ax.text(6.1, 8.8, "Canonical incident trace $G$ (complete instrumentation)",
            ha="center", fontsize=8.2, weight="bold")
    ax.text(6.1, 4.85, r"all vertices share one correlation identifier $\rho$",
            ha="center", fontsize=6.8, style="italic", color="#555")
    ax.text(6.1, 3.75, r"$\pi_L$ : deterministic, idempotent field-level projection",
            ha="center", fontsize=7.6)
    ax.add_patch(FancyArrowPatch((6.1, 3.42), (6.1, 2.45), arrowstyle="-|>",
                                 mutation_scale=9, lw=1.3, color="#222"))
    for i, pr in enumerate(PROFS):
        ax.add_patch(FancyBboxPatch((0.85 + i * 2.25, 1.25), 1.85, 0.85,
                                    boxstyle="round,pad=0.03,rounding_size=0.10",
                                    fc="none", ec=PC[i], lw=1.35))
        ax.text(1.78 + i * 2.25, 1.67, pr, ha="center", va="center",
                fontsize=8.5, color=PC[i], weight="bold")
    ax.text(6.1, 0.55, "evidence packages delivered to investigators",
            ha="center", fontsize=6.8, color="#555", style="italic")

    ax2.set_xlim(0, 6.4); ax2.set_ylim(0, 9.2); ax2.axis("off")
    ax2.text(3.1, 8.8, r"Profile lattice under $\subseteq$", ha="center",
             fontsize=8.2, weight="bold")
    labels = [r"$L_0=\{E_0\}$", r"$L_1=L_0\cup\{E_1\}$", r"$L_2=L_1\cup\{E_2\}$",
              r"$L_3=L_2\cup\{E_3\}$", r"$L_4=L_3\cup\{E_4\}$"]
    for i, lab in enumerate(labels):
        y = 1.55 + i * 1.5
        ax2.add_patch(FancyBboxPatch((0.5, y - 0.38), 4.2, 0.76,
                                     boxstyle="round,pad=0.03,rounding_size=0.10",
                                     fc=PC[i], alpha=0.14, ec=PC[i], lw=1.0))
        ax2.text(2.6, y, lab, ha="center", va="center", fontsize=8)
        if i < 4:
            ax2.add_patch(FancyArrowPatch((2.6, y + 0.40), (2.6, y + 1.10),
                                          arrowstyle="-|>", mutation_scale=8,
                                          lw=0.9, color="#666"))
    ax2.text(5.5, 4.3, "non-nested\nablations\n" + r"$A_{\neg E_2}$, $A_{\neg E_3}$",
             ha="center", va="center", fontsize=6.6, color="#888")
    ax2.text(3.1, 0.45, r"$L_m\subseteq L_n \Rightarrow \mathcal{R}^*(L_m)\leq\mathcal{R}^*(L_n)$",
             ha="center", fontsize=7.4, color="#333")
    save(fig, "fig1_evidence_model.png")


# ---------------------------------------------------------------- Figure 2
def fig_design():
    d = pd.read_csv(os.path.join(OUT, "design_assignment.csv"))
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.5),
                             gridspec_kw=dict(width_ratios=[1.5, 1, 1]))
    # panel a: assignment map, cases x investigators
    d2 = d.copy()
    d2["pi"] = d2.profile.map({p: i for i, p in enumerate(PROFS)})
    piv = d2.pivot_table(index="case_id", columns="investigator", values="pi")
    piv = piv.loc[sorted(piv.index, key=lambda s: (s[0], s))]
    cmap = matplotlib.colors.ListedColormap(PC)
    im = axes[0].imshow(piv.values, aspect="auto", cmap=cmap, vmin=-0.5, vmax=4.5,
                        interpolation="nearest")
    axes[0].set_xticks(range(len(piv.columns)), piv.columns)
    axes[0].set_xlabel("investigator")
    axes[0].set_ylabel("canonical case (grouped by family)")
    fams = [c[0] for c in piv.index]
    bounds, prev = [], fams[0]
    for i, f in enumerate(fams):
        if f != prev:
            bounds.append(i); prev = f
    for b in bounds:
        axes[0].axhline(b - 0.5, color="w", lw=0.8)
    ticks = [0] + bounds
    centres = [(ticks[i] + (ticks[i + 1] if i + 1 < len(ticks) else len(fams))) / 2
               for i in range(len(ticks))]
    axes[0].set_yticks(centres, [fams[int(t)] for t in ticks])
    axes[0].set_title("(a) assignment", fontsize=8.5)
    axes[0].grid(False)
    cb = fig.colorbar(im, ax=axes[0], ticks=range(5), pad=0.02)
    cb.ax.set_yticklabels(PROFS, fontsize=7)

    # panel b: family x profile balance
    t = d.pivot_table(index="family", columns="profile", aggfunc="size", fill_value=0)
    axes[1].imshow(t.values, cmap="Blues", vmin=0, vmax=t.values.max() * 1.4)
    for i in range(t.shape[0]):
        for j in range(t.shape[1]):
            axes[1].text(j, i, t.values[i, j], ha="center", va="center", fontsize=7)
    axes[1].set_xticks(range(5), PROFS); axes[1].set_yticks(range(len(t)), t.index)
    axes[1].set_title("(b) family $\\times$ profile", fontsize=8.5)
    axes[1].grid(False)

    # panel c: investigator x profile balance
    t2 = d.pivot_table(index="investigator", columns="profile", aggfunc="size", fill_value=0)
    axes[2].imshow(t2.values, cmap="Blues", vmin=0, vmax=t2.values.max() * 1.4)
    for i in range(t2.shape[0]):
        for j in range(t2.shape[1]):
            axes[2].text(j, i, t2.values[i, j], ha="center", va="center", fontsize=7)
    axes[2].set_xticks(range(5), PROFS); axes[2].set_yticks(range(len(t2)), t2.index)
    axes[2].set_title("(c) investigator $\\times$ profile", fontsize=8.5)
    axes[2].grid(False)
    save(fig, "fig2_design.png")


# ---------------------------------------------------------------- Figure 3
def fig_cost():
    n = pd.read_csv(os.path.join(OUT, "cost_nested.csv"))
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.4))
    x = np.arange(5)
    axes[0].bar(x, n.bytes_gz_mean / 1024, color=PC, alpha=0.9, width=0.62)
    axes[0].plot(x, n.bytes_raw_mean / 1024, "o--", color="#444", ms=3.5, lw=1,
                 label="uncompressed")
    axes[0].set_xticks(x, PROFS); axes[0].set_ylabel("KiB retained per case")
    axes[0].set_title("(a) storage cost", fontsize=8.5)
    axes[0].legend(frameon=False, loc="upper left")

    d = (n.bytes_gz_mean.diff() / 1024).values
    axes[1].bar(x[1:], d[1:], color=PC[1:], alpha=0.9, width=0.62)
    for i in range(1, 5):
        axes[1].text(i, d[i] + 0.25, f"{d[i]:.1f}", ha="center", fontsize=7)
    axes[1].set_xticks(x[1:], [f"$L_{i-1}{{\\rightarrow}}L_{i}$" for i in range(1, 5)])
    axes[1].set_ylabel("incremental KiB (gzip)")
    axes[1].set_title("(b) marginal storage cost", fontsize=8.5)

    w = 0.38
    axes[2].bar(x - w / 2, n.sens_raw_fields, w, color="#1f6f8b", label="raw-content fields")
    axes[2].bar(x + w / 2, n.sens_secret_fields, w, color="#a33b3b", label="secret-bearing fields")
    axes[2].set_xticks(x, PROFS); axes[2].set_ylabel("fields per case")
    axes[2].set_title("(c) privacy exposure", fontsize=8.5)
    axes[2].legend(frameon=False, fontsize=7)
    save(fig, "fig3_cost.png")


# ---------------------------------------------------------------- Figure 4
def fig_frontier():
    sys.path.insert(0, HERE)
    from power import SCEN, BASE_N, FAMS
    from metrics import marginal_forensic_value
    n = pd.read_csv(os.path.join(OUT, "cost_nested.csv"))
    w = np.array([BASE_N[f] for f in FAMS], float); w /= w.sum()
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.7))
    for ax, scen, ttl in [(axes[0], "S1_true_L3", "(a) scenario S1 (true $L^*=L_3$)"),
                          (axes[1], "S3_true_L4", "(b) scenario S3 (true $L^*=L_4$)")]:
        P = np.array([SCEN[scen][f] for f in FAMS])
        pm = w @ P
        r = marginal_forensic_value(pm, n.bytes_gz_mean.values, n.sens_raw_fields.values
                                    + n.sens_secret_fields.values)
        C = r["composite_cost"]
        ax.plot(C, pm, "-", color="#999", lw=1, zorder=1)
        for i in range(5):
            ax.scatter(C[i], pm[i], s=70, color=PC[i], zorder=3,
                       edgecolor="w", linewidth=0.8)
            ax.annotate(PROFS[i], (C[i], pm[i]), textcoords="offset points",
                        xytext=(6, -9), fontsize=8, color=PC[i])
        ax.axhline(0.90, color="#a33b3b", ls=":", lw=1)
        ax.text(0.02, 0.905, "absolute requirement", fontsize=6.8, color="#a33b3b")
        ax.set_xlabel("composite cost  $C_n$  (bytes + sensitive fields, normalised)")
        ax.set_ylabel("marginal source-attribution")
        ax.set_ylim(0, 1.02)
        ax.set_title(ttl, fontsize=8.5)
    fig.text(0.5, -0.06, "Design calculation under the frozen elicited scenarios; "
             "not an empirical result.", ha="center", fontsize=7, style="italic",
             color="#666")
    save(fig, "fig4_frontier.png")


# ---------------------------------------------------------------- Figure 5
def fig_precision():
    oc = pd.read_csv(os.path.join(OUT, "sizing_oc.csv"))
    s = (oc[oc.margin == 0.10].groupby(["N", "k"], as_index=False)
         .agg(se=("se_RD", "mean"), npp=("n_per_profile", "first")))
    fig, ax = plt.subplots(figsize=(3.5, 2.6))
    for k, mk in [(3, "o-"), (5, "s--")]:
        g = s[s.k == k].sort_values("N")
        if len(g):
            ax.plot(g.N, g.se, mk, color=PC[1] if k == 3 else PC[3], ms=4, lw=1.2,
                    label=f"$k={k}$ investigators")
    for m, c, lab in [(0.10, "#2e8b6f", r"$\Delta=0.10$"), (0.05, "#a33b3b", r"$\Delta=0.05$")]:
        ax.axhline(m / 2.487, color=c, ls=":", lw=1.1)
        ax.text(ax.get_xlim()[1], m / 2.487, f"  80% power, {lab}", fontsize=6.8,
                color=c, va="center")
    ax.set_xlabel("canonical cases $N$"); ax.set_ylabel(r"SE of $\widehat{RD}(L_3,L_4)$")
    ax.legend(frameon=False)
    ax.set_title("Achieved precision vs design size", fontsize=9)
    save(fig, "fig5_precision.png")


# ---------------------------------------------------------------- Figure 6
def fig_oc():
    oc = pd.read_csv(os.path.join(OUT, "sizing_oc.csv"))
    oc = oc[oc.margin == 0.10]
    designs = [(80, 3), (160, 5), (320, 3)]
    designs = [d for d in designs if ((oc.N == d[0]) & (oc.k == d[1])).any()]
    scens = ["S4_true_L1", "S2_true_L2", "S1_true_L3", "S3_true_L4", "S0_true_none"]
    fig, axes = plt.subplots(1, len(designs), figsize=(7.2, 2.8), sharey=True)
    if len(designs) == 1:
        axes = [axes]
    cols = PC + ["#888888"]
    labs = PROFS + ["abstain"]
    for ax, (N, k) in zip(axes, designs):
        sub = oc[(oc.N == N) & (oc.k == k)].set_index("scenario").loc[scens]
        bottom = np.zeros(len(scens))
        for i, lab in enumerate(labs):
            v = sub[f"sel_{lab}"].values
            ax.bar(range(len(scens)), v, 0.68, bottom=bottom, color=cols[i],
                   label=lab if (N, k) == designs[0] else None,
                   edgecolor="w", linewidth=0.4)
            bottom += v
        for j, sc in enumerate(scens):
            ax.scatter(j, sub.p_correct.values[j], marker="_", s=260, color="k",
                       linewidth=1.6, zorder=5)
        ax.set_xticks(range(len(scens)),
                      [s.split("_")[-1] for s in scens], rotation=0)
        ax.set_title(f"$N={N}$, $k={k}$", fontsize=8.5)
        ax.set_ylim(0, 1); ax.grid(axis="x", visible=False)
    axes[0].set_ylabel("P(rule returns profile)")
    axes[0].set_xlabel("true minimum profile")
    fig.legend(loc="upper center", bbox_to_anchor=(0.5, 1.13), ncol=6,
               frameon=False)
    fig.text(0.5, -0.09, "Black dash marks the correct answer. "
             "Design calculation at margin $\\Delta=0.10$.",
             ha="center", fontsize=7, style="italic", color="#666")
    save(fig, "fig6_operating_characteristics.png")


# ---------------------------------------------------------------- Figure 7
def fig_correctness():
    oc = pd.read_csv(os.path.join(OUT, "sizing_oc.csv"))
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.6), sharey=True)
    for ax, m in zip(axes, [0.10, 0.05]):
        sub = oc[oc.margin == m]
        if not len(sub):
            continue
        for k, mk, c in [(3, "o-", PC[1]), (5, "s--", PC[3])]:
            g = (sub[(sub.k == k) & (sub.scenario != "S0_true_none")]
                 .groupby("N", as_index=False).p_correct.mean().sort_values("N"))
            if len(g):
                ax.plot(g.N, g.p_correct, mk, color=c, ms=4, lw=1.2, label=f"$k={k}$")
        ax.axhline(0.8, color="#a33b3b", ls=":", lw=1)
        ax.set_xlabel("canonical cases $N$")
        ax.set_title(f"non-inferiority margin $\\Delta={m}$", fontsize=8.5)
    axes[0].set_ylabel("P(correct minimum profile)")
    axes[0].legend(frameon=False)
    axes[0].set_ylim(0, 1)
    save(fig, "fig7_selection_power.png")


# ---------------------------------------------------------------- Figure 8
def fig_prs():
    ex = pd.read_csv(os.path.join(OUT, "prs_worked_example.csv"))
    fig, ax = plt.subplots(figsize=(4.6, 2.5))
    y = np.arange(len(ex))[::-1]
    ax.barh(y, ex.PRS, 0.55, color=[PC[4], PC[3], PC[2], PC[1], PC[1], PC[0]])
    for i, (v, cov, pr, ka) in enumerate(zip(ex.PRS, ex.coverage, ex.precision, ex.kappa)):
        ax.text(v + 0.015, y[i], f"$\\rho$={cov:.2f} $\\pi$={pr:.2f} $\\kappa$={ka:.2f}",
                va="center", fontsize=6.3, color="#444")
    short = [s.split("(")[0].strip() + "\n(" + s.split("(")[1] for s in ex.scenario]
    ax.set_yticks(y, short, fontsize=6.3)
    ax.set_xlim(0, 1.45); ax.set_xticks(np.arange(0, 1.01, 0.25))
    ax.set_xlabel("Path Reconstruction Score")
    ax.set_title("Behaviour of the PRS on a worked five-step incident", fontsize=8.5)
    save(fig, "fig8_prs.png")


if __name__ == "__main__":
    which = sys.argv[1:] or ["1", "2", "3", "4", "5", "6", "7", "8"]
    fns = {"1": fig_evidence_lattice, "2": fig_design, "3": fig_cost,
           "4": fig_frontier, "5": fig_precision, "6": fig_oc,
           "7": fig_correctness, "8": fig_prs}
    for w in which:
        try:
            fns[w]()
        except Exception as e:
            print("FAILED fig", w, type(e).__name__, e)
