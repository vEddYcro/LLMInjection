"""
stats_core.py -- Statistical engine for the MFLP evidence-ablation study.

Two estimators, matching the two estimands defined in the protocol:

(a) glmm_pql : conditional (subject-specific) logistic model with crossed random
    intercepts for canonical case and investigator, fitted by penalised
    quasi-likelihood.  Used for the RQ1 successive-difference contrasts on the
    logit scale, delta_n = alpha_{L_n} - alpha_{L_{n-1}}.

(b) marginal_rd : population-averaged risk difference RD_n = P(Y|L_n) - P(Y|L4)
    from a saturated identity-link model with investigator fixed effects and a
    CR2 bias-reduced cluster-robust variance clustered on canonical case.  Used
    for the confirmatory non-inferiority test and the MFLP selection rule,
    because the selection criterion is stated on the probability scale.

With only three investigators the investigator term is fixed in (b); clustering
on a 3-level grouping would be invalid.
"""
import numpy as np
from scipy import optimize, stats

LOGIT = lambda p: np.log(p / (1 - p))
EXPIT = lambda x: 1.0 / (1.0 + np.exp(-x))


# -------------------------------------------------- GLMM (PQL), fast version
def _blocks(group):
    lev, inv = np.unique(group, return_inverse=True)
    order = np.argsort(inv, kind="stable")
    starts = np.searchsorted(inv[order], np.arange(len(lev)))
    ends = np.append(starts[1:], len(order))
    return [order[s:e] for s, e in zip(starts, ends)]


def _reml_nll_block(logs2, X, z, W, blocks):
    """REML profile deviance for V = s2*Z Z' + diag(1/W) with a single
    random intercept; exploits block-diagonality (Woodbury per block)."""
    s2 = float(np.exp(logs2))
    p = X.shape[1]
    XtViX = np.zeros((p, p)); XtViz = np.zeros(p); ztViz = 0.0
    logdetV = 0.0
    for idx in blocks:
        w = W[idx]; Xc = X[idx]; zc = z[idx]
        sw = w.sum(); den = 1.0 + s2 * sw
        # V_c^{-1} x = w*x - s2*w*(w.x)/den
        def Vi(M):
            wm = (w[:, None] * M) if M.ndim == 2 else w * M
            s = (w @ M)
            return wm - s2 * np.outer(w, s) / den if M.ndim == 2 else wm - s2 * w * s / den
        ViX = Vi(Xc); Viz = Vi(zc)
        XtViX += Xc.T @ ViX; XtViz += Xc.T @ Viz; ztViz += zc @ Viz
        logdetV += -np.log(w).sum() + np.log(den)
    try:
        Lx = np.linalg.cholesky(XtViX)
    except np.linalg.LinAlgError:
        return 1e12, None, None
    beta = np.linalg.solve(XtViX, XtViz)
    quad = ztViz - XtViz @ beta
    nll = 0.5 * (logdetV + 2 * np.sum(np.log(np.diag(Lx))) + quad)
    return nll, beta, np.linalg.inv(XtViX)


def glmm_pql_ri(y, X, group, maxit=15, tol=1e-6):
    """Binomial(logit) GLMM with ONE random intercept (canonical case).
    Investigator is carried as fixed effects inside X, because three levels
    cannot identify a variance component."""
    blocks = _blocks(np.asarray(group))
    n, p = X.shape
    beta = np.zeros(p)
    beta[0] = LOGIT(np.clip(y.mean(), 1e-3, 1 - 1e-3))
    b = np.zeros(len(blocks))
    logs2 = np.log(0.5)
    vcov = np.eye(p)
    bexp = np.zeros(n)
    for it in range(maxit):
        eta = np.clip(X @ beta + bexp, -12, 12)
        mu = EXPIT(eta)
        W = np.clip(mu * (1 - mu), 1e-6, None)
        z = eta + (y - mu) / W
        r = optimize.minimize_scalar(
            lambda ls: _reml_nll_block(ls, X, z, W, blocks)[0],
            bounds=(-8.0, 3.0), method="bounded",
            options=dict(xatol=1e-3, maxiter=40))
        logs2 = float(r.x)
        _, beta_new, vcov = _reml_nll_block(logs2, X, z, W, blocks)
        if beta_new is None:
            break
        s2 = np.exp(logs2)
        res = z - X @ beta_new
        bexp = np.zeros(n)
        for j, idx in enumerate(blocks):
            w = W[idx]; sw = w.sum()
            bj = s2 * (w @ res[idx]) / (1.0 + s2 * sw)
            b[j] = bj; bexp[idx] = bj
        d = np.max(np.abs(beta_new - beta))
        beta = beta_new
        if d < tol:
            break
    return dict(beta=beta, vcov=vcov, sigma=float(np.sqrt(np.exp(logs2))),
                n_iter=it + 1)


# ------------------------------------- GLMM by exact Gauss-Hermite quadrature
def glmm_gh(y, X, group, nodes=20, start=None):
    """Binomial(logit) GLMM with one random intercept, fitted by maximising the
    exact marginal likelihood with `nodes`-point Gauss-Hermite quadrature.

    With three-observation blocks the quadrature is effectively exact, so this
    avoids the downward bias that penalised quasi-likelihood shows for binary
    responses.  Returns beta, observed-information covariance, and sigma.
    """
    y = np.asarray(y, float)
    g = np.asarray(group)
    _, inv = np.unique(g, return_inverse=True)
    order = np.argsort(inv, kind="stable")
    yo, Xo, io = y[order], X[order], inv[order]
    seg = np.searchsorted(io, np.arange(io.max() + 1))
    x, w = np.polynomial.hermite.hermgauss(nodes)
    t = np.sqrt(2.0) * x
    lw = np.log(w / np.sqrt(np.pi))
    p = X.shape[1]

    def nll(par):
        beta, ls = par[:p], par[p]
        sig = np.exp(ls)
        eta = (Xo @ beta)[:, None] + sig * t[None, :]
        eta = np.clip(eta, -30, 30)
        # log Bernoulli pmf
        ll = yo[:, None] * eta - np.logaddexp(0.0, eta)
        blocksum = np.add.reduceat(ll, seg, axis=0)          # (ncase, nodes)
        m = blocksum + lw[None, :]
        mx = m.max(axis=1, keepdims=True)
        lse = (mx[:, 0] + np.log(np.exp(m - mx).sum(axis=1)))
        return -lse.sum()

    if start is None:
        start = np.zeros(p + 1)
        start[0] = LOGIT(np.clip(y.mean(), 1e-3, 1 - 1e-3))
        start[p] = np.log(0.7)
    res = optimize.minimize(nll, start, method="L-BFGS-B",
                            options=dict(maxiter=500, ftol=1e-10))
    par = res.x
    # observed information by central differences
    h = 1e-4
    H = np.zeros((p + 1, p + 1))
    f0 = nll(par)
    for i in range(p + 1):
        for j in range(i, p + 1):
            ei = np.zeros(p + 1); ei[i] = h
            ej = np.zeros(p + 1); ej[j] = h
            fpp = nll(par + ei + ej); fpm = nll(par + ei - ej)
            fmp = nll(par - ei + ej); fmm = nll(par - ei - ej)
            H[i, j] = H[j, i] = (fpp - fpm - fmp + fmm) / (4 * h * h)
    try:
        cov = np.linalg.inv(H)
    except np.linalg.LinAlgError:
        cov = np.linalg.pinv(H)
    return dict(beta=par[:p], vcov=cov[:p, :p], sigma=float(np.exp(par[p])),
                loglik=-f0, converged=bool(res.success))


# ------------------------------------------------- generic dense PQL (legacy)
def _reml_nll(logsig, X, z, W, Zs):
    sig2 = np.exp(2 * np.asarray(logsig))
    n = len(z)
    V = np.diag(1.0 / W)
    for s2, Z in zip(sig2, Zs):
        V += s2 * (Z @ Z.T)
    try:
        L = np.linalg.cholesky(V)
    except np.linalg.LinAlgError:
        return 1e12
    Vi_X = np.linalg.solve(V, X)
    Vi_z = np.linalg.solve(V, z)
    XtViX = X.T @ Vi_X
    try:
        Lx = np.linalg.cholesky(XtViX)
    except np.linalg.LinAlgError:
        return 1e12
    beta = np.linalg.solve(XtViX, X.T @ Vi_z)
    r = z - X @ beta
    quad = r @ np.linalg.solve(V, r)
    logdetV = 2 * np.sum(np.log(np.diag(L)))
    logdetXtViX = 2 * np.sum(np.log(np.diag(Lx)))
    return 0.5 * (logdetV + logdetXtViX + quad)


def glmm_pql(y, X, group_arrays, maxit=25, tol=1e-6):
    """Binomial(logit) GLMM with independent crossed random intercepts.

    group_arrays : list of integer arrays, one per random-effect grouping.
    Returns dict with beta, vcov(beta), sigma (sd per grouping), n_iter.
    """
    n, p = X.shape
    Zs = []
    for g in group_arrays:
        lev = np.unique(g)
        Z = np.zeros((n, len(lev)))
        Z[np.arange(n), np.searchsorted(lev, g)] = 1.0
        Zs.append(Z)

    beta = np.zeros(p)
    beta[0] = LOGIT(np.clip(y.mean(), 1e-3, 1 - 1e-3))
    b = [np.zeros(Z.shape[1]) for Z in Zs]
    logsig = np.log(np.array([0.5] * len(Zs)))

    for it in range(maxit):
        eta = X @ beta + sum(Z @ bb for Z, bb in zip(Zs, b))
        eta = np.clip(eta, -12, 12)
        mu = EXPIT(eta)
        W = np.clip(mu * (1 - mu), 1e-6, None)
        z = eta + (y - mu) / W

        res = optimize.minimize(_reml_nll, logsig, args=(X, z, W, Zs),
                                method="Nelder-Mead",
                                options=dict(xatol=1e-4, fatol=1e-4, maxiter=300))
        logsig_new = res.x
        sig2 = np.exp(2 * logsig_new)

        V = np.diag(1.0 / W)
        for s2, Z in zip(sig2, Zs):
            V += s2 * (Z @ Z.T)
        Vi = np.linalg.inv(V)
        XtViX = X.T @ Vi @ X
        vcov = np.linalg.inv(XtViX)
        beta_new = vcov @ (X.T @ Vi @ z)
        r = z - X @ beta_new
        b_new = [s2 * (Z.T @ (Vi @ r)) for s2, Z in zip(sig2, Zs)]

        d = np.max(np.abs(beta_new - beta))
        beta, b, logsig = beta_new, b_new, logsig_new
        if d < tol:
            break
    return dict(beta=beta, vcov=vcov, sigma=np.exp(logsig), n_iter=it + 1)


def wald(beta, vcov, L):
    """Two-sided Wald test for contrast L'beta = 0."""
    est = L @ beta
    se = np.sqrt(max(float(L @ vcov @ L), 1e-12))
    zst = est / se
    return est, se, zst, 2 * stats.norm.sf(abs(zst))


# ------------------------------------------- marginal RD, CR2 cluster-robust
def marginal_rd(y, D, cluster, ref_col):
    """Saturated identity-link (linear probability) fit of y on design D,
    with CR2 bias-reduced cluster-robust covariance.

    D must contain profile indicators (all 5, no intercept) plus investigator
    contrasts. Returns estimates of theta and the CR2 covariance; RD contrasts
    are taken afterwards against column `ref_col` (the L4 indicator).
    """
    XtX_inv = np.linalg.pinv(D.T @ D)
    theta = XtX_inv @ (D.T @ y)
    resid = y - D @ theta
    H = D @ XtX_inv @ D.T

    meat = np.zeros((D.shape[1], D.shape[1]))
    for c in np.unique(cluster):
        idx = np.where(cluster == c)[0]
        Dc, rc = D[idx], resid[idx]
        Hcc = H[np.ix_(idx, idx)]
        # CR2 adjustment: A_c = (I - H_cc)^{-1/2}
        M = np.eye(len(idx)) - Hcc
        w, Vv = np.linalg.eigh((M + M.T) / 2)
        w = np.clip(w, 1e-10, None)
        A = Vv @ np.diag(w ** -0.5) @ Vv.T
        u = Dc.T @ (A @ rc)
        meat += np.outer(u, u)
    vcov = XtX_inv @ meat @ XtX_inv
    return theta, vcov


def ni_test(theta, vcov, idx_test, idx_ref, margin, alpha=0.05):
    """One-sided non-inferiority test of profile idx_test vs idx_ref.
    H0: RD <= -margin ; conclude non-inferiority if lower confidence bound > -margin.
    Satterthwaite-free normal approximation; df supplied by caller if needed.
    """
    L = np.zeros(len(theta)); L[idx_test] = 1.0; L[idx_ref] = -1.0
    est = L @ theta
    se = np.sqrt(max(L @ vcov @ L, 1e-12))
    lcb = est - stats.norm.ppf(1 - alpha) * se
    return est, se, lcb, bool(lcb > -margin)
