"""
power.py -- Monte Carlo power analysis and operating characteristics for the
MFLP evidence-ablation study.

Everything here is a *design calculation*.  The probability matrices below are
elicited design assumptions used to size the study; they are not predictions of
the empirical result and are frozen in the protocol before data collection.

Produces:
  out/power_contrasts.csv        power for the RQ1/RQ2/RQ3 contrasts at N=80,k=3
  out/power_size.csv             empirical size under the flat (null) scenario
  out/power_curve_cases.csv      power vs number of canonical cases
  out/power_curve_inv.csv        power vs number of investigators
  out/mflp_operating_char.csv    P(selected profile = L*) under four scenarios
"""
import json, os, sys
import numpy as np
import pandas as pd
from scipy import optimize, stats

sys.path.insert(0, os.path.dirname(__file__))
from stats_core import glmm_gh, wald, marginal_rd, ni_test, LOGIT, EXPIT

OUT = os.path.join(os.path.dirname(__file__), "..", "out")
PROFILES = ["L0", "L1", "L2", "L3", "L4"]
SEL_LABELS = PROFILES + ["abstain"]
FAMS = ["D", "I", "R", "T", "X", "F", "B"]
BASE_N = {"D": 10, "I": 10, "R": 10, "T": 10, "X": 10, "F": 10, "B": 20}

SIGMA_CASE = 0.80      # logit-scale sd of canonical-case difficulty
SIGMA_INV = 0.35       # logit-scale sd of investigator skill
NI_MARGIN = 0.10       # primary non-inferiority margin (risk difference)
NI_MARGIN_SENS = 0.05  # sensitivity margin
ABS_THRESH = 0.90      # absolute marginal source-attribution requirement
GLMM_SIMS = 400        # GLMM refit on the first GLMM_SIMS replicates only

# ---- elicited marginal (population-averaged) success probabilities ---------
# rows = family, cols = L0..L4.  These are frozen design assumptions used to
# size the study and to characterise the operating behaviour of the MFLP
# selection rule.  They are NOT predictions of the empirical result.  Five
# scenarios are used, with five distinct correct answers, so that the rule can
# be shown to recover the right profile and to abstain when it should.
SCEN = {}

# S1: retrieval provenance AND tool telemetry both needed; E4 adds little on
#     average but is decisive for exfiltration.  (H1 + H2 + H3 as stated.)
SCEN["S1_true_L3"] = {
    "D": [0.20, 0.92, 0.94, 0.96, 0.96],
    "I": [0.10, 0.35, 0.90, 0.94, 0.95],
    "R": [0.08, 0.25, 0.88, 0.93, 0.94],
    "T": [0.08, 0.30, 0.45, 0.93, 0.94],
    "X": [0.10, 0.30, 0.50, 0.85, 0.95],
    "F": [0.15, 0.55, 0.80, 0.90, 0.92],
    "B": [0.70, 0.85, 0.90, 0.94, 0.95],
}
# S2: retrieval provenance alone is sufficient; tool telemetry adds little.
SCEN["S2_true_L2"] = {
    "D": [0.20, 0.92, 0.95, 0.96, 0.96],
    "I": [0.10, 0.35, 0.93, 0.94, 0.95],
    "R": [0.08, 0.25, 0.92, 0.93, 0.94],
    "T": [0.08, 0.30, 0.92, 0.93, 0.94],
    "X": [0.10, 0.30, 0.90, 0.92, 0.94],
    "F": [0.15, 0.55, 0.90, 0.91, 0.92],
    "B": [0.70, 0.85, 0.94, 0.94, 0.95],
}
# S3: nothing below the full profile is sufficient.
SCEN["S3_true_L4"] = {
    "D": [0.18, 0.60, 0.68, 0.75, 0.93],
    "I": [0.08, 0.22, 0.55, 0.65, 0.91],
    "R": [0.07, 0.18, 0.52, 0.62, 0.90],
    "T": [0.07, 0.20, 0.30, 0.62, 0.90],
    "X": [0.08, 0.20, 0.32, 0.55, 0.92],
    "F": [0.12, 0.40, 0.55, 0.66, 0.89],
    "B": [0.65, 0.78, 0.83, 0.86, 0.92],
}
# S4: prompt/response logging alone already suffices -- tests over-selection.
SCEN["S4_true_L1"] = {
    "D": [0.20, 0.95, 0.96, 0.96, 0.96],
    "I": [0.10, 0.92, 0.93, 0.94, 0.95],
    "R": [0.08, 0.91, 0.92, 0.93, 0.94],
    "T": [0.08, 0.92, 0.93, 0.93, 0.94],
    "X": [0.10, 0.90, 0.91, 0.92, 0.94],
    "F": [0.15, 0.90, 0.90, 0.91, 0.92],
    "B": [0.70, 0.94, 0.94, 0.94, 0.95],
}
# S0: flat -- no profile effect and no profile adequate; the rule must ABSTAIN.
SCEN["S0_true_none"] = {f: [0.72] * 5 for f in FAMS}


# --------------------------------------------------------------- design
def make_design(n_per_fam, k_inv, rng):
    """Exactly balanced case x investigator assignment.

    Within each family, case i and investigator j are assigned profile
    sigma((i + j) mod 5), where sigma is a random relabelling of the five
    profiles drawn once per family.  Because i runs over a multiple of five
    cases, every (investigator, profile) cell within a family receives exactly
    m/5 cases, and every case is seen once by each investigator at k distinct
    profiles.  This reproduces the balance properties of the explicit
    3-subset construction in design.py for any k <= 5.
    """
    if not 1 <= k_inv <= 5:
        raise ValueError("k_inv must be between 1 and 5.")
    rows, cid = [], 0
    for f in FAMS:
        m = int(round(n_per_fam[f] / 5.0)) * 5          # force multiple of five
        sigma = list(rng.permutation(5))
        for i in range(m):
            cid += 1
            for j in range(k_inv):
                rows.append((cid, f, j, sigma[(i + j) % 5]))
    return pd.DataFrame(rows, columns=["case", "family", "inv", "prof"])


def solve_theta(p_marg, sig_tot):
    """Find conditional logit theta such that E_u[expit(theta+u)] = p_marg."""
    gh_x, gh_w = np.polynomial.hermite.hermgauss(40)
    nodes = np.sqrt(2) * sig_tot * gh_x
    wts = gh_w / np.sqrt(np.pi)

    def f(th):
        return float(np.sum(wts * EXPIT(th + nodes)) - p_marg)
    return optimize.brentq(f, -25, 25)


def theta_matrix(scen):
    sig_tot = np.sqrt(SIGMA_CASE ** 2 + SIGMA_INV ** 2)
    return {f: np.array([solve_theta(p, sig_tot) for p in row])
            for f, row in scen.items()}


# --------------------------------------------------------------- simulation
def simulate(des, TH, rng):
    ncase = des.case.max()
    u = rng.normal(0, SIGMA_CASE, ncase + 1)
    v = rng.normal(0, SIGMA_INV, des.inv.max() + 1)
    eta = np.array([TH[f][p] for f, p in zip(des.family, des.prof)])
    eta = eta + u[des.case.values] + v[des.inv.values]
    return (rng.random(len(des)) < EXPIT(eta)).astype(float)


def build_matrices(des):
    """Return (Xg, Dm).

    Xg : GLMM design -- intercept, four backward-difference profile columns,
         family contrasts, investigator contrasts.
    Dm : marginal design -- five profile indicators only.  Because the
         assignment is exactly balanced over families and investigators, the
         unadjusted profile cell means are unbiased for the marginal success
         probabilities, so no covariate adjustment is needed and none is
         applied; adjustment with a linear link would otherwise absorb part of
         the profile x family interaction into the profile coefficients.
    """
    n = len(des)
    P = np.zeros((n, 5)); P[np.arange(n), des.prof.values] = 1.0
    fams = sorted(des.family.unique())
    F = np.zeros((n, len(fams) - 1))
    for j, f in enumerate(fams[1:]):
        F[:, j] = (des.family.values == f).astype(float)
    invs = sorted(des.inv.unique())
    I = np.zeros((n, max(len(invs) - 1, 0)))
    for j, q in enumerate(invs[1:]):
        I[:, j] = (des.inv.values == q).astype(float)
    S = np.zeros((n, 4))
    for j in range(4):
        S[:, j] = (des.prof.values > j).astype(float)   # backward-difference coding
    Xg = np.hstack([np.ones((n, 1)), S, F, I])
    Dm = P
    return Xg, Dm


def mflp_select(theta, vcov, margin=NI_MARGIN, abs_thresh=ABS_THRESH, alpha=0.05):
    """Frozen MFLP selection rule.

    Step 1 (feasibility gate).  If the full profile L4 does not itself meet the
    absolute performance requirement -- point estimate of the
    marginal success probability at or above `abs_thresh` -- no minimum profile is
    issued.  The study then reports evidence-taxonomy validation only.  This
    implements the pre-registered "do not force an MFLP claim" rule.

    Step 2 (selection).  Otherwise L* is the smallest profile that is both
    non-inferior to L4 within `margin` and meets the absolute point-estimate requirement. Non-inferiority is
    judged by a one-sided lower confidence bound; adequacy is a feasibility screen.

    Returns 0..4 for L0..L4, or 5 for "abstain".
    """
    z = stats.norm.ppf(1 - alpha)

    def lcb(i):
        return theta[i] - z * np.sqrt(max(vcov[i, i], 1e-12))

    if theta[4] < abs_thresh:
        return 5
    for L in range(5):
        _, _, l_ni, ni_ok = ni_test(theta, vcov, L, 4, margin, alpha)
        if ni_ok and theta[L] >= abs_thresh:
            return L
    return 4


# --------------------------------------------------------------- experiments
def run_contrast_power(nsim, scen_name, n_per_fam, k_inv, seed, do_glmm=True):
    rng = np.random.default_rng(seed)
    TH = theta_matrix(SCEN[scen_name])
    des = make_design(n_per_fam, k_inv, np.random.default_rng(seed + 1))
    Xg, Dm = build_matrices(des)
    cl = des.case.values

    # family-restricted designs for RQ2 contrasts
    sub = {"IR": des.family.isin(["I", "R"]).values,
           "T": (des.family == "T").values,
           "X": (des.family == "X").values}

    hits = {f"delta{j+1}": 0 for j in range(4)}
    hits.update({"H2a_E2_in_IR": 0, "H2b_E3_in_T": 0, "H3_E4_in_X": 0})
    ni_hits = {f"NI_{PROFILES[L]}": 0 for L in range(4)}
    sel = np.zeros(6)
    glmm_fail = 0

    for s in range(nsim):
        y = simulate(des, TH, rng)
        # marginal model -> NI tests + selection rule
        try:
            th, vc = marginal_rd(y, Dm, cl, ref_col=4)
        except np.linalg.LinAlgError:
            continue
        for L in range(4):
            _, _, _, ok = ni_test(th, vc, L, 4, NI_MARGIN)
            ni_hits[f"NI_{PROFILES[L]}"] += ok
        sel[mflp_select(th, vc)] += 1

        # family-restricted marginal contrasts (RQ2 / H2 / H3)
        for key, mask, a, b in [("H2a_E2_in_IR", sub["IR"], 1, 2),
                                ("H2b_E3_in_T", sub["T"], 2, 3),
                                ("H3_E4_in_X", sub["X"], 3, 4)]:
            ys, Ds, cs = y[mask], Dm[mask], cl[mask]
            keep = Ds.sum(0) > 0
            try:
                t2, v2 = marginal_rd(ys, Ds[:, keep], cs, ref_col=None)
            except np.linalg.LinAlgError:
                continue
            cols = np.where(keep)[0]
            if a not in cols or b not in cols:
                continue
            ia, ib = int(np.where(cols == a)[0][0]), int(np.where(cols == b)[0][0])
            Lv = np.zeros(len(t2)); Lv[ib] = 1; Lv[ia] = -1
            est = Lv @ t2
            se = np.sqrt(max(Lv @ v2 @ Lv, 1e-12))
            hits[key] += (est / se > stats.norm.ppf(0.975))

        if do_glmm and s < GLMM_SIMS:
            try:
                fit = glmm_gh(y, Xg, des.case.values)
                for j in range(4):
                    Lv = np.zeros(len(fit["beta"])); Lv[1 + j] = 1.0
                    _, _, _, p = wald(fit["beta"], fit["vcov"], Lv)
                    hits[f"delta{j+1}"] += (p < 0.05)
            except Exception:
                glmm_fail += 1

    n_ok = nsim
    res = dict(scenario=scen_name, n_cases=int(sum(n_per_fam.values())),
               k_inv=k_inv, nsim=nsim, glmm_fail=glmm_fail)
    # Normalize GLMM-based contrasts over successful GLMM fits; use NaN when
    # GLMM refitting was intentionally skipped so downstream output cannot
    # mistake "not computed" for zero power.
    glmm_den = max(min(GLMM_SIMS, nsim) - glmm_fail, 1)
    for j in range(4):
        key=f"delta{j+1}"
        hits[key] = (hits[key] / glmm_den * n_ok) if do_glmm else np.nan
    res.update({k: (v / n_ok if not (isinstance(v, float) and np.isnan(v)) else np.nan)
                for k, v in hits.items()})
    res.update({k: v / n_ok for k, v in ni_hits.items()})
    for L in range(5):
        res[f"sel_{PROFILES[L]}"] = sel[L] / n_ok
    res["sel_abstain"] = sel[5] / n_ok
    return res


def true_optimum(scen_name, n_per_fam=BASE_N):
    """The profile a perfectly-informed decision maker would select under the
    scenario's true marginal probabilities: smallest L with
    p_L >= p_L4 - margin AND p_L >= abs_thresh."""
    scen = SCEN[scen_name]
    w = np.array([n_per_fam[f] for f in FAMS], float); w /= w.sum()
    P = np.array([scen[f] for f in FAMS])          # 7 x 5
    pm = w @ P                                      # marginal by profile
    if pm[4] < ABS_THRESH:
        return 5, pm
    for L in range(5):
        if pm[L] >= pm[4] - NI_MARGIN and pm[L] >= ABS_THRESH:
            return L, pm
    return 4, pm


def main():
    os.makedirs(OUT, exist_ok=True)
    nsim = int(os.environ.get("NSIM", 1500))

    # (0) true optima and marginal probability profile per scenario
    trows = []
    for scen in SCEN:
        Lstar, pm = true_optimum(scen)
        trows.append(dict(scenario=scen, true_Lstar=SEL_LABELS[Lstar],
                          **{f"p_{PROFILES[i]}": round(float(pm[i]), 4) for i in range(5)}))
    pd.DataFrame(trows).to_csv(os.path.join(OUT, "scenario_truth.csv"), index=False)
    print(pd.DataFrame(trows).to_string(index=False), flush=True)

    # (1) main power table + empirical size, N=80, k=3
    rows = []
    for scen in ["S4_true_L1", "S2_true_L2", "S1_true_L3",
                 "S3_true_L4", "S0_true_none"]:
        r = run_contrast_power(nsim, scen, BASE_N, 3, seed=101, do_glmm=True)
        rows.append(r)
        pd.DataFrame(rows).to_csv(os.path.join(OUT, "power_contrasts.csv"), index=False)
        print(scen, {k: round(v, 3) for k, v in r.items() if isinstance(v, float)}, flush=True)

    # (2) power curve vs number of cases (k=3, scenario S1)
    curve = []
    for scale in [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]:
        npf = {f: max(4, int(round(n * scale))) for f, n in BASE_N.items()}
        r = run_contrast_power(nsim, "S1_true_L3", npf, 3,
                               seed=202, do_glmm=False)
        curve.append(r)
        pd.DataFrame(curve).to_csv(os.path.join(OUT, "power_curve_cases.csv"), index=False)
        print("cases", sum(npf.values()), "NI_L3", round(r["NI_L3"], 3),
              "H2b", round(r["H2b_E3_in_T"], 3), flush=True)

    # (3) power curve vs number of investigators (N=80, scenario S1)
    curve2 = []
    for k in [2, 3, 4, 5]:
        r = run_contrast_power(nsim, "S1_true_L3", BASE_N, k,
                               seed=303, do_glmm=False)
        curve2.append(r)
        pd.DataFrame(curve2).to_csv(os.path.join(OUT, "power_curve_inv.csv"), index=False)
        print("inv", k, "NI_L3", round(r["NI_L3"], 3),
              "H2a", round(r["H2a_E2_in_IR"], 3), flush=True)
    print("done", flush=True)


if __name__ == "__main__":
    main()
