"""
design.py -- Balanced incomplete-block / cyclic assignment for the MFLP study.

Default confirmatory design:
    160 canonical cases x 5 investigators = 800 blinded evaluations.

Each investigator sees each canonical case exactly once, and never sees the same
canonical case under more than one profile. With k=5, the five investigators
collectively cover all five profiles for every case. Within each attack family,
investigator x profile and family x profile counts are exactly balanced when the
family size is a multiple of five.

Outputs are written relative to this package, never to machine-specific paths.
"""
from __future__ import annotations
import argparse, json, os, random
from pathlib import Path
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
OUT = (HERE / ".." / "out").resolve()
PROFILES = ["L0", "L1", "L2", "L3", "L4", "A_noE2", "A_noE3"]
N_PROF = len(PROFILES)
SEED = 20260911

# Primary 160-case journal design (scaled 2x from the 80-case baseline).
DEFAULT_FAMILIES = {"D": 21, "I": 21, "R": 21, "T": 21, "X": 21, "F": 21, "B": 42}


def build_design(families=None, k_inv=N_PROF, seed=SEED):
    """Construct an exactly balanced cyclic design.

    Parameters
    ----------
    families : dict[str, int]
        Number of canonical cases per family. Every count must be a positive
        multiple of 5.
    k_inv : int
        Number of investigators, 1..5. A case receives k_inv distinct profiles.
    seed : int
        Seed used only for the per-family random relabelling of profiles.
    """
    families = dict(DEFAULT_FAMILIES if families is None else families)
    if not 1 <= k_inv <= N_PROF:
        raise ValueError(f"k_inv must be between 1 and {N_PROF} so profiles are distinct within a case.")
    bad = {f:n for f,n in families.items() if n <= 0 or n % N_PROF != 0}
    if bad:
        raise ValueError(f"family counts must be positive multiples of {N_PROF}; invalid: {bad}")

    rng = np.random.default_rng(seed)
    investigators = [f"I{i+1}" for i in range(k_inv)]
    rows, global_idx = [], 0
    for fam, n in families.items():
        sigma = list(rng.permutation(N_PROF))
        for i in range(n):
            global_idx += 1
            case_id = f"{fam}{global_idx:04d}"
            for j, inv in enumerate(investigators):
                rows.append({
                    "case_id": case_id,
                    "family": fam,
                    "investigator": inv,
                    "profile": PROFILES[sigma[(i + j) % N_PROF]],
                })
    return pd.DataFrame(rows)


def verify(df, families=None, k_inv=None):
    """Verify design constraints and return a JSON-serialisable report."""
    families = dict(DEFAULT_FAMILIES if families is None else families)
    if k_inv is None:
        k_inv = int(df["investigator"].nunique())
    rep = {
        "n_cases": int(df.case_id.nunique()),
        "n_obs": int(len(df)),
        "n_investigators": int(df.investigator.nunique()),
    }
    # C1: every case exactly once per investigator
    rep["C1_each_case_once_per_investigator"] = bool(
        (df.groupby(["case_id", "investigator"]).size() == 1).all()
        and (df.groupby("case_id").investigator.nunique() == k_inv).all()
    )
    # C2: within a case, investigators receive distinct profiles
    rep["C2_distinct_profiles_within_case"] = bool(
        (df.groupby("case_id").profile.nunique() == k_inv).all()
    )
    # C3: within family, every investigator sees every profile equally often
    c3_ok = True
    for fam, n in families.items():
        g = df[df.family == fam]
        tab = g.groupby(["investigator", "profile"]).size().unstack(fill_value=0)
        c3_ok &= bool((tab == n // N_PROF).all().all())
    rep["C3_family_investigator_profile_balance"] = bool(c3_ok)
    # C4: within family, every profile has equal observations overall
    c4_ok = True
    for fam, n in families.items():
        counts = df[df.family == fam].groupby("profile").size()
        c4_ok &= bool((counts.reindex(PROFILES, fill_value=0) == n * k_inv // N_PROF).all())
    rep["C4_family_profile_balance"] = bool(c4_ok)
    rep["obs_per_investigator"] = {str(k):int(v) for k,v in df.groupby("investigator").size().items()}
    rep["obs_per_profile"] = {str(k):int(v) for k,v in df.groupby("profile").size().items()}
    return rep


def _schedule_cost(seq):
    return sum(
        (seq[i]["family"] == seq[i+1]["family"]) +
        (seq[i]["profile"] == seq[i+1]["profile"])
        for i in range(len(seq)-1)
    )


def _swap_delta(seq, i, j):
    """Exact local change in adjacency cost for swapping positions i and j."""
    n=len(seq)
    affected=set()
    for q in (i-1,i,j-1,j):
        if 0 <= q < n-1:
            affected.add(q)
    def edge_cost(q):
        return ((seq[q]["family"] == seq[q+1]["family"]) +
                (seq[q]["profile"] == seq[q+1]["profile"]))
    before=sum(edge_cost(q) for q in affected)
    seq[i],seq[j]=seq[j],seq[i]
    after=sum(edge_cost(q) for q in affected)
    seq[i],seq[j]=seq[j],seq[i]
    return after-before


def _min_conflict_schedule(records, rng, max_restarts=60, max_steps=30000):
    """Find a zero-adjacency sequence by stochastic local search."""
    best=None; best_cost=10**9
    n=len(records)
    for _ in range(max_restarts):
        seq=records[:]
        rng.shuffle(seq)
        cost=_schedule_cost(seq)
        if cost < best_cost:
            best,best_cost=seq[:],cost
        temp=1.0
        for step in range(max_steps):
            if cost == 0:
                return seq
            # Focus one swap position around a violating edge.
            bad=[q for q in range(n-1)
                 if seq[q]["family"] == seq[q+1]["family"]
                 or seq[q]["profile"] == seq[q+1]["profile"]]
            q=rng.choice(bad)
            i=rng.choice([q,q+1])
            j=rng.randrange(n)
            if i==j:
                continue
            delta=_swap_delta(seq,i,j)
            # Mostly downhill, with small annealed escape probability.
            import math
            if delta <= 0 or rng.random() < math.exp(-delta/max(temp,1e-6)):
                seq[i],seq[j]=seq[j],seq[i]
                cost += delta
                if cost < best_cost:
                    best,best_cost=seq[:],cost
            temp=max(0.02,temp*0.9995)
    if best_cost == 0:
        return best
    return None


def randomize_order(df, seed=SEED, max_restarts=60):
    """Randomise presentation order with zero same-family/profile adjacencies."""
    rng = random.Random(seed + 1)
    rows, diag = [], {}
    for inv, g in df.groupby("investigator", sort=True):
        records = g.to_dict("records")
        seq = _min_conflict_schedule(records, rng, max_restarts=max_restarts)
        if seq is None:
            raise RuntimeError(f"unable to construct zero-adjacency order for {inv}")
        fam = [r["family"] for r in seq]
        pro = [r["profile"] for r in seq]
        diag[str(inv)] = {
            "same_family_adjacent": int(sum(a==b for a,b in zip(fam, fam[1:]))),
            "same_profile_adjacent": int(sum(a==b for a,b in zip(pro, pro[1:]))),
        }
        for order, r in enumerate(seq, 1):
            r = dict(r); r["order"] = order; rows.append(r)
    return pd.DataFrame(rows), diag

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--investigators", type=int, default=N_PROF)
    p.add_argument("--seed", type=int, default=SEED)
    p.add_argument("--x-cases", type=int, default=None,
                   help="Optional X-family count (multiple of 5). Use 40 or 50 for the H3-focused extension.")
    return p.parse_args()


def main():
    args = parse_args()
    fam = dict(DEFAULT_FAMILIES)
    if args.x_cases is not None:
        fam["X"] = args.x_cases
    df = build_design(fam, args.investigators, args.seed)
    rep = verify(df, fam, args.investigators)
    ordered, diag = randomize_order(df, args.seed)
    if not all(v == 0 for d in diag.values() for v in d.values()):
        raise AssertionError(f"carry-over constraints failed: {diag}")
    if not all(v for k,v in rep.items() if k.startswith("C")):
        raise AssertionError(f"design verification failed: {rep}")

    OUT.mkdir(parents=True, exist_ok=True)
    ordered.to_csv(OUT / "design_assignment.csv", index=False)
    fp = (ordered.groupby(["family","profile"]).size()
          .unstack(fill_value=0).reindex(columns=PROFILES))
    fp.to_csv(OUT / "design_family_by_profile.csv")
    with open(OUT / "design_report.json", "w", encoding="utf-8") as fh:
        json.dump({"verification": rep, "order_diagnostics": diag,
                   "family_counts": fam, "seed": args.seed}, fh, indent=2)
    print(json.dumps(rep, indent=2))
    print("order diagnostics:", json.dumps(diag, indent=2))
    print(f"wrote {OUT/'design_assignment.csv'} ({len(ordered)} rows)")


if __name__ == "__main__":
    main()
