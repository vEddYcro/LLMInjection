"""validate_package.py -- fast structural and unit validation for the MFLP package."""
from __future__ import annotations
import json, os, sys
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import design
import schema_and_cost as sc
import metrics
from power import make_design, BASE_N

def main():
    # Schema integrity
    keys=[(r[0], r[1]) for r in sc.SCHEMA]
    assert len(keys)==len(set(keys)), "duplicate class+field entries in schema"
    assert len(sc.SCHEMA)==42, f"schema count changed unexpectedly: {len(sc.SCHEMA)}"
    assert set(sc.PROFILE_CLASSES)=={"L0","L1","L2","L3","L4"}, \
        "PROFILE_CLASSES must hold only the nested ladder; ablation arms live in ABLATIONS"
    assert set(sc.ABLATIONS)=={"A_noE2","A_noE3"}, \
        f"unexpected ablation arms: {sorted(sc.ABLATIONS)}"

    # Projection is deterministic + idempotent + nested.
    import random
    tr=sc.make_trace("R", random.Random(sc.SEED))
    for name, classes in sc.PROFILE_CLASSES.items():
        p1=sc.project(tr, classes)
        p2=sc.project(tr, classes)
        assert p1==p2, f"{name} projection is not deterministic"
        assert sc.project(p1, classes)==p1, f"{name} projection is not idempotent"
    for name, classes in sc.ABLATIONS.items():
        a1=sc.project(tr, classes)
        assert a1==sc.project(tr, classes), f"{name} projection is not deterministic"
        assert sc.project(a1, classes)==a1, f"{name} projection is not idempotent"
        keep=set(classes)
        for ev in a1:
            for field in ev:
                if field=="_class":
                    continue
                assert sc.field_class(ev["_class"], field) in keep, \
                    f"{name} leaked {field}"
    # A_noE2 and A_noE3 are deliberately NOT nested with the ladder: that is the point
    # of the Sec. 14 contrast, so they are excluded from the nesting assertion below.
    nested=["L0","L1","L2","L3","L4"]
    sizes=[len(sc.project(tr, sc.PROFILE_CLASSES[p])) for p in nested]
    assert all(a<=b for a,b in zip(sizes,sizes[1:])), "profile event sets are not nested"
    # Every emitted non-internal field must belong to a retained class.
    for prof in nested:
        keep=set(sc.PROFILE_CLASSES[prof])
        for ev in sc.project(tr, sc.PROFILE_CLASSES[prof]):
            for field in ev:
                if field == "_class":
                    continue
                cls=sc.field_class(ev["_class"], field)
                assert cls in keep, f"{prof} leaked {field} from {cls}"
    bad=[dict(tr[0], unexpected_secret="x")]
    try:
        sc.project(bad, sc.PROFILE_CLASSES["L0"])
        raise AssertionError("projection did not fail closed on an unknown field")
    except KeyError:
        pass

    # Scoring semantics
    exact, chan=metrics.attribution_score(
        {"channel":"retrieved_document","object_id":"d1"},
        {"channel":"retrieved_document","object_id":"d1"})
    assert (exact,chan)==(1,1)
    exact, chan=metrics.attribution_score(
        {"channel":"retrieved_document","object_id":"wrong"},
        {"channel":"retrieved_document","object_id":"d1"})
    assert (exact,chan)==(0,1)
    prs=metrics.path_reconstruction_score(["a","b","c"],["a","b","c"])
    assert abs(prs["PRS"]-1.0)<1e-12

    # Primary design
    df=design.build_design()
    rep=design.verify(df)
    expected_cases=sum(design.DEFAULT_FAMILIES.values())
    expected_obs=expected_cases*design.N_PROF
    assert rep["n_cases"]==expected_cases and rep["n_obs"]==expected_obs, \
        f'design is {rep["n_cases"]}x{rep["n_obs"]}, expected {expected_cases}x{expected_obs}'
    assert rep["n_investigators"]==design.N_PROF, \
        f'{design.N_PROF} profiles require {design.N_PROF} investigators, got {rep["n_investigators"]}'
    assert all(v for k,v in rep.items() if k.startswith("C"))
    ordered, diag=design.randomize_order(df)
    assert all(v==0 for d in diag.values() for v in d.values())

    # Simulation design guard
    sim=make_design(BASE_N,5,np.random.default_rng(1))
    assert sim.groupby("case").prof.nunique().eq(5).all()  # simulation layer: ladder only

    print("VALIDATION PASSED")
    print(json.dumps({"schema_fields":len(sc.SCHEMA), **rep}, indent=2))

if __name__=="__main__":
    main()
