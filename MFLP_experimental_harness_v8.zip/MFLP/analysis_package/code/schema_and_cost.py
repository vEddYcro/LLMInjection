"""
schema_and_cost.py -- Frozen E0..E4 telemetry schema (42 fields), the deterministic profile
projection operator pi_L, and measurement of the storage and privacy cost of each
logging profile on reference trace instances.

The traces produced here are *reference instances* of the frozen schema, built to
representative field sizes.  They instantiate the analytic cost model of Sec. 8;
they are not measurements of the (not-yet-collected) empirical corpus.

Outputs:
  out/schema_mflp_v1.json     frozen field schema with class, sensitivity, type
  out/cost_by_profile.csv     bytes / sensitive-field counts per profile
  out/cost_by_family.csv      per-family byte cost
  out/reference_trace_R.json  one full L4 canonical trace, for the appendix
"""
import gzip, hashlib, io, json, os, random
import numpy as np
import pandas as pd

OUT = os.path.join(os.path.dirname(__file__), "..", "out")
SEED = 20260911

# --------------------------------------------------------------------------
# 1. Frozen schema.  sensitivity: 0 = identifier/metadata, 1 = derived/hashed,
#    2 = raw content that may carry user or corpus text, 3 = designated secret.
# --------------------------------------------------------------------------
SCHEMA = [
    # class, field, type, sensitivity, note
    ("E0", "event_id",              "uuid",   0, "stable event identifier"),
    ("E0", "correlation_id",        "uuid",   0, "propagated through whole request"),
    ("E0", "session_id",            "uuid",   0, ""),
    ("E0", "ts_coarse",             "ts_s",   0, "1 s resolution"),
    ("E0", "endpoint",              "enum",   0, ""),
    ("E0", "http_status",           "int",    0, ""),
    ("E0", "error_code",            "enum",   0, ""),
    ("E0", "duration_ms",           "int",    0, ""),

    ("E1", "invocation_id",         "uuid",   0, ""),
    ("E1", "parent_event_id",       "uuid",   0, ""),
    ("E1", "model_id",              "str",    0, ""),
    ("E1", "system_prompt_hash",    "sha256", 1, ""),
    ("E1", "user_input",            "text",   2, "raw user turn"),
    ("E1", "context_component_ids", "list",   0, "ordered ids of assembled blocks"),
    ("E1", "assembled_context",     "text",   2, "full prompt as sent"),
    ("E1", "response_text",         "text",   2, ""),
    ("E1", "gen_params",            "obj",    0, "temperature, top_p, max_tokens, seed"),
    ("E1", "token_counts",          "obj",    0, ""),
    ("E1", "finish_reason",         "enum",   0, ""),

    ("E2", "retrieval_id",          "uuid",   0, ""),
    ("E2", "parent_invocation_id",  "uuid",   0, ""),
    ("E2", "retrieval_query",       "text",   2, ""),
    ("E2", "corpus_version",        "str",    0, ""),
    ("E2", "embedding_model_id",    "str",    0, ""),
    ("E2", "hits",                  "list",   2, "per-hit: document_id, chunk_id, span_id, "
                                                 "source_uri, rank, score, content_hash, chunk_text"),

    ("E3", "tool_call_id",          "uuid",   0, ""),
    ("E3", "parent_invocation_id",  "uuid",   0, ""),
    ("E3", "tool_name",             "enum",   0, ""),
    ("E3", "arguments",             "obj",    3, "may contain synthetic secrets"),
    ("E3", "authz_decision",        "enum",   0, ""),
    ("E3", "authz_policy_id",       "str",    0, ""),
    ("E3", "return_value",          "text",   3, ""),
    ("E3", "return_hash",           "sha256", 1, ""),
    ("E3", "action_status",         "enum",   0, ""),

    ("E4", "ts_precise",            "ts_ns",  0, "PTP/NTP-synchronised, ns"),
    ("E4", "app_version",           "str",    0, ""),
    ("E4", "config_hash",           "sha256", 1, ""),
    ("E4", "prompt_template_version", "str",  0, ""),
    ("E4", "prompt_template_hash",  "sha256", 1, ""),
    ("E4", "net_dest",              "obj",    2, "host, port, proto, tls_sni, bytes_out, bytes_in"),
    ("E4", "process_event",         "obj",    1, "pid, exec, parent, uid"),
    ("E4", "host_id",               "str",    0, ""),
]

CLASS_OF = {(c, f): c for c, f, *_ in SCHEMA}
# Sensitivity is field-level here; duplicate field names across event types must
# agree on sensitivity. parent_invocation_id is intentionally present in both
# E2 and E3 with sensitivity 0.
SENS_OF = {}
for c, f, t, s, *_ in SCHEMA:
    if f in SENS_OF and SENS_OF[f] != s:
        raise ValueError(f"inconsistent sensitivity for shared field {f}")
    SENS_OF[f] = s

def field_class(event_class, field):
    """Resolve a field's evidence class in the context of its event type."""
    if ("E0", field) in CLASS_OF:
        return "E0"
    if (event_class, field) in CLASS_OF:
        return event_class
    # Fallback only for a globally unique field.
    matches = [c for (c, f) in CLASS_OF if f == field]
    return matches[0] if len(set(matches)) == 1 else None

PROFILE_CLASSES = {
    "L0": ["E0"],
    "L1": ["E0", "E1"],
    "L2": ["E0", "E1", "E2"],
    "L3": ["E0", "E1", "E2", "E3"],
    "L4": ["E0", "E1", "E2", "E3", "E4"],
}
# non-nested ablations (Sec. 6.6)
ABLATIONS = {
    "A_noE2": ["E0", "E1", "E3"],       # tools but no retrieval provenance
    "A_noE3": ["E0", "E1", "E2"],       # provenance but no tool telemetry
}

# --------------------------------------------------------------------------
# 2. Canonical trace generation at representative field sizes
# --------------------------------------------------------------------------
FAMILY_SHAPE = {
    # family: (n_llm_invocations, n_retrievals, top_k, n_tool_calls, n_net_events)
    "D": (2, 1, 5, 1, 0),
    "I": (2, 1, 5, 1, 0),
    "R": (2, 2, 8, 1, 0),
    "T": (3, 1, 5, 3, 0),
    "X": (3, 1, 5, 3, 2),
    "F": (2, 1, 5, 1, 0),
    "B": (2, 1, 5, 1, 0),
}
CHUNK_CHARS = 780          # mean retrieved chunk length
USER_CHARS = 220
RESP_CHARS = 640
SYSPROMPT_CHARS = 1450
TOOL_RET_CHARS = 340


def _uuid(rng):
    return "%032x" % rng.getrandbits(128)


def _text(rng, n):
    # lorem-like filler at realistic entropy; content is irrelevant to byte cost
    alpha = "abcdefghijklmnopqrstuvwxyz "
    return "".join(rng.choice(alpha) for _ in range(int(n)))


def _sha(rng):
    return hashlib.sha256(("%d" % rng.getrandbits(64)).encode()).hexdigest()


def make_trace(family, rng):
    n_llm, n_ret, k, n_tool, n_net = FAMILY_SHAPE[family]
    corr = _uuid(rng)
    sess = _uuid(rng)
    events = []

    def base(cls):
        return {"_class": cls, "event_id": _uuid(rng), "correlation_id": corr,
                "session_id": sess, "ts_coarse": 1789000000 + rng.randint(0, 10 ** 5),
                "endpoint": "/v1/chat", "http_status": 200,
                "error_code": "none", "duration_ms": rng.randint(400, 9000)}

    # E0 request envelope
    ev = base("E0"); events.append(ev)

    for i in range(n_llm):
        e = base("E0"); e["_class"] = "E1"
        e.update({
            "invocation_id": _uuid(rng), "parent_event_id": ev["event_id"],
            "model_id": "local-8b-instruct@2026.03",
            "system_prompt_hash": _sha(rng),
            "user_input": _text(rng, USER_CHARS) if i == 0 else "",
            "context_component_ids": [_uuid(rng) for _ in range(k + 2)],
            "assembled_context": _text(rng, SYSPROMPT_CHARS + k * CHUNK_CHARS),
            "response_text": _text(rng, RESP_CHARS),
            "gen_params": {"temperature": 0.0, "top_p": 1.0, "max_tokens": 1024, "seed": 7},
            "token_counts": {"prompt": 1800, "completion": 190},
            "finish_reason": "stop",
        })
        events.append(e)

    for i in range(n_ret):
        e = base("E0"); e["_class"] = "E2"
        e.update({
            "retrieval_id": _uuid(rng),
            "parent_invocation_id": events[1]["invocation_id"],
            "retrieval_query": _text(rng, 120),
            "corpus_version": "corpus-v1.3.0",
            "embedding_model_id": "bge-small-en@1.5",
            "hits": [{
                "document_id": _uuid(rng), "chunk_id": _uuid(rng), "span_id": "s%d" % j,
                "source_uri": "synthetic://corpus/v1.3.0/doc%04d#c%02d" % (rng.randint(0, 50), j),
                "rank": j + 1, "score": round(rng.uniform(0.3, 0.95), 4),
                "content_hash": _sha(rng), "chunk_text": _text(rng, CHUNK_CHARS),
            } for j in range(k)],
        })
        events.append(e)

    for i in range(n_tool):
        e = base("E0"); e["_class"] = "E3"
        e.update({
            "tool_call_id": _uuid(rng),
            "parent_invocation_id": events[1]["invocation_id"],
            "tool_name": rng.choice(["search_private_record", "send_message", "fetch_url"]),
            "arguments": {"q": _text(rng, 90), "record_id": "synthetic_secret_%02d" % rng.randint(1, 40)},
            "authz_decision": rng.choice(["allow", "deny"]),
            "authz_policy_id": "pol-004",
            "return_value": _text(rng, TOOL_RET_CHARS),
            "return_hash": _sha(rng),
            "action_status": rng.choice(["completed", "attempted", "blocked"]),
        })
        events.append(e)

    # E4 decoration attaches to every event, plus standalone net/process events
    for e in events:
        e.update({
            "ts_precise": 1789000000000000000 + rng.randint(0, 10 ** 9),
            "app_version": "mflp-app@1.0.0", "config_hash": _sha(rng),
            "prompt_template_version": "tpl-v4", "prompt_template_hash": _sha(rng),
            "host_id": "sandbox-01",
            "process_event": {"pid": rng.randint(100, 60000), "exec": "/usr/bin/python3.12",
                              "parent": 1, "uid": 1000},
        })
    for i in range(n_net):
        e = base("E0"); e["_class"] = "E4"
        e.update({
            "ts_precise": 1789000000000000000 + rng.randint(0, 10 ** 9),
            "app_version": "mflp-app@1.0.0", "config_hash": _sha(rng),
            "prompt_template_version": "tpl-v4", "prompt_template_hash": _sha(rng),
            "host_id": "sandbox-01",
            "net_dest": {"host": "sink.local", "port": 8081, "proto": "tcp",
                         "tls_sni": "sink.local", "bytes_out": rng.randint(200, 4000),
                         "bytes_in": rng.randint(80, 900)},
            "process_event": {"pid": rng.randint(100, 60000), "exec": "/usr/bin/python3.12",
                              "parent": 1, "uid": 1000},
        })
        events.append(e)
    return events


# --------------------------------------------------------------------------
# 3. Projection operator pi_L  (deterministic, field-level, idempotent)
# --------------------------------------------------------------------------
def project(events, classes):
    """Retain an event iff its own class is in `classes`; within a retained
    event retain a field iff the field's class is in `classes`.  E0 envelope
    fields are always retained for any retained event (they are the join keys)."""
    keep = set(classes)
    out = []
    for e in events:
        if e["_class"] not in keep:
            continue
        ne = {}
        for kf, v in e.items():
            if kf == "_class":
                ne[kf] = v
                continue
            cls = field_class(e["_class"], kf)
            if cls is None:
                raise KeyError(f"unclassified telemetry field {kf!r} on event class {e['_class']!r}")
            if cls in keep:
                ne[kf] = v
        out.append(ne)
    return out


def sensitive_counts(events):
    c = {1: 0, 2: 0, 3: 0}
    raw_chars = 0
    for e in events:
        for kf, v in e.items():
            s = SENS_OF.get(kf, 0)
            if s:
                c[s] += 1
            if s >= 2:
                raw_chars += len(json.dumps(v))
    return c, raw_chars


def nbytes(obj):
    b = json.dumps(obj, separators=(",", ":"), sort_keys=True).encode()
    gz = gzip.compress(b, 9)
    return len(b), len(gz)


def main():
    rng = random.Random(SEED)
    fam_n = {"D": 10, "I": 10, "R": 10, "T": 10, "X": 10, "F": 10, "B": 20}
    rows, famrows = [], []
    ref_trace = None
    for fam, n in fam_n.items():
        traces = [make_trace(fam, rng) for _ in range(n)]
        if fam == "R" and ref_trace is None:
            ref_trace = traces[0]
        for prof, classes in list(PROFILE_CLASSES.items()) + list(ABLATIONS.items()):
            raw = gz = 0
            s1 = s2 = s3 = 0
            rawchars = 0
            nev = 0
            for t in traces:
                p = project(t, classes)
                r, g = nbytes(p)
                raw += r; gz += g; nev += len(p)
                c, rc = sensitive_counts(p)
                s1 += c[1]; s2 += c[2]; s3 += c[3]; rawchars += rc
            famrows.append(dict(family=fam, profile=prof, n_cases=n,
                                bytes_raw=raw / n, bytes_gz=gz / n,
                                events=nev / n, sens2=s2 / n, sens3=s3 / n,
                                raw_content_chars=rawchars / n))
    fdf = pd.DataFrame(famrows)
    # corpus-level aggregate (weighted by family size)
    agg = (fdf.assign(w=lambda d: d.n_cases)
              .groupby("profile")
              .apply(lambda g: pd.Series({
                  "bytes_raw_mean": np.average(g.bytes_raw, weights=g.w),
                  "bytes_gz_mean": np.average(g.bytes_gz, weights=g.w),
                  "events_mean": np.average(g.events, weights=g.w),
                  "sens_raw_fields": np.average(g.sens2, weights=g.w),
                  "sens_secret_fields": np.average(g.sens3, weights=g.w),
                  "raw_content_chars": np.average(g.raw_content_chars, weights=g.w),
              }), include_groups=False)
              .reset_index())
    order = ["L0", "L1", "L2", "L3", "L4", "A_noE2", "A_noE3"]
    agg["ord"] = agg.profile.map({p: i for i, p in enumerate(order)})
    agg = agg.sort_values("ord").drop(columns="ord").reset_index(drop=True)
    # marginal cost
    nested = agg[agg.profile.isin(["L0", "L1", "L2", "L3", "L4"])].reset_index(drop=True)
    nested["delta_bytes_gz"] = nested.bytes_gz_mean.diff()
    nested["cum_ratio_vs_L4"] = nested.bytes_gz_mean / nested.bytes_gz_mean.iloc[-1]
    os.makedirs(OUT, exist_ok=True)
    agg.to_csv(os.path.join(OUT, "cost_by_profile.csv"), index=False)
    nested.to_csv(os.path.join(OUT, "cost_nested.csv"), index=False)
    fdf.to_csv(os.path.join(OUT, "cost_by_family.csv"), index=False)
    with open(os.path.join(OUT, "reference_trace_R.json"), "w") as fh:
        json.dump(ref_trace, fh, indent=1)
    with open(os.path.join(OUT, "schema_mflp_v1.json"), "w") as fh:
        json.dump([{"class": c, "field": f, "type": t, "sensitivity": s, "note": n}
                   for c, f, t, s, n in SCHEMA], fh, indent=1)
    pd.set_option("display.width", 200)
    print(nested.to_string(index=False))
    print()
    print(agg.to_string(index=False))
    return agg, nested, fdf


if __name__ == "__main__":
    main()
