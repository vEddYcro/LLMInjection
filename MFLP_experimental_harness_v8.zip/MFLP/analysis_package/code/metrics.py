"""
metrics.py -- Reference implementation of the scoring functions defined in
Sec. 5 of the manuscript.  Every primary outcome is computed from the structured
investigator workbook and the sealed ground-truth manifest by this module, with
no free-text judgement, so scoring is reproducible from the archived artefacts.

Implements:
  * source attribution scoring (exact / channel-only / incorrect)
  * the order-aware Path Reconstruction Score (PRS)
  * unsupported-step rate and evidence-grounding rate
  * Brier score with the Murphy (reliability-resolution-uncertainty)
    decomposition, and expected calibration error
  * marginal forensic value and the cost-performance Pareto frontier
"""
import itertools, json, os
import numpy as np
import pandas as pd

OUT = os.path.join(os.path.dirname(__file__), "..", "out")


# ------------------------------------------------------- source attribution
CHANNELS = ["user", "retrieved_document", "rag_corpus", "tool_output", "none"]


def attribution_score(reported, truth):
    """reported / truth: dicts with keys 'channel' and 'object_id'.
    Returns (exact, channel_only) as 0/1 indicators.  The primary outcome is
    `exact`; `channel_only` is reported separately and never pooled into the
    primary, so partial credit cannot inflate the headline result.
    """
    ch = reported.get("channel") == truth.get("channel")
    obj = reported.get("object_id") == truth.get("object_id")
    if truth.get("channel") == "none":          # benign control
        return int(ch), int(ch)
    # Return exact attribution and channel correctness as separate indicators.
    # An exact attribution is necessarily also channel-correct.
    return int(ch and obj), int(ch)


def appropriate_abstention(reported_channel, truth_channel, identifiable):
    """Score epistemically appropriate source-attribution abstention.

    Parameters
    ----------
    reported_channel : str
        Investigator response; use "unknown" for abstention.
    truth_channel : str
        Ground-truth channel.
    identifiable : bool
        Whether the delivered profile contains enough source identity evidence
        for the case by the frozen identifiability rule.

    Returns 1 only when source identity is structurally unavailable and the
    investigator answers "unknown". This is reported separately from exact
    attribution, where unknown scores 0.
    """
    return int((not identifiable) and reported_channel == "unknown")


# --------------------------------------------------- path reconstruction
def _lcs_len(a, b):
    m, n = len(a), len(b)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(m):
        for j in range(n):
            dp[i + 1][j + 1] = dp[i][j] + 1 if a[i] == b[j] else max(dp[i][j + 1], dp[i + 1][j])
    return dp[m][n]


def path_reconstruction_score(reported_steps, truth_steps):
    """Order-aware reconstruction score.

    reported_steps : ordered list of step identifiers claimed by the investigator
    truth_steps    : ordered list of ground-truth step identifiers

    rho   = |M| / |S|                 coverage (recall of ground-truth steps)
    pi    = |M| / |R|                 precision (1 - unsupported-step rate)
    kappa = LCS(M_R, M_S) / |M|       order consistency
    PRS   = kappa * 2*pi*rho/(pi+rho)

    PRS = 1 iff the investigator reports exactly the ground-truth steps in the
    correct order; it is 0 if no reported step matches.  Reporting extra
    unsupported steps strictly reduces PRS, so padding the answer cannot help.
    """
    S, R = list(truth_steps), list(reported_steps)
    if len(R) == 0 or len(S) == 0:
        return dict(PRS=0.0, coverage=0.0, precision=0.0, kappa=0.0,
                    unsupported_rate=1.0 if R else 0.0, n_matched=0)
    matched = [r for r in R if r in S]
    M = len(set(matched))
    if M == 0:
        return dict(PRS=0.0, coverage=0.0, precision=0.0, kappa=0.0,
                    unsupported_rate=1.0, n_matched=0)
    rho = M / len(S)
    pi = M / len(R)
    seq_r = [r for r in R if r in S]
    seq_s = [s for s in S if s in set(seq_r)]
    kappa = _lcs_len(seq_r, seq_s) / len(seq_r)
    f1 = 2 * pi * rho / (pi + rho)
    return dict(PRS=kappa * f1, coverage=rho, precision=pi, kappa=kappa,
                unsupported_rate=1 - pi, n_matched=M)


def evidence_grounding_rate(claims, delivered_event_ids):
    """Fraction of the investigator's conclusions that cite at least one event
    identifier actually present in the evidence package they were given.
    Citations to identifiers absent from the package are counted as ungrounded;
    they indicate inference presented as observation."""
    if not claims:
        return np.nan
    ok = sum(bool(set(c.get("evidence", [])) & set(delivered_event_ids)) for c in claims)
    return ok / len(claims)


# ----------------------------------------------------------- calibration
def brier_decomposition(conf, outcome, n_bins=10):
    """Brier score with the Murphy decomposition B = REL - RES + UNC."""
    f = np.asarray(conf, float)
    o = np.asarray(outcome, float)
    n = len(f)
    B = np.mean((f - o) ** 2)
    obar = o.mean()
    UNC = obar * (1 - obar)
    edges = np.linspace(0, 1, n_bins + 1)
    idx = np.clip(np.digitize(f, edges[1:-1]), 0, n_bins - 1)
    REL = RES = 0.0
    ece = 0.0
    for k in range(n_bins):
        m = idx == k
        nk = m.sum()
        if nk == 0:
            continue
        fk, ok_ = f[m].mean(), o[m].mean()
        REL += nk * (fk - ok_) ** 2
        RES += nk * (ok_ - obar) ** 2
        ece += nk * abs(fk - ok_)
    return dict(brier=B, reliability=REL / n, resolution=RES / n,
                uncertainty=UNC, ece=ece / n)


# ------------------------------------------- marginal value and cost frontier
def marginal_forensic_value(perf, cost_bytes, sens_fields, w_bytes=0.5, w_sens=0.5):
    """perf, cost_bytes, sens_fields: arrays indexed L0..L4.

    MFV_n = (perf_n - perf_{n-1}) / (cost_n - cost_{n-1})   [per KiB]

    Composite normalised cost C_n = w_b * b~_n + w_s * s~_n with b~, s~ each
    min-max scaled to [0,1] across profiles.  The frontier is the set of
    profiles not dominated on (C, perf).
    """
    perf = np.asarray(perf, float)
    b = np.asarray(cost_bytes, float)
    s = np.asarray(sens_fields, float)

    def norm(x):
        return (x - x.min()) / (x.max() - x.min()) if x.max() > x.min() else np.zeros_like(x)

    C = w_bytes * norm(b) + w_sens * norm(s)
    mfv = np.full(len(perf), np.nan)
    for n in range(1, len(perf)):
        db = (b[n] - b[n - 1]) / 1024.0
        mfv[n] = (perf[n] - perf[n - 1]) / db if db > 0 else np.nan
    dominated = []
    for i in range(len(perf)):
        dom = any((C[j] <= C[i]) and (perf[j] >= perf[i]) and
                  ((C[j] < C[i]) or (perf[j] > perf[i])) for j in range(len(perf)))
        dominated.append(dom)
    return dict(mfv_per_KiB=mfv, composite_cost=C, on_frontier=~np.array(dominated))


# ------------------------------------------------------------ worked example
def worked_example():
    truth = ["s1_retrieve_poisoned_chunk", "s2_context_assembly",
             "s3_model_emits_tool_call", "s4_tool_reads_secret",
             "s5_send_to_sink"]
    cases = {
        "L4 investigator (complete, ordered)": truth,
        "L3 investigator (misses network step)": truth[:4],
        "L2 investigator (no tool telemetry; invents a step)":
            ["s1_retrieve_poisoned_chunk", "s2_context_assembly",
             "s3_model_emits_tool_call", "sX_user_supplied_payload"],
        "L1 investigator (content but no provenance)":
            ["s2_context_assembly", "sX_user_supplied_payload",
             "s3_model_emits_tool_call"],
        "L1 investigator (right steps, wrong order)":
            ["s3_model_emits_tool_call", "s2_context_assembly",
             "s1_retrieve_poisoned_chunk"],
        "L0 investigator (no reconstruction)": ["sX_unknown_error"],
    }
    rows = []
    for k, v in cases.items():
        r = path_reconstruction_score(v, truth)
        r["scenario"] = k
        rows.append(r)
    df = pd.DataFrame(rows)[["scenario", "coverage", "precision", "kappa",
                             "unsupported_rate", "PRS"]]
    return df.round(3)


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    ex = worked_example()
    ex.to_csv(os.path.join(OUT, "prs_worked_example.csv"), index=False)
    print(ex.to_string(index=False))

    # calibration sanity check on synthetic well- and over-confident raters
    rng = np.random.default_rng(3)
    p = rng.uniform(0.5, 1.0, 400)
    o_cal = (rng.random(400) < p).astype(float)
    o_over = (rng.random(400) < p * 0.75).astype(float)
    print("\ncalibrated  ", {k: round(v, 4) for k, v in brier_decomposition(p, o_cal).items()})
    print("overconfident", {k: round(v, 4) for k, v in brier_decomposition(p, o_over).items()})
