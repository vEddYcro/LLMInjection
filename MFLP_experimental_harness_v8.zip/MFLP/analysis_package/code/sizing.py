"""
sizing.py -- Operating characteristics of the frozen MFLP selection rule as a
function of corpus size N, investigator count k, and non-inferiority margin.

This is the design calculation that determines how large the study has to be.
It answers three questions:

  Q1  With what probability does the rule return the correct profile (or
      correctly abstain) under each of the five scenarios?
  Q2  What is the probability of an *unsafe* error -- recommending a profile
      strictly below the true minimum, i.e. under-logging?
  Q3  How large must N and k be for the rule to be adequately powered at a
      given margin?

Writes out/sizing_oc.csv and out/sizing_power.csv.
"""
import os, sys, time
import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, os.path.dirname(__file__))
from power import (SCEN, BASE_N, FAMS, PROFILES, SEL_LABELS, NI_MARGIN,
                   ABS_THRESH, SIGMA_CASE, SIGMA_INV, theta_matrix, make_design,
                   build_matrices, simulate, mflp_select, true_optimum)
from stats_core import marginal_rd, ni_test

OUT = os.path.join(os.path.dirname(__file__), "..", "out")
TRUE_IDX = {"S4_true_L1": 1, "S2_true_L2": 2, "S1_true_L3": 3,
            "S3_true_L4": 4, "S0_true_none": 5}


def scale_corpus(N):
    return {f: max(4, int(round(n * N / 80))) for f, n in BASE_N.items()}


def run_oc(scen, N, k, margin, nsim, seed):
    TH = theta_matrix(SCEN[scen])
    des = make_design(scale_corpus(N), k, np.random.default_rng(seed + 7))
    _, Dm = build_matrices(des)
    cl = des.case.values
    rng = np.random.default_rng(seed)
    sel = np.zeros(6)
    ses = []
    for _ in range(nsim):
        y = simulate(des, TH, rng)
        try:
            th, vc = marginal_rd(y, Dm, cl, 4)
        except np.linalg.LinAlgError:
            continue
        sel[mflp_select(th, vc, margin=margin)] += 1
        Lv = np.zeros(len(th)); Lv[3] = 1; Lv[4] = -1
        ses.append(np.sqrt(max(Lv @ vc @ Lv, 0)))
    sel = sel / sel.sum()
    t = TRUE_IDX[scen]
    # under-logging = a profile strictly weaker than the true minimum was issued
    under = sel[:t].sum() if t <= 4 else sel[:5].sum()
    over = sel[t + 1:5].sum() if t <= 4 else 0.0
    return dict(scenario=scen, true=SEL_LABELS[t], N=N, k=k, margin=margin,
                n_obs=len(des), n_per_profile=len(des) // 5,
                p_correct=sel[t], p_underlog=under, p_overlog=over,
                p_abstain=sel[5], se_RD=float(np.mean(ses)),
                **{f"sel_{SEL_LABELS[i]}": sel[i] for i in range(6)})


def main():
    os.makedirs(OUT, exist_ok=True)
    nsim = int(os.environ.get("NSIM", 1500))
    rows = []
    grid = [(80, 3), (80, 5), (160, 3), (160, 5), (240, 3), (320, 3), (320, 5)]
    for margin in (0.10, 0.05):
        for (N, k) in grid:
            for scen in TRUE_IDX:
                r = run_oc(scen, N, k, margin, nsim, seed=1000 + N + k)
                rows.append(r)
                print(f"m={margin} N={N} k={k} {scen:14s} "
                      f"correct={r['p_correct']:.3f} under={r['p_underlog']:.3f} "
                      f"abstain={r['p_abstain']:.3f} SE={r['se_RD']:.4f}", flush=True)
                pd.DataFrame(rows).to_csv(os.path.join(OUT, "sizing_oc.csv"), index=False)
    print("done", flush=True)


if __name__ == "__main__":
    main()
