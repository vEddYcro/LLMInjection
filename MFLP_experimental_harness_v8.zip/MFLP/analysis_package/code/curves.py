"""curves.py -- power for the directional hypotheses H1-H3 at candidate designs."""
import os, sys
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(__file__))
from power import run_contrast_power, BASE_N
from sizing import scale_corpus
OUT = os.path.join(os.path.dirname(__file__), "..", "out")
os.makedirs(OUT, exist_ok=True)
rows = []
for (N, k) in [(80, 3), (160, 3), (160, 5), (240, 3), (320, 5)]:
    r = run_contrast_power(int(os.environ.get("NSIM", 1000)), "S1_true_L3",
                           scale_corpus(N), k, seed=500 + N + k, do_glmm=(N <= 160))
    r["N"], r["k"] = N, k
    rows.append(r)
    pd.DataFrame(rows).to_csv(os.path.join(OUT, "hypothesis_power.csv"), index=False)
    print(N, k, {a: round(r[a], 3) for a in
                 ["delta1", "delta2", "delta3", "delta4",
                  "H2a_E2_in_IR", "H2b_E3_in_T", "H3_E4_in_X"]}, flush=True)
print("done", flush=True)
