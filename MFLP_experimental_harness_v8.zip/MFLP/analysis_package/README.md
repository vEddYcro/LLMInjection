# MFLP reproducibility package — corrected version

Code and computed design outputs supporting the pre-data protocol
**A Minimum Forensic Logging Profile for Prompt-Injection Incidents in LLM-Integrated Applications**.

## Important scope

This package is **not the investigator interface**. Human investigators receive only `investigator_kit/` and their assigned blinded evidence packages. The full package is for the study team and, after the blinded phase, reviewers/independent researchers.

It currently reproduces and validates:
- the powered experimental assignment;
- the E0–E4 telemetry schema and deterministic profile projection;
- storage/privacy cost calculations on reference traces;
- scoring functions;
- Monte-Carlo sizing / MFLP operating characteristics;
- directional-hypothesis power calculations;
- manuscript design-analysis figures.

It still does **not** contain empirical reconstruction data, because the canonical incident corpus, sealed ground-truth manifests, evidence packages, and investigator responses have not yet been collected.

## Primary design

Default `code/design.py` output is **160 canonical cases × 5 investigators = 800 blinded evaluations**, matching the powered journal design in the revised protocol. The optional H3-focused extension can increase the exfiltration family, e.g.:

    python3 code/design.py --x-cases 40

## Install

Python 3.10+ recommended.

    python -m venv .venv
    source .venv/bin/activate          # Windows: .venv\Scripts\activate
    pip install -r requirements.txt

## Validate quickly

    python code/validate_package.py

or run the whole pipeline with small Monte-Carlo counts:

    python run_all.py --quick

## Reproduce the full design-analysis package

    python run_all.py --full

Equivalent individual commands:

    python code/design.py
    python code/schema_and_cost.py
    python code/metrics.py
    NSIM=1200 python code/sizing.py
    NSIM=1000 python code/curves.py
    python code/figures.py

All output paths are package-relative. No machine-specific `/home/...` paths remain.

## Directory roles

- `code/`: design, schema, scoring, statistical and simulation code.
- `out/`: generated machine-readable outputs.
- `figs/`: generated manuscript figures.
- `investigator_kit/`: materials safe to distribute to blinded investigators.
- `PACKAGE_ROLES.md`: explains study-team vs investigator vs reviewer use.

## Corrections made in this release

1. Removed hard-coded `/home/claude/...` output paths.
2. Replaced the obsolete 80×3 assignment generator with the powered 160×5 primary design.
3. Made `figures.py` handle a dynamic number of investigators.
4. Corrected source-attribution scoring so exact attribution also counts as channel-correct.
5. Corrected the MFLP-rule documentation: the adequacy floor uses the frozen point-estimate feasibility screen, while non-inferiority uses the one-sided confidence bound.
6. Added design guards, schema/projection/scoring validation, and a one-command pipeline.
7. Removed a duplicate non-nested ablation alias.
8. Clarified the schema is 42 fields in the code as currently implemented.
9. Added blinded investigator materials and explicit package-role documentation.

## Manuscript synchronisation note

The current code contains **42 unique telemetry fields**, while the manuscript text describes a “40-field” schema. The computed cost outputs were generated from the 42-field implementation. For scientific consistency, the manuscript should say **42-field** unless two fields are deliberately removed and all Section 8 cost results are regenerated. This package keeps the implemented schema intact rather than silently changing the measured cost model.

## Seeds

Default seed: `20260911`.

## Empirical phase not yet included

After data collection, the final public reproducibility release should additionally contain de-identified:
- canonical-trace manifests (or releasable synthetic traces);
- profile-projection manifests;
- assignment map with opaque identifiers;
- investigator workbooks;
- scored outcome table;
- final analysis script and generated result tables.

Ground truth must remain inaccessible to investigators until all assigned evaluations are locked.
