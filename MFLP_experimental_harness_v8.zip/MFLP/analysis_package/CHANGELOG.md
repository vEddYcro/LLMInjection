# Changelog

## Corrected package
- removed machine-specific output paths;
- updated primary assignment to 160 cases × 5 investigators;
- added optional X-family oversampling;
- made presentation-order randomisation generic and verified zero-adjacency;
- fixed E2/E3 shared-field projection classification;
- made profile projection fail closed on unknown telemetry fields;
- fixed channel-only source-attribution scoring;
- corrected MFLP rule documentation;
- added dynamic-investigator figure generation;
- added validation script, requirements, and one-command runners;
- added blinded investigator kit and role documentation;
- documented manuscript synchronization requirements.
