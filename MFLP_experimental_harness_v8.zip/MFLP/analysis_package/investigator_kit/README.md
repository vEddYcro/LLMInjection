# Investigator / evaluator kit

This folder is the only part of the study materials that should be distributed to human investigators during the blinded reconstruction study.

Investigators must **not** receive the full reproducibility package before completing their assigned cases. The full package exposes profile construction, simulation assumptions, scoring logic, and eventually ground truth, which can bias reconstruction.

Each investigator should receive:
1. the common `instructions.md`;
2. only their assigned blinded evidence packages (opaque case tokens; no family/profile labels);
3. one workbook row per assigned case, using `workbook_template.csv`.

The investigator does not run `power.py`, `sizing.py`, `design.py`, `schema_and_cost.py`, or the scoring code. Those are research/reproducibility tools for the study team and, after release, reviewers and independent researchers.
