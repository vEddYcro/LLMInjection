# Who uses what?

## Human investigators/evaluators during the experiment
Use only `investigator_kit/` plus the blinded evidence packages assigned to them. They should not receive this full repository until their evaluation is finished.

## Study team
Uses the full package to generate/verify assignments, freeze the schema, project profiles, score submitted workbooks against sealed ground truth, run statistics, and regenerate figures.

## Peer reviewers and independent researchers
After the study is complete and the blinded phase is closed, the full package lets them audit the protocol, reproduce design/power calculations, verify scoring, rerun analyses from released de-identified data, and regenerate figures.

The package is therefore a **research and reproducibility instrument**, not the interface through which human investigators conduct the forensic reconstruction.
