# Manuscript synchronisation notes after code correction

The corrected code uncovered two manuscript/package consistency items that should be synchronized before final submission:

1. **Telemetry field count.** The implemented frozen schema contains 42 class-field entries, not 40. The manuscript currently says “40-field” in several places. The least disruptive correction is to change those manuscript references to “42-field”; deleting two fields would change the frozen schema and cost model.

2. **Reference telemetry-cost values.** The original projection code used a single global field-name map. Because `parent_invocation_id` legitimately exists in both E2 and E3 event types, the E2 instance was incorrectly classified as E3 during projection. The corrected projector resolves field class in the context of event type and fails closed on unknown fields. This slightly changes the reference byte-cost values in `out/cost_nested.csv`. The manuscript's Section 8 tables/numbers should be regenerated from this corrected file before submission.

These are pre-data design/cost corrections; they do not alter empirical reconstruction results because those data have not yet been collected.
