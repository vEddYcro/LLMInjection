"""run_all.py -- reproducible pipeline runner.

Use --quick for installation validation (small Monte Carlo counts).
Use --full to reproduce manuscript design-analysis outputs (longer runtime).
"""
from __future__ import annotations
import argparse, os, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
CODE=ROOT/"code"

def run(args, env=None):
    e=os.environ.copy()
    if env: e.update(env)
    print("+"," ".join(map(str,args)), flush=True)
    subprocess.run(args, cwd=ROOT, env=e, check=True)

def main():
    ap=argparse.ArgumentParser()
    g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--quick",action="store_true")
    g.add_argument("--full",action="store_true")
    a=ap.parse_args()
    py=sys.executable
    run([py, str(CODE/"validate_package.py")])
    run([py, str(CODE/"design.py")])
    run([py, str(CODE/"schema_and_cost.py")])
    run([py, str(CODE/"metrics.py")])
    if a.quick:
        run([py, str(CODE/"sizing.py")], {"NSIM":"20"})
        run([py, str(CODE/"curves.py")], {"NSIM":"20"})
    else:
        run([py, str(CODE/"sizing.py")], {"NSIM":"1200"})
        run([py, str(CODE/"curves.py")], {"NSIM":"1000"})
    run([py, str(CODE/"figures.py")])
    print("PIPELINE COMPLETE")

if __name__=="__main__":
    main()
