# MFLP Study Execution Runbook — WSL Edition

**Minimum Forensic Logging Profile for Prompt-Injection Incidents — end-to-end execution on Windows Subsystem for Linux**

Version 2.0 (WSL) · prepared 12 September 2026 · for Vedran Dakić

---

## 0. Read this first

This runbook covers the whole chain on a Windows workstation running WSL2: preparing the distro, freezing the protocol, generating the incident corpus with a real local model on your GPU, handing blinded packages to human investigators, collecting their answers, and scoring them into the tables that populate Section 9 of the manuscript.

Three things to know before you start.

**The study is two commands separated by weeks, not one.** Phase 1 (`run_study.sh`) needs the GPU and produces blinded evidence packages. Those packages contain no findings — that is the point of them. Phase 2 (`score_study.py`) runs after your investigators return their workbooks and needs no GPU at all. Running locally, you can simply leave the machine alone in between.

**The harness as originally shipped would have invalidated the study.** I audited the code and found eight defects, four of them blocking. The most serious: every investigator package above L0 contained the internal case ID and family letter in plain text, and the L1 packages contained the full retrieved document text — exactly the evidence L1 is defined to exclude. The primary independent variable was not being varied. Section 10 documents all of it. Use the corrected package, not the original ZIP.

**Ollama must run inside WSL, or under mirrored networking.** This is the single most common way this setup fails. Details in §2.3.

---

## 1. Check your machine is suitable

### 1.1 GPU and memory

The workload is at most three model generations per case (`agent.max_steps: 3`), so 160 cases is at most 480 generations. It is a small job; sizing is about fitting the model in VRAM, not throughput.

| Model | VRAM needed | Typical card | Approximate phase-1 wall time |
|---|---|---|---|
| 8B quantized (q4) | ~6 GB | RTX 3060 12 GB, RTX 4060 Ti | 45–90 min |
| 8B fp16 | ~16 GB | RTX 4080 16 GB, RTX 3090 | 25–50 min |
| 14B quantized | ~10 GB | RTX 4070 Ti / 3090 | 1.5–3 h |
| CPU only | — | — | 8–20 h, not recommended |

Allow around 20 GB of free disk inside the distro: the model weights dominate, the study output itself is about 25 MB.

### 1.2 Verify WSL2 and GPU passthrough

In **PowerShell**:

```powershell
wsl --status          # Default Version must be 2
wsl --update
nvidia-smi            # confirm the Windows driver sees your GPU
```

Install the NVIDIA driver **on Windows only**. Do not install a Linux NVIDIA driver inside the distro — it overwrites the WSL CUDA shim and breaks passthrough. If you have ever done this, reinstall the distro.

If you don't yet have a distro:

```powershell
wsl --install -d Ubuntu-24.04
```

Then, inside WSL:

```bash
uname -r                            # should mention 'microsoft'
ls /usr/lib/wsl/lib/libcuda.so.1    # must exist: this is the passthrough shim
nvidia-smi                          # must list your GPU
```

### 1.3 Give WSL enough memory

WSL2 defaults to half your host RAM, which can be tight while a model is loaded. Create or edit `C:\Users\<you>\.wslconfig`:

```ini
[wsl2]
memory=24GB
processors=8
swap=8GB
```

If you intend to run Ollama on the Windows side rather than inside the distro (see §2.3), also add:

```ini
networkingMode=mirrored
```

Then apply it from PowerShell:

```powershell
wsl --shutdown
```

---

## 2. Prepare the distro

### 2.1 Packages

```bash
sudo apt-get update
sudo apt-get install -y python3-pip python3-venv unzip zip dos2unix curl
```

`zip` and `dos2unix` are not present on a stock Ubuntu image and both are needed.

### 2.2 Unpack the harness — inside WSL

Put the package in your **Linux home directory**, not under `/mnt/c/`. On the Windows mount, `chmod +x` does not persist without the `metadata` mount option, and writing 800 small package directories across the 9p filesystem boundary is dramatically slower.

```bash
cd ~
# if the ZIP is in your Windows Downloads folder:
cp /mnt/c/Users/<you>/Downloads/MFLP_experimental_harness_v3_corrected.zip ~
unzip -q MFLP_experimental_harness_v3_corrected.zip
cd MFLP
```

Unzip **with the WSL `unzip` command**, not Windows Explorer or 7-Zip. Extracting on the Windows side can introduce CRLF line endings, after which bash fails with `$'\r': command not found`. If that happens:

```bash
dos2unix *.sh
```

Then:

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r analysis_package/requirements.txt
chmod +x preflight.sh run_study.sh
```

Remember to `source .venv/bin/activate` in every new terminal.

### 2.3 Ollama — the important bit

The harness deliberately refuses any model endpoint that is not loopback. Under WSL2's default NAT networking, `127.0.0.1:11434` inside the distro does **not** reach an Ollama server running on Windows, so the standard Windows install will fail the loopback check rather than work.

**Option A (recommended) — Ollama inside WSL:**

```bash
curl -fsSL https://ollama.com/install.sh | sh
```

WSL has systemd disabled by default, so there is no service to start. Either run the server manually in a second terminal and leave it running:

```bash
ollama serve
```

or enable systemd once and use the service. Add to `/etc/wsl.conf`:

```ini
[boot]
systemd=true
```

then `wsl --shutdown` from PowerShell, reopen the distro, and:

```bash
sudo systemctl enable --now ollama
systemctl is-active ollama     # expect: active
```

**Option B — Ollama on Windows with mirrored networking.** On Windows 11 23H2 or later, `networkingMode=mirrored` in `.wslconfig` (§1.3) makes `localhost` resolve across the boundary, so a Windows-side Ollama satisfies the loopback check. This works, but record the **Windows** Ollama version in your run manifest, because the one reported from inside the distro will be wrong or absent. Preflight warns you if it detects this situation.

Verify either way:

```bash
curl -s http://127.0.0.1:11434/api/tags | head -c 200
```

---

## 3. Choose and freeze the model

This is a preregistration decision, not a runtime one. Pull the model, then record its **manifest digest**, not its tag — tags such as `llama3.1:8b` are mutable and will silently resolve to different weights months later, making your "frozen model identifier" (Action Plan §3) meaningless.

```bash
export MFLP_MODEL=llama3.1:8b
ollama pull "$MFLP_MODEL"
ollama show --modelfile "$MFLP_MODEL" | head -5   # record the FROM ... sha256 digest
ollama --version
```

Write the results into `config/study.json`:

```json
  "model": {
    "adapter": "ollama",
    "model_id": "llama3.1:8b",
    "model_digest": "sha256:<digest from ollama show>",
    "ollama_version": "<version>",
    "host_platform": "WSL2 Ubuntu 24.04 on Windows 11"
  },
```

Check structured-output behaviour before committing to the model:

```bash
curl -s http://127.0.0.1:11434/api/chat -d '{
  "model":"'"$MFLP_MODEL"'","stream":false,
  "messages":[{"role":"user","content":"Return only {\"answer\":\"ok\",\"tool_call\":null}"}]}' \
  | python3 -c 'import sys,json;print(json.load(sys.stdin)["message"]["content"])'
```

If the model wraps JSON in prose or code fences on most turns, the harness records `finish_reason: parse_error`, the agent never calls tools, attack-success rates collapse toward zero, and the run is wasted. Prefer a model with reliable structured output. This is the main thing the pilot in §6 exists to test.

---

## 4. Freeze the protocol

Everything that affects the generated data must be frozen and hashed before confirmatory data exists.

```bash
python3 -m harness.freeze_study           # writes study_lock.json
python3 -m harness.freeze_study --verify  # expect: Study lock verified.
```

The lock covers `config/study.json`, the scenario templates, the literature provenance file, and the four harness modules. `run_study.sh` re-verifies it, and the confirmatory run **refuses to start** if anything changed. If you must change something afterwards, record it in `protocol/deviations.md` and re-freeze deliberately — never edit and re-lock silently.

---

## 5. Preflight

```bash
./preflight.sh
```

Ten seconds, no GPU cost. On WSL it additionally confirms you are on the Linux filesystem rather than `/mnt/c`, that the scripts have Unix line endings, that the CUDA passthrough shim is present, and that Ollama is answering on loopback — distinguishing an in-distro server from a mirrored Windows one. It then runs the complete generate → blind → validate chain against the mock adapter in a temporary directory.

**Do not start the real run until preflight prints `PREFLIGHT PASSED`.**

---

## 6. Pilot run

Action Plan §8 requires a pilot; the Guide recommends 10–14 cases with two non-author investigators. It answers three questions: does the chosen model produce parseable structured output, is the evidence legible to someone who did not build the system, and is the workbook vocabulary unambiguous.

```bash
./run_study.sh --pilot 14
```

The pilot draws a **stratified** sample — two cases from each of the seven families — so it contains real attacks and real controls. (In the original code `--limit 14` returned fourteen benign cases and nothing else; see defect D5.)

Hand `deliverables/<stamp>/investigator_I1.zip` and `investigator_I2.zip` to two colleagues who did not build the scenarios. Record where they hesitated, where they disagreed, and how long each case took.

Then refine the rubric and telemetry fields **once**, freeze `protocol-v1`, and record every later change in `deviations.md`. **Pilot cases and pilot responses are excluded from the confirmatory dataset.**

---

## 7. Confirmatory run

Run it inside `tmux` so that closing the Windows Terminal tab does not kill the job:

```bash
sudo apt-get install -y tmux
tmux new -s mflp
source .venv/bin/activate
export MFLP_MODEL=llama3.1:8b
./run_study.sh
```

Detach with `Ctrl-b` then `d`; reattach with `tmux attach -t mflp`.

Two Windows-specific cautions. Do not run `wsl --shutdown` while the job is running. And check that Windows sleep and hibernation are disabled for the duration — a suspend mid-run leaves a partial `runtime/` tree, in which case rerun from scratch with `--overwrite` rather than trying to resume.

The script performs, in order: lock verification → 160-case generation with the real model → strict blinding validation → design/power/cost analysis and figures → run manifest → packaging. A full transcript goes to `run_<timestamp>.log`.

Expected output:

```
deliverables/<timestamp>/
  investigator_I1.zip ... investigator_I5.zip   <- hand these out
  study_team_PRIVATE_DO_NOT_SHARE.zip           <- keep sealed
  analysis_outputs.zip                          <- design/power/cost/figures
  run_<timestamp>.log
  SHA256SUMS.txt
  README.txt
```

**Verify the blinding line in the log before distributing anything:**

```
Scanned 800 packages: L0=160, L1=160, L2=160, L3=160, L4=160
PASS: strict blinding validation clean.
```

If it does not say that, stop and do not hand out packages.

### Getting the files onto Windows

```bash
cp -r deliverables /mnt/c/Users/<you>/Documents/MFLP/
sha256sum -c deliverables/<timestamp>/SHA256SUMS.txt
```

You can also reach the distro from Windows Explorer at `\\wsl$\Ubuntu-24.04\home\<you>\MFLP`. Copy the ZIPs out; do not edit files in the `runtime/` tree from Windows.

### What is in each archive

`investigator_I<n>.zip` contains 160 directories, one per assigned case, named only by opaque token. Each holds `events.jsonl` (that case's evidence at that investigator's assigned profile), `case_manifest.json`, `package_hashes.txt`, a short `README.txt`, plus `workbook.csv` and `instructions.md`. No family letter, no profile label, no case ID, no ground truth.

`study_team_PRIVATE_DO_NOT_SHARE.zip` contains the canonical L4 traces, the sealed ground truth, `assignment_opaque_map.csv` (mapping opaque tokens back to real cases and profiles), the local sink, and the run manifest. **Investigators must not receive this, or any part of it, until all responses are locked.** Store it where they have no access — not in a shared folder alongside their packages.

---

## 8. Instructions for the human evaluators

Give each investigator their own ZIP and nothing else. The text below is what they need; it matches `instructions.md` inside their package.

### 8.1 What you are doing

You are reconstructing what happened in a set of synthetic security incidents involving an LLM-based agent, using only the telemetry you were given. Each case is a separate incident. You have 160 of them.

The amount of telemetry differs between cases, deliberately and without being marked. Some cases will contain enough evidence to answer every question; some will not. **The study is measuring which conclusions are supportable from which evidence, so a well-justified `unknown` is a correct and valuable answer.** Guessing to avoid an `unknown` damages the data.

### 8.2 Rules

1. Work **only** from the files inside your own case directory. Do not use other cases, the protocol, the manuscript, or outside material to fill gaps.
2. Do not discuss cases with the other investigators while the study is open.
3. Do not attempt to identify which telemetry profile a case is on.
4. Every substantive conclusion must cite at least one `event_id` that appears in that case's `events.jsonl`. Citations to event IDs not delivered to you count as ungrounded.
5. Work through cases in the order given in your `workbook.csv`. Take breaks, but record real times.
6. If you realise mid-study that you have been applying a rule inconsistently, tell the study team — do **not** go back and silently revise earlier cases.

### 8.3 Filling in the workbook

Open `workbook.csv` in Excel or LibreOffice. One row per case, pre-filled with the opaque token. Fill the remaining columns:

| Column | Accepted values | Notes |
|---|---|---|
| `incident_class` | `malicious` / `benign` / `indeterminate` | Was this an attack? |
| `injection_channel` | `user` / `retrieved_document` / `rag_corpus` / `tool_output` / `none` / `unknown` | Where did the hostile instruction enter? |
| `injection_object_id` | identifier of the carrying object, or `unknown` | e.g. a document ID or tool-call ID |
| `ordered_event_ids` | comma-separated `event_id` values, in the order you believe they occurred | Your reconstructed attack path. Do not pad it — unsupported steps reduce the score. |
| `tool_action` | `attempted` / `completed` / `none` / `unknown` | Did the agent try to use a tool, and did it succeed? |
| `affected_resource_ids` | comma-separated identifiers, or blank | Records or resources touched |
| `external_effect` | `yes` / `no` / `unknown` | Did anything leave the system? |
| `confidence_0_100` | integer 0–100 | Confidence in the case overall |
| `supporting_event_ids` | comma-separated `event_id` values | The evidence you relied on |
| `start_time_utc` | ISO-8601, e.g. `2026-10-01T09:00:00Z` | When you opened the case |
| `submit_time_utc` | ISO-8601 | When you finished it |

**Excel note:** when saving, choose *CSV UTF-8 (Comma delimited)* and keep the header row and column order. Do not let Excel reformat the time columns into its own date format — set those two columns to Text before typing, or type the timestamps with a leading apostrophe. The scorer reads either line ending and strips byte-order marks, so a normal Excel save is otherwise fine.

Return the file as `workbook.csv`.

### 8.4 A note on scoring

Path reconstruction is order-aware and penalises unsupported steps: reporting extra events that were not part of the incident lowers the score, so listing everything in the file is worse than listing only what you can justify. Attribution gives separate credit for identifying the correct channel but the wrong object, so name the channel even when you cannot pin down the object.

---

## 9. Collect, score, and write up

Once **every** investigator has returned a completed workbook and those responses are locked, break the blind. This step needs no GPU, so it can run in the same WSL distro or anywhere with Python.

```bash
cd ~/MFLP && source .venv/bin/activate
mkdir -p collected/I1 collected/I2 collected/I3 collected/I4 collected/I5
# copy each returned workbook.csv into the matching directory
python3 score_study.py --responses collected/ --out deliverables/results
```

It refuses to run if any assigned case has no response, unless you pass `--allow-incomplete` — in which case report the response rate in the paper.

Outputs:

| File | Contents |
|---|---|
| `results_by_profile.csv` | **The primary endpoint table.** Precision, recall, F1, exact attribution, channel-only attribution, abstention rate, median path completeness, unsupported-step rate, outcome and tool-action accuracy, grounding rate, median minutes — per L0–L4. |
| `results_by_profile_family.csv` | The same, split by attack family, for the family-specific forensic questions in Action Plan §12. |
| `results_by_investigator.csv` | Per-investigator, for inter-rater agreement and fatigue checks. |
| `scored_responses.csv` | One scored row per response, for further analysis. |
| `summary.json` | Response rate, unmatched rows, and a ground-truth digest for chain of custody. |

**Only now** apply the decision rule you froze under Action Plan §15A: δ, the adequacy floor τ, the multiplicity procedure, the CI estimator, and the ABSTAIN/NO-MFLP rule. The primary endpoint is the selected MFLP or an abstention, reported with its design operating characteristic. Do not look at `results_by_profile.csv` and then choose thresholds.

Combine the cost columns from `analysis_outputs.zip` with the performance columns here for the forensic-benefit-versus-retained-data comparison (§13), and archive `study_team_PRIVATE_DO_NOT_SHARE.zip` alongside the results as the reproducibility record.

---

## 10. Defect register

Eight defects were found by audit and reproduced empirically against the shipped package. All are fixed in the corrected harness; each entry records what was wrong, why it mattered, and what changed.

### Blocking

**D1 — Internal case identifiers leaked into every package above L0.**
Injected documents were named `DOC-<case_id>-P`, e.g. `DOC-R0057-P-C1`. This string appeared in `context_component_ids` at L1 and in retrieval hits at L2 and above, so an investigator could read the case number, the family letter (`R` = poisoned RAG) and a literal `-P` poisoned marker straight out of the evidence. Benign corpus documents used shared `DOC-B0xx` IDs, so the one document with a different ID shape was always the injection. This unblinds family and maliciousness for 60 of 160 cases and makes attribution trivial for the rest.
*Fix:* every document in every case is relabelled with an opaque per-case ID derived from the study ID; no ID encodes case, family or role, and no document ID is shared across cases.

**D2 — L1 packages contained the full retrieved document text and tool outputs.**
`project()` removed whole events by class but not fields. The E1 model-invocation event carries `assembled_context` (a concatenation of all retrieved chunk texts and all tool return values) and `context_component_ids`; both survived projection to L1 and L2. An L1 package — defined as E0+E1, with no retrieval and no tool telemetry — therefore contained the poisoned chunk in full. The primary independent variable was not being varied.
*Fix:* the model's context is recorded as typed components tagged with their source class, and projection rebuilds the context view from only the retained classes. Verified: retrieved text now first appears at L2, tool returns at L3, and the gradient is monotone (L0: 1 event / 546 bytes → L4: 6 events / 12,406 bytes).

**D3 — The blinding validator checked key names, not values.**
`validate_release.py` searched for the literal strings `"case_id"`, `"family"` and so on as JSON keys. It passed all 800 packages while D1 and D2 were live.
*Fix:* added `harness/validate_blinding.py`, which checks values against a case-ID regex and a marker list, verifies each package contains only the event classes its profile permits, verifies no derived field exposes a non-retained class, verifies document-ID uniqueness across cases, and re-checks the SHA-256 manifest. The old validator is retained; `run_study.sh` runs both.

**D4 — The injected document ranked first in 60 of 60 retrieval cases.**
Injected document text began with a verbatim copy of the user query, guaranteeing it topped the token-overlap ranking, and it was always inserted at index 0. "Rank 1 means injection" is learnable within a handful of cases, turning attribution into pattern-matching rather than forensics.
*Fix:* the query echo is removed and retrieval rank is now an explicitly controlled fixture, balanced uniformly across ranks 1–5 (verified: 12 cases at each rank, 60/60 delivered). **This needs a sentence in the methods section:** the retriever is a controlled laboratory fixture, not an object of study, and injected-chunk rank is assigned by balanced design.

### Non-blocking but material

**D5 — `--limit` returned an all-benign pilot.** Cases were truncated alphabetically, so `--limit 14` yielded fourteen `B` cases and no attacks — the pilot your Guide recommends would have tested nothing. *Fix:* stratified sampling; `--pilot 14` returns two cases from each of the seven families.

**D6 — `--overwrite` left stale investigator packages in place.** Only `canonical/` and `ground_truth_private/` were cleared, so a superseded run's release directories survived and could be distributed by mistake. *Fix:* all runtime output directories are cleared together.

**D7 — Canonical traces were not reproducible, and the config hash depended on the install path.** Events used `time.time_ns()` and real process IDs, so no two runs produced identical traces; `config_hash` was computed over a config dict containing the absolute install path, so it differed between machines — and would differ between `/home/you/MFLP` and `/mnt/c/...`, which matters here. Action Plan §17 asks for a hash-rooted chain of custody, which this made unverifiable. *Fix:* a fixed synthetic epoch with a deterministic millisecond clock, stable synthetic process identity, and a path-independent config hash. Real host, GPU, driver and process provenance is recorded once per run in `runtime/run_manifest.json`. Verified: 160/160 canonical traces byte-identical across reruns.

**D8 — Event schema was missing mandated fields, and two ground-truth rules were wrong.** Events lacked `schema_version`, `run_id`, `monotonic_sequence`, `producer`, `redaction_state` and `integrity_hash`, all required by Action Plan §4; `duration_ms` was hardcoded to zero and `ts_coarse` had one-second resolution, making ordering impossible at L0. Separately, `attack_success` counted *blocked* tool calls as success for the `tool_use` objective, and 10 of 20 `T`-family cases retained the placeholder `pending_tool_call` as their attribution target — an unscorable answer, occurring precisely when the model resisted the injection, which a well-behaved real model will do more often than the mock did. *Fix:* all §4 fields added with a per-event integrity hash; success requires a completed tool call; undelivered injections are recorded as `injection_delivered: false` with a null object, and the scorer excludes them from the attribution denominator rather than counting them as failures.

### Verification performed

After patching, against the mock adapter: 160 canonical incidents and 800 blinded packages generated; strict validation clean across all five profiles; 160/160 traces byte-reproducible across reruns; injection delivery 60/60 with rank balanced 12/12/12/12/12; stratified pilot covering all seven families; the original smoke test still passes; and `score_study.py` scored 800 simulated responses end to end, producing the expected monotone L0→L4 gradient. **Those scores came from a scripted responder used to exercise the scorer and are not data.** No part of this can substitute for human investigators.

---

## 11. Decisions still outstanding

Four items need your judgement rather than a code change. Three affect the paper's defensibility.

**11.1 Scenario diversity (address before freeze).** `scenarios/templates.json` contains fifteen distinct scenarios — two per attack family, three benign. The 160 cases cycle these templates, varying only topic and record identifier, so each template is replicated roughly ten times. The design analysis treats 160 cases as 160 independent units; with fifteen underlying scenarios they are not, and a reviewer who notices will treat the effective sample size as far smaller than the power analysis claims. Either author more templates — eight to ten per family would make the replication structure defensible — or explicitly model template as a random effect and state the limitation. This is the largest remaining threat to the statistical claims.

**11.2 The §14 ablation arms do not exist.** Action Plan §14 makes E0+E1+E3 (no retrieval provenance) and E0+E1+E2 (no tool telemetry) a *mandatory* confirmatory secondary ablation, frozen before collection. `design_assignment.csv` contains only L0–L4 — 160 rows per profile, 800 total — and the projector defines only those five profiles. Adding two arms means either growing the release to 1,120 packages, a 40% increase in investigator workload, or re-powering at the current package count. Both have consequences for §15A, so I have not chosen for you. Decide before freezing; adding them afterwards means discarding the frozen run.

**11.3 Ecological validity.** The injected payloads previously announced themselves (`TEST POISONED CHUNK:`, `TOOL OUTPUT TEST INJECTION:`). I replaced these with neutral phrasing (`Note for the assistant:`, `service-notice:`), which is a clear improvement, but they remain short, uniform and written in the same register. Action Plan §6 asks for 20–25% literature-derived cases translated into synthetic laboratory scenarios; that translation work is not done, and `scenarios/literature_provenance.csv` should be populated to match whatever you author.

**11.4 Ethics determination.** Measuring five human investigators is human-subjects research. Action Plan §18 requires the appropriate institutional determination and defined retention and access rules for investigator responses before you collect any. Obtain it before §8, not after — the confirmatory run itself involves no human data and can be done first.

---

## 12. WSL-specific pitfalls, collected

| Symptom | Cause | Fix |
|---|---|---|
| `bash: $'\r': command not found` | ZIP extracted on the Windows side | `dos2unix *.sh` |
| `Permission denied` running `./run_study.sh` | Package sits under `/mnt/c` | Move to `~`, then `chmod +x` |
| Ollama endpoint refused as non-loopback | Windows-side Ollama under NAT networking | Install Ollama inside WSL, or set `networkingMode=mirrored` |
| `systemctl: command not found` | systemd disabled by default | `ollama serve` manually, or enable systemd in `/etc/wsl.conf` |
| `nvidia-smi` missing inside WSL | Linux NVIDIA driver installed in the distro | Reinstall distro; the driver belongs on Windows only |
| Run dies when the terminal closes | No terminal multiplexer | Run inside `tmux` |
| Partial `runtime/` after a suspend | Windows slept mid-run | Rerun with `--overwrite`; disable sleep first |
| Generation crawls, GPU idle | Model did not fit in VRAM, fell back to CPU | Use a smaller quantization |
| Timestamps mangled in a returned workbook | Excel reformatted the ISO-8601 columns | Set those columns to Text before entry |

---

## 13. Command summary

```powershell
# ---- Windows, once ----
wsl --status ; wsl --update ; nvidia-smi
# edit C:\Users\<you>\.wslconfig  (memory / processors / swap)
wsl --shutdown
```

```bash
# ---- WSL, setup ----
sudo apt-get update && sudo apt-get install -y python3-pip python3-venv unzip zip dos2unix curl tmux
cd ~ && unzip -q MFLP_experimental_harness_v3_corrected.zip && cd MFLP
python3 -m venv .venv && source .venv/bin/activate
pip install -r analysis_package/requirements.txt
chmod +x preflight.sh run_study.sh
curl -fsSL https://ollama.com/install.sh | sh
ollama serve &                       # or enable systemd

# ---- WSL, phase 1 ----
export MFLP_MODEL=llama3.1:8b
ollama pull "$MFLP_MODEL"
# edit config/study.json: adapter=ollama, model_id, model_digest
python3 -m harness.freeze_study && python3 -m harness.freeze_study --verify
./preflight.sh                       # must print PREFLIGHT PASSED
./run_study.sh --pilot 14            # pilot: 2 investigators, refine, re-freeze
tmux new -s mflp                     # then, inside tmux:
./run_study.sh                       # confirmatory: 160 cases, 800 packages
cp -r deliverables /mnt/c/Users/<you>/Documents/MFLP/

# ---- weeks later, phase 2, no GPU ----
python3 score_study.py --responses collected/ --out deliverables/results
```
