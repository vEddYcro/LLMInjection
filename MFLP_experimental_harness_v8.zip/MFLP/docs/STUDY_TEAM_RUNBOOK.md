# Study-team runbook

1. Run `python run_smoke_test.py`.
2. Inspect several canonical traces, ground-truth manifests and blinded projections.
3. Resolve any schema/scoring mismatch before protocol freeze.
4. Freeze code/config/model and archive hashes.
5. Delete smoke-test runtime outputs.
6. Run `python run_confirmatory.py --model <frozen local Ollama model>`.
7. Run `python -m harness.validate_release`.
8. Give each investigator only their `I#` folder, instructions and workbook.
9. Lock completed workbooks before unblinding.
10. Join responses to the private opaque assignment map only after the evaluation phase closes.
11. Run the analysis/scoring pipeline and populate Section 9.

Do not manually edit a canonical trace or blinded package. If a case is invalid, mark it as a protocol deviation and regenerate a new case version under an explicit versioned identifier.
