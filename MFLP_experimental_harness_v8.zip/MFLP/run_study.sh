#!/usr/bin/env bash
# MFLP phase-1 runner: one command, from frozen config to downloadable deliverables.
#
#   export MFLP_MODEL=llama3.1:8b
#   ./run_study.sh                 # full 160-case confirmatory run
#   ./run_study.sh --pilot 14      # stratified pilot, no lock required
#
# Everything an investigator receives, and everything you need to keep private,
# ends up under deliverables/ as separate archives.
set -euo pipefail
cd "$(dirname "$0")"

MODEL="${MFLP_MODEL:-}"
ENDPOINT="${MFLP_ENDPOINT:-http://127.0.0.1:11434}"
PILOT=0
ROBUSTNESS=0
while [ $# -gt 0 ]; do
  case "$1" in
    --pilot) PILOT="${2:-14}"; shift 2 ;;
    --robustness) ROBUSTNESS=1; shift ;;
    --model) MODEL="$2"; shift 2 ;;
    *) echo "unknown argument: $1"; exit 2 ;;
  esac
done
[ -z "$MODEL" ] && { echo "Set MFLP_MODEL or pass --model"; exit 2; }

SLUG=$(printf '%s' "$MODEL" | tr ':/' '__' | tr -cd 'A-Za-z0-9_.-')
STAMP="$(date -u +%Y%m%dT%H%M%SZ)_${SLUG}"
LOG="run_${STAMP}.log"
exec > >(tee -a "$LOG") 2>&1
echo "=== MFLP run $STAMP | model=$MODEL | pilot=$PILOT ==="

echo "--- [0/6] environment"
python3 -c "import numpy,scipy,pandas,matplotlib" 2>/dev/null \
  || { echo "FATAL: analysis dependencies missing for $(command -v python3)."
       echo "       Activate the venv (source .venv/bin/activate) or pip install -r analysis_package/requirements.txt."
       echo "       Stopping now rather than at stage 4, after the model run."; exit 3; }
echo "python: $(command -v python3)"

echo "--- [1/6] freeze verification"
if [ "$PILOT" -eq 0 ]; then
  python3 -m harness.freeze_study --verify
  FROZEN=$(python3 -c 'import json;print(json.load(open("config/study.json"))["model"].get("model_id",""))')
  if [ "$MODEL" != "$FROZEN" ]; then
    if [ "$ROBUSTNESS" -eq 0 ]; then
      echo "FATAL: --model '$MODEL' is not the frozen model_id '$FROZEN'."
      echo "       The human-study corpus must come from the preregistered model."
      echo "       For a second-model robustness corpus, pass --robustness."
      exit 4
    fi
    echo "ROBUSTNESS RUN: $MODEL is not the frozen model. This corpus is for the"
    echo "section 15 replication only and must NOT be given to investigators."
  else
    echo "primary confirmatory run: model matches frozen model_id"
  fi
else
  echo "pilot run: lock not enforced (pilot data must be excluded from the confirmatory set)"
fi

echo "--- [2/6] generating incidents and running the agent"
ARGS=(--adapter ollama --model "$MODEL" --endpoint "$ENDPOINT" --overwrite)
[ "$PILOT" -gt 0 ] && ARGS+=(--limit "$PILOT") || ARGS+=(--confirmatory)
time python3 -m harness.run_experiment "${ARGS[@]}"

echo "--- [3/6] blinding validation (strict)"
python3 -m harness.validate_release
python3 -m harness.validate_blinding

echo "--- [4/6] design, power, cost and figures"
( cd analysis_package && python3 run_all.py --quick )

echo "--- [5/6] run manifest"
python3 - "$MODEL" "$ENDPOINT" "$STAMP" <<'PY'
import json,sys,hashlib,platform,subprocess,os
from pathlib import Path
model,endpoint,stamp=sys.argv[1:4]
def sh(c):
    try: return subprocess.check_output(c,shell=True,text=True,stderr=subprocess.DEVNULL).strip()
    except Exception: return None
files={}
for rel in ["config/study.json","scenarios/templates.json","harness/engine.py",
            "harness/generate_cases.py","harness/model_adapters.py","harness/run_experiment.py"]:
    files[rel]=hashlib.sha256(Path(rel).read_bytes()).hexdigest()
man={"run_stamp_utc":stamp,"model_id":model,"endpoint":endpoint,
     "ollama_version":sh("ollama --version"),
     "model_manifest":sh(f"ollama show --modelfile {model} | head -5"),
     "gpu":sh("nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader"),
     "host":{"platform":platform.platform(),"python":platform.python_version()},
     "file_hashes":files,
     "n_canonical":len(list(Path("runtime/canonical").glob("*.jsonl"))),
     "n_packages":len(list(Path("runtime/investigator_release").glob("I*/CASE-*")))}
Path("runtime/run_manifest.json").write_text(json.dumps(man,indent=2))
print(json.dumps({k:man[k] for k in ("n_canonical","n_packages","gpu")},indent=2))
PY

echo "--- [6/6] packaging deliverables"
OUT="deliverables/${STAMP}"
mkdir -p "$OUT"
for I in runtime/investigator_release/I*; do
  INV=$(basename "$I")
  STAGE=$(mktemp -d)
  cp -r "$I" "$STAGE/$INV"
  cp analysis_package/investigator_kit/instructions.md "$STAGE/$INV/"
  ( cd "$STAGE" && zip -qr "$OLDPWD/$OUT/investigator_${INV}.zip" "$INV" )
  rm -rf "$STAGE"
done
zip -qr "$OUT/study_team_PRIVATE_DO_NOT_SHARE.zip" \
  runtime/canonical runtime/ground_truth_private runtime/study_team_private \
  runtime/run_manifest.json runtime/local_sink 2>/dev/null
zip -qr "$OUT/analysis_outputs.zip" analysis_package/out analysis_package/figs
cp "$LOG" "$OUT/"
( cd "$OUT" && sha256sum ./*.zip > SHA256SUMS.txt )

cat > "$OUT/README.txt" <<EOF
MFLP run $STAMP
model: $MODEL
pilot: $PILOT
robustness: $ROBUSTNESS   (1 = second-model replication corpus, NOT for investigators)

investigator_I1.zip .. investigator_I5.zip
    Hand exactly one of these to each investigator. They contain blinded evidence
    packages, a pre-populated workbook.csv, and the instructions. Nothing else.

study_team_PRIVATE_DO_NOT_SHARE.zip
    Canonical L4 traces, sealed ground truth, the opaque-token map, and the run
    manifest. Investigators must not receive this before responses are locked.

analysis_outputs.zip
    Design, power, cost tables and figures 1-8.

After collecting completed workbooks into collected/I1/workbook.csv .. collected/I5/workbook.csv:
    python3 score_study.py --responses collected/ --out deliverables/results
EOF

echo
echo "DONE. Download this directory:"
ls -lh "$OUT"
