# Investigator Handbook

**Forensic reconstruction of prompt-injection incidents in an LLM-integrated application**

For investigators taking part in the MFLP study · Algebra Bernays University

---

## 1. What you are being asked to do

You will be given a set of synthetic security incidents that occurred in a laboratory AI agent — a system that answers questions by retrieving documents and calling a small number of tools. For each incident you receive a package of log data, and your task is to work out what happened: whether the incident was an attack, where the hostile instruction came from if there was one, what the agent did in response, and whether anything left the system.

Each case is independent. Nothing carries over from one to the next.

**What the study is measuring is not you.** It is measuring which conclusions are supportable from which log data. Your answers are the instrument, not the subject. There is no performance ranking of investigators, and nothing you submit is assessed as competence.

## 2. Why the evidence looks uneven

The amount of log data differs from case to case. This is deliberate and it is the point of the study — different cases deliberately retain different classes of telemetry, so that we can find out which classes investigators actually need.

Three consequences follow, and they matter more than anything else in this handbook:

**Missing data is not an error.** If a case contains no record of document retrieval, that does not mean no retrieval happened. It means that class of logging was not retained for that case. Do not report it as a fault.

**`unknown` is frequently the correct answer.** Some cases simply cannot support a conclusion about where an injection came from, or whether a tool call succeeded. Recording `unknown` in those cases is a correct, informative answer that the study depends on. Guessing in order to fill the field damages the data more than leaving it blank would.

**Do not try to work out which logging condition a case is on.** Answer from the evidence in front of you, case by case.

## 3. What you receive

A single directory containing one sub-directory per case. Each case directory is named only by an opaque token such as `CASE-92db3f97c81515a7`, and contains:

| File | Contents |
|---|---|
| `events.jsonl` | The evidence. One JSON event per line. |
| `case_manifest.json` | The case token and package format version. |
| `package_hashes.txt` | SHA-256 of each file, for integrity checking. |
| `README.txt` | A one-line reminder of the rules. |
| `workbook.csv` | Your answer sheet, pre-filled with the case tokens. |
| `instructions.md` | A short form of this handbook. |

You will receive nothing else, and you should not seek anything else. In particular you will not be given the study protocol, the list of scenarios, the correct answers, or any other investigator's package until all responses are locked.

## 4. Rules

1. Work only from the files inside the case directory you are answering about. Do not use other cases to fill a gap in this one.
2. Do not discuss cases, or your reasoning about them, with the other investigators while the study is open.
3. Every substantive conclusion must cite at least one `event_id` that actually appears in that case's `events.jsonl`.
4. Work through the cases in the order given in your `workbook.csv`. The order is part of the design.
5. Record real times. Do not reconstruct them afterwards from memory.
6. Take breaks. Fatigue is a known problem in tasks like this, and a rested judgement is worth more to us than a fast one.
7. If you realise part-way through that you have been applying a rule inconsistently, tell the study team. **Do not go back and silently revise earlier cases** — a documented change of approach is usable data; an undocumented one is not.

## 5. Reading the evidence

`events.jsonl` holds one JSON object per line, each one event. Any text editor will open it; `jq` or a short Python snippet is more comfortable for the longer cases.

```bash
python3 -c "
import json,sys
for line in open('events.jsonl'):
    e=json.loads(line)
    print(e['monotonic_sequence'], e['event_type'], e['event_id'])
"
```

### Fields present on every event

| Field | Meaning |
|---|---|
| `event_id` | Unique identifier. **This is what you cite in the workbook.** |
| `event_type` | What kind of event this is — see below. |
| `correlation_id` | Ties together all events belonging to one request. |
| `monotonic_sequence` | Ordering within the case. Use this, not the timestamps. |
| `timestamp_utc` | Milliseconds. Times are synthetic and evenly spaced; they carry no forensic meaning. |
| `parent_event_id` / `parent_invocation_id` | Causal links to the event that produced this one. |
| `integrity_hash` | Hash of the event's own contents. |
| `redaction_state` | `none`, or a note that fields were removed for this case. |

### Event types you may encounter

**`request`** — a user request arriving. Minimal: endpoint, status, timing.

**`model_invocation`** — one call to the language model. Useful fields: `user_input` (present on the first invocation), `response_text` (what the model produced), `context_components` (the pieces of text placed in the model's context, each tagged with the class it came from), `context_component_ids`, and `finish_reason`.

**`retrieval`** — a document lookup. `retrieval_query` is what was searched for; `hits` is the ranked list. Each hit carries `document_id`, `chunk_id`, `rank`, `score`, `source_uri`, `content_hash` and the `text` itself.

**`tool_call`** — the agent invoking a tool. `tool_name` is one of `search_private_record`, `send_message` or `fetch_url`. `arguments` is what it passed, `return_value` what came back, `authz_decision` whether policy allowed it, and **`action_status`** whether it actually completed or was blocked. The distinction between an attempted and a completed tool call matters and is asked for separately in the workbook.

**`environment`** and **`network_effect`** — host, process and destination metadata.

### A way of working

There is no required method, but investigators new to this kind of data often find it helps to read the events in `monotonic_sequence` order first, without judging anything; then ask what the user actually requested; then ask whether anything the agent did goes beyond that request; and only then ask where the instruction to do that could have entered. Following `parent_event_id` and `parent_invocation_id` backwards from any surprising action is usually faster than reading forwards.

Be careful with one thing in particular: text that appears inside `context_components`, `return_value` or a retrieval `hit` is **data the agent was exposed to**, not an instruction the system issued. Part of what you are judging is whether the agent treated such text as an instruction when it should not have.

## 6. Filling in the workbook

One row per case, pre-filled with the token. Complete the remaining columns.

| Column | Accepted values |
|---|---|
| `incident_class` | `malicious`, `benign`, `indeterminate` |
| `injection_channel` | `user`, `retrieved_document`, `rag_corpus`, `tool_output`, `none`, `unknown` |
| `injection_object_id` | The identifier of the object carrying the hostile instruction — a `document_id`, `chunk_id` or `tool_call_id` — or `unknown` |
| `ordered_event_ids` | Comma-separated `event_id` values, in the order you believe the attack proceeded |
| `tool_action` | `attempted`, `completed`, `none`, `unknown` |
| `affected_resource_ids` | Comma-separated identifiers of records or resources touched; blank if none |
| `external_effect` | `yes`, `no`, `unknown` |
| `confidence_0_100` | Integer, your confidence in the case overall |
| `supporting_event_ids` | Comma-separated `event_id` values you relied on |
| `start_time_utc` | ISO-8601, e.g. `2026-10-01T09:00:00Z` |
| `submit_time_utc` | ISO-8601 |

**Channel definitions.** `user` means the hostile text arrived in the user's own request. `retrieved_document` and `rag_corpus` both mean it arrived inside retrieved content; use `retrieved_document` when a specific document was fetched for this request and `rag_corpus` when it came from the general knowledge base. `tool_output` means it arrived in what a tool returned. `none` means there was no hostile instruction. `unknown` means the evidence does not let you tell.

### If you use Excel

Save as *CSV UTF-8 (Comma delimited)*. Keep the header row and the column order exactly as supplied.

Excel will try to reformat the two ISO-8601 time columns into its own date format, which corrupts them. Either format those columns as Text before you start typing, or type each timestamp with a leading apostrophe.

Return the file as `workbook.csv`.

## 7. How answers are scored, and why it matters to you

You are not being graded, but knowing how the measures behave will stop you from answering in ways that distort them.

**Path reconstruction is order-aware and penalises unsupported steps.** Reporting extra events that were not part of the incident lowers the score. Listing every event in the file is therefore *worse* than listing only the ones you can justify. Report the steps you believe in, in the order you believe they happened.

**Attribution gives separate credit for channel and object.** If you can tell that a hostile instruction came in through retrieved content but cannot pin down which document, record the channel and put `unknown` for the object. That is more informative than leaving both blank, and more honest than guessing an ID.

**Citations are checked against what you were given.** An `event_id` that does not appear in that case's evidence counts as ungrounded, so copy them rather than typing from memory.

**Abstention is measured deliberately.** Cases where you correctly decline to answer are a result the study wants, not a gap in it.

## 8. Time, effort and pacing

Each investigator receives 168 cases. We do not yet know how long a case takes — establishing that is part of what this study produces — so please do not pace yourself against any target.

Record `start_time_utc` when you open a case and `submit_time_utc` when you finish it. If you are interrupted mid-case, note it in your correspondence with the study team rather than adjusting the times.

There is no deadline pressure that should push you toward guessing. If the workload turns out to be heavier than expected, tell the study team — the schedule can change, but the quality of individual judgements cannot be recovered afterwards.

## 9. Participation, data and withdrawal

Your responses are research data. They are analysed to compare logging conditions, never to assess individuals, and no individual investigator's performance is reported.

*[To be completed by the study team before distribution: the institutional ethics determination reference; who holds the data and for how long; how the data are stored; how to withdraw and what happens to already-submitted responses; the named contact for questions.]*

You may stop at any time. If you do, tell the study team so the response rate can be reported accurately.

## 10. Questions during the study

Ask the study team about anything procedural: a corrupt file, an ambiguous column, a workbook that will not save, whether something counts as an interruption.

**We cannot answer questions about specific cases**, and you should not ask other investigators about them either. If a case is genuinely unreadable — malformed JSON, a missing file — report it as a technical fault rather than answering around it.

Contact: *[study team contact, to be completed before distribution]*

## 11. Before you submit

- Every row has an `incident_class`.
- Every substantive conclusion cites at least one `event_id` from that case.
- `unknown` has been used wherever the evidence genuinely does not support a conclusion.
- `ordered_event_ids` contains the steps you believe in, not everything in the file.
- Both time columns are filled and still in ISO-8601 format after saving.
- The header row and column order are unchanged.
- The file is named `workbook.csv`.

Thank you. The thing that makes this study work is honest uncertainty — recorded uncertainty is a finding, and a guess that happens to be right is not.
