
import argparse,subprocess,sys
ap=argparse.ArgumentParser()
ap.add_argument("--model",required=True,help="Local Ollama model identifier, e.g. llama3.1:8b")
ap.add_argument("--endpoint",default="http://127.0.0.1:11434")
a=ap.parse_args()
subprocess.check_call([sys.executable,"-m","harness.run_experiment","--adapter","ollama","--model",a.model,"--endpoint",a.endpoint,"--confirmatory"])
subprocess.check_call([sys.executable,"-m","harness.validate_release"])
