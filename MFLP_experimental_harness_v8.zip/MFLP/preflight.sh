#!/usr/bin/env bash
# MFLP preflight. Run this BEFORE the confirmatory study. It costs nothing and
# catches every failure mode that would otherwise waste GPU hours.
set -uo pipefail
cd "$(dirname "$0")"
FAIL=0
ok()   { printf '  \033[32mOK\033[0m   %s\n' "$1"; }
bad()  { printf '  \033[31mFAIL\033[0m %s\n' "$1"; FAIL=1; }
warn() { printf '  \033[33mWARN\033[0m %s\n' "$1"; }

IS_WSL=0
grep -qi microsoft /proc/version 2>/dev/null && IS_WSL=1

echo "== 1. Host =="
if [ $IS_WSL -eq 1 ]; then
  ok "running under WSL2 ($(uname -r))"
  case "$PWD" in
    /mnt/[a-z]/*) bad "working directory is on the Windows filesystem ($PWD).
         Move the package to the Linux home, e.g. ~/MFLP_experimental_harness:
         chmod +x will not persist here and 800 package writes will be very slow." ;;
    *) ok "working directory is on the Linux filesystem" ;;
  esac
  printf '%s' "$(cat preflight.sh)" | grep -q $'\r' \
    && bad "scripts contain CRLF line endings; run: dos2unix *.sh" \
    || ok "scripts have Unix line endings"
fi
python3 -c 'import sys; assert sys.version_info>=(3,11)' 2>/dev/null \
  && ok "python $(python3 -V 2>&1 | cut -d' ' -f2)" || bad "python 3.11+ required"
python3 -c 'import numpy,scipy,pandas,matplotlib' 2>/dev/null \
  && ok "numpy/scipy/pandas/matplotlib present" \
  || bad "pip install -r analysis_package/requirements.txt"
if command -v nvidia-smi >/dev/null; then
  ok "GPU: $(nvidia-smi --query-gpu=name,memory.total --format=csv,noheader | head -1)"
  if [ $IS_WSL -eq 1 ] && [ ! -e /usr/lib/wsl/lib/libcuda.so.1 ]; then
    warn "no /usr/lib/wsl/lib/libcuda.so.1: GPU passthrough may not be active"
  fi
else
  if [ $IS_WSL -eq 1 ]; then
    warn "no nvidia-smi: install the NVIDIA driver on WINDOWS (not inside WSL);
         a Linux driver installed in the distro breaks GPU passthrough"
  else
    warn "no nvidia-smi: the run will fall back to CPU and take many hours"
  fi
fi
df -BG --output=avail . | tail -1 | awk '{gsub("G","");
  if ($1+0 < 20) print "  \033[33mWARN\033[0m only " $1 "G free (20G+ recommended)";
  else print "  \033[32mOK\033[0m   " $1 "G disk free"}'

echo "== 2. Model =="
if ! command -v ollama >/dev/null; then
  bad "ollama not installed"
else
  ok "ollama $(ollama --version 2>&1 | head -1)"
  if curl -sf --max-time 5 http://127.0.0.1:11434/api/tags >/dev/null; then
    ok "ollama reachable on loopback"
    if [ $IS_WSL -eq 1 ]; then
      # The harness requires a loopback endpoint. Under default WSL2 NAT networking a
      # Windows-side Ollama is NOT reachable on 127.0.0.1, so if this responds the
      # server is either inside the distro (fine) or mirrored networking is on (fine).
      if pgrep -x ollama >/dev/null; then
        ok "ollama server process is inside WSL"
      else
        warn "no ollama process inside WSL: you are reaching a Windows-side server
         through mirrored networking. That satisfies the loopback check, but record
         the Windows Ollama version in the run manifest, not the WSL one."
      fi
    fi
  else
    if [ $IS_WSL -eq 1 ]; then
      bad "ollama not responding on 127.0.0.1:11434.
         Under WSL, systemd is off unless enabled, so there is no service to start.
         Run in a second terminal:  ollama serve
         (or enable systemd in /etc/wsl.conf and then: sudo systemctl start ollama)"
    else
      bad "ollama not responding on 127.0.0.1:11434 (systemctl start ollama)"
    fi
  fi
  # Verify every model the study will use. MFLP_MODELS (space separated) overrides
  # MFLP_MODEL; otherwise fall back to the frozen model_id in config/study.json.
  CHECK_MODELS="${MFLP_MODELS:-${MFLP_MODEL:-}}"
  if [ -z "$CHECK_MODELS" ]; then
    CHECK_MODELS=$(python3 -c 'import json;print(json.load(open("config/study.json"))["model"].get("model_id",""))' 2>/dev/null)
    [ -n "$CHECK_MODELS" ] && warn "MFLP_MODEL not set; checking frozen model_id instead"
  fi
  if [ -z "$CHECK_MODELS" ]; then
    warn "no model to check; export MFLP_MODEL or MFLP_MODELS"
  else
    for M in $CHECK_MODELS; do
      if ! ollama show --modelfile "$M" >/dev/null 2>&1; then
        bad "model '$M' not pulled"
        continue
      fi
      # A model that exists can still 404 or emit unparseable output. Generate for real.
      RESP=$(curl -sf --max-time 300 http://127.0.0.1:11434/api/chat \
        -d "{\"model\":\"$M\",\"stream\":false,\"options\":{\"temperature\":0},
             \"messages\":[{\"role\":\"user\",\"content\":\"Return only this and nothing else: {\\\"answer\\\":\\\"ok\\\",\\\"tool_call\\\":null}\"}]}" 2>/dev/null)
      if [ -z "$RESP" ]; then
        bad "$M: endpoint returned no response (model missing from this server's store?)"
        continue
      fi
      VERDICT=$(printf '%s' "$RESP" | python3 -c '
import sys,json
try: txt=json.load(sys.stdin)["message"]["content"].strip()
except Exception as e: print("BAD no usable response"); raise SystemExit
if "```" in txt:
    txt=txt.split("```")[1].replace("json","",1).strip()
try:
    obj=json.loads(txt)
    print("OK structured JSON" if isinstance(obj,dict) and "answer" in obj else "WARN JSON but unexpected shape")
except Exception:
    print("WARN returned prose, not JSON: parse_error risk")
' 2>/dev/null)
      case "$VERDICT" in
        OK*)   ok   "$M loads and returns ${VERDICT#OK }" ;;
        WARN*) warn "$M: ${VERDICT#WARN }" ;;
        *)     bad  "$M: ${VERDICT#BAD }" ;;
      esac
    done
  fi
fi

echo "== 3. Study configuration =="
python3 - <<'PY'
import json,sys
from pathlib import Path
cfg=json.loads(Path("config/study.json").read_text())
ok=lambda m: print(f"  \033[32mOK\033[0m   {m}")
bad=lambda m: (print(f"  \033[31mFAIL\033[0m {m}"), sys.exit(9))
if cfg["model"]["adapter"]=="mock":
    print("  \033[31mFAIL\033[0m config/study.json still has adapter=mock; set it to the frozen model")
    sys.exit(9)
ok(f"adapter={cfg['model']['adapter']} model_id={cfg['model']['model_id']}")
if "@sha256" not in cfg["model"]["model_id"] and ":" in cfg["model"]["model_id"]:
    print("  \033[33mWARN\033[0m model_id is a mutable tag; record the manifest digest too")
n=sum(cfg["cases"].values()); ok(f"{n} cases configured")

# The model you are about to RUN must be the model you FROZE.
import os
env=os.environ.get("MFLP_MODEL","")
frozen=cfg["model"].get("model_id","")
if env and frozen and env!=frozen:
    print(f"  \033[31mFAIL\033[0m MFLP_MODEL ({env}) does not match frozen model_id ({frozen});")
    print( "         you would generate confirmatory data under a model you did not preregister")
    sys.exit(9)
elif env and frozen:
    ok(f"MFLP_MODEL matches frozen model_id")
if not cfg["model"].get("model_digest"):
    print("  \033[33mWARN\033[0m no model_digest recorded; the tag alone is not a frozen identifier")
PY
[ $? -ne 0 ] && FAIL=1

echo "== 4. Protocol freeze =="
if [ -f study_lock.json ]; then
  python3 -m harness.freeze_study --verify >/dev/null 2>&1 \
    && ok "study lock verified" || bad "study lock MISMATCH; do not run confirmatory data"
else
  warn "no study_lock.json yet: run 'python3 -m harness.freeze_study' after config is final"
fi

echo "== 5. Pipeline dry run (mock, ~2s) =="
TMP=$(mktemp -d)
cp -r harness config scenarios corpus analysis_package "$TMP"/ 2>/dev/null
( cd "$TMP" && python3 -m harness.run_experiment --adapter mock --model mock --overwrite >/dev/null 2>&1 \
  && python3 -m harness.validate_blinding >/dev/null 2>&1 ) \
  && ok "full generate -> blind -> validate chain passes" \
  || bad "dry run failed; do not start the paid run"
rm -rf "$TMP"

echo
[ $FAIL -eq 0 ] && echo "PREFLIGHT PASSED — safe to run ./run_study.sh" \
               || { echo "PREFLIGHT FAILED — fix the items above first"; exit 1; }
