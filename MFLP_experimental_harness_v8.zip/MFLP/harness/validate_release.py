
import csv,json,sys
from pathlib import Path
BAD_KEYS={"case_id","family","profile","_class","attack_success","injection_source"}
def main():
    root=Path(__file__).resolve().parents[1]
    rel=root/"runtime/investigator_release"
    if not rel.exists(): raise SystemExit("No investigator release. Run experiment first.")
    bad=[]
    packages=0
    for p in rel.glob("I*/CASE-*"):
        packages+=1
        txt="\n".join(x.read_text(errors="ignore") for x in p.glob("*") if x.is_file())
        for k in BAD_KEYS:
            if f'"{k}"' in txt: bad.append((str(p),k))
        man=json.loads((p/"case_manifest.json").read_text())
        if "opaque_case_token" not in man: bad.append((str(p),"missing opaque token"))
    if bad:
        print("FAIL",bad[:20]); return 1
    print(f"PASS: {packages} blinded packages scanned; no forbidden study-team labels found.")
    return 0
if __name__=="__main__": raise SystemExit(main())
