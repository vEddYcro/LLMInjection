
import json, hashlib, uuid, time, random, re
from pathlib import Path
def stable_id(prefix, *parts):
    h=hashlib.sha256(("|".join(map(str,parts))).encode()).hexdigest()[:16]
    return f"{prefix}-{h}"
def sha256_text(x):
    return hashlib.sha256(x.encode("utf-8")).hexdigest()
def dump_json(path,obj):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(obj,indent=2,sort_keys=True),encoding="utf-8")
def dump_jsonl(path,rows):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    with open(path,"w",encoding="utf-8") as f:
        for r in rows: f.write(json.dumps(r,sort_keys=True)+"\n")
def load_json(path): return json.loads(Path(path).read_text(encoding="utf-8"))
def utc_ns():
    return time.time_ns()
def safe_tokenize(s):
    return re.findall(r"[a-z0-9_]+",s.lower())
