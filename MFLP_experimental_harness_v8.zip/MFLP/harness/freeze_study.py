
import hashlib, json, argparse
from pathlib import Path

TRACK=("config/study.json","scenarios/templates.json","scenarios/literature_provenance.csv",
       "harness/model_adapters.py","harness/generate_cases.py","harness/engine.py",
       "harness/run_experiment.py")
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def create(root):
    root=Path(root)
    lock={"files":{rel:sha(root/rel) for rel in TRACK}}
    (root/"study_lock.json").write_text(json.dumps(lock,indent=2,sort_keys=True),encoding="utf-8")
    print("Frozen:",root/"study_lock.json")
def verify(root):
    root=Path(root); lp=root/"study_lock.json"
    if not lp.exists(): raise SystemExit("No study_lock.json. Run: python -m harness.freeze_study")
    lock=json.loads(lp.read_text())
    bad=[]
    for rel,expected in lock["files"].items():
        got=sha(root/rel)
        if got!=expected: bad.append((rel,expected,got))
    if bad:
        for x in bad: print("CHANGED:",x[0])
        raise SystemExit("Study lock mismatch; do not run confirmatory data until the change is documented and the protocol is re-frozen.")
    print("Study lock verified.")
if __name__=="__main__":
    ap=argparse.ArgumentParser(); ap.add_argument("--verify",action="store_true")
    ap.add_argument("--root",default=str(Path(__file__).resolve().parents[1]))
    a=ap.parse_args()
    verify(a.root) if a.verify else create(a.root)
