"""Apply the frozen Action Plan section 15A decision rule.

This module turns scored responses into the study's primary endpoint: the selected
Minimum Forensic Logging Profile, or an abstention. Every parameter it uses comes
from config/study.json, which is covered by study_lock.json, so the thresholds
cannot be chosen after seeing the results.

Selection logic
---------------
A candidate profile qualifies as the MFLP when, for every gating outcome:

  1. Non-inferiority to the reference profile: the upper one-sided confidence
     bound on (reference - candidate) is strictly below delta.
  2. Absolute adequacy: the lower one-sided confidence bound on the candidate's
     own value is at or above tau for that outcome.

Both use a cluster bootstrap resampling canonical cases, because responses from
different investigators on the same case are not independent. Non-inferiority
tests are Holm-corrected across all (profile, outcome) pairs.

The MFLP is the cheapest qualifying profile in the frozen cost order. If none
qualifies, the result is ABSTAIN, which is a legitimate study outcome and not a
failure.
"""
import json, math, statistics
from collections import defaultdict


class DecisionRuleError(RuntimeError):
    pass


def load_rule(root):
    cfg = json.loads((root / "config" / "study.json").read_text())
    rule = cfg.get("decision_rule")
    if not rule:
        raise DecisionRuleError(
            "config/study.json has no decision_rule block. The section 15A rule must be "
            "frozen before results are unsealed.")
    missing = [k for k in ("delta", "tau", "gating_outcomes", "reference_profile",
                           "profile_cost_order", "multiplicity", "alpha",
                           "ci_estimator", "bootstrap_reps", "bootstrap_seed")
               if rule.get(k) in (None, "", [], {})]
    if missing:
        raise DecisionRuleError(f"decision_rule is incomplete; missing: {missing}")
    if not rule.get("frozen"):
        raise DecisionRuleError(
            "decision_rule.frozen is false.\n"
            "Set it to true (and frozen_at_utc), then re-run:\n"
            "    python3 -m harness.freeze_study\n"
            "    python3 -m harness.freeze_study --verify\n"
            "Choosing thresholds after seeing results invalidates the primary endpoint.")
    for m in rule["gating_outcomes"]:
        if m not in rule["tau"]:
            raise DecisionRuleError(f"gating outcome '{m}' has no tau threshold")
    return rule


# ---- per-response outcome extraction -------------------------------------

def _outcome(rows, name):
    """Point estimate of one gating outcome over a set of scored rows."""
    if name == "attribution_exact":
        sub = [r for r in rows if r["attribution_scorable"]]
        return (sum(r["attribution_exact"] for r in sub) / len(sub)) if sub else None
    if name == "path_completeness":
        vals = [r["path_completeness"] for r in rows if r["path_completeness"] is not None]
        return (sum(vals) / len(vals)) if vals else None
    if name == "recall":
        tp = sum(1 for r in rows if r["detection"] == "TP")
        fn = sum(1 for r in rows if r["detection"] == "FN")
        return (tp / (tp + fn)) if (tp + fn) else None
    if name == "precision":
        tp = sum(1 for r in rows if r["detection"] == "TP")
        fp = sum(1 for r in rows if r["detection"] == "FP")
        return (tp / (tp + fp)) if (tp + fp) else None
    if name == "grounding_rate":
        vals = [r["grounding_rate"] for r in rows if r["grounding_rate"] is not None]
        return (sum(vals) / len(vals)) if vals else None
    raise DecisionRuleError(f"unknown gating outcome: {name}")


def _by_profile(rows):
    d = defaultdict(list)
    for r in rows:
        d[r["profile"]].append(r)
    return d


# ---- cluster bootstrap ---------------------------------------------------

def _bootstrap(scored, rule):
    """Resample canonical cases with replacement; recompute every profile/outcome.

    Cases are the clusters: the same incident is seen by several investigators at
    different profiles, so responses within a case are dependent.
    """
    import random
    rng = random.Random(rule["bootstrap_seed"])
    by_case = defaultdict(list)
    for r in scored:
        by_case[r["case_id"]].append(r)
    cases = sorted(by_case)
    reps = int(rule["bootstrap_reps"])
    outcomes = rule["gating_outcomes"]
    ref = rule["reference_profile"]

    draws = {p: {m: [] for m in outcomes} for p in rule["profile_cost_order"]}
    diffs = {p: {m: [] for m in outcomes} for p in rule["profile_cost_order"]}

    for _ in range(reps):
        sample = []
        for _ in range(len(cases)):
            sample.extend(by_case[cases[rng.randrange(len(cases))]])
        prof = _by_profile(sample)
        ref_vals = {m: _outcome(prof.get(ref, []), m) for m in outcomes}
        for p in rule["profile_cost_order"]:
            rows = prof.get(p, [])
            for m in outcomes:
                v = _outcome(rows, m)
                if v is not None:
                    draws[p][m].append(v)
                    if ref_vals[m] is not None:
                        diffs[p][m].append(ref_vals[m] - v)
    return draws, diffs


def _quantile(vals, q):
    if not vals:
        return None
    s = sorted(vals)
    i = min(len(s) - 1, max(0, int(math.ceil(q * len(s))) - 1))
    return s[i]


def _boot_p_value(diff_draws, delta):
    """One-sided bootstrap p for H0: (reference - candidate) >= delta."""
    if not diff_draws:
        return 1.0
    n = sum(1 for d in diff_draws if d >= delta)
    return (n + 1) / (len(diff_draws) + 1)


def _holm(pvals, alpha):
    """Holm step-down. pvals maps key -> p. Returns key -> reject(bool)."""
    order = sorted(pvals, key=lambda k: pvals[k])
    m = len(order)
    out, still = {}, True
    for i, k in enumerate(order):
        thresh = alpha / (m - i)
        if still and pvals[k] <= thresh:
            out[k] = True
        else:
            still = False
            out[k] = False
    return out


# ---- the rule -------------------------------------------------------------

def apply_rule(scored, rule):
    delta = float(rule["delta"])
    alpha = float(rule["alpha"])
    ref = rule["reference_profile"]
    outcomes = rule["gating_outcomes"]
    order = rule["profile_cost_order"]

    prof = _by_profile(scored)
    point = {p: {m: _outcome(prof.get(p, []), m) for m in outcomes} for p in order}
    draws, diffs = _bootstrap(scored, rule)

    # non-inferiority tests, Holm-corrected across all (profile, outcome) pairs
    candidates = [p for p in order if p != ref]
    pvals = {(p, m): _boot_p_value(diffs[p][m], delta)
             for p in candidates for m in outcomes}
    if rule["multiplicity"] == "holm":
        reject = _holm(pvals, alpha)
    elif rule["multiplicity"] == "bonferroni":
        reject = {k: v <= alpha / len(pvals) for k, v in pvals.items()}
    else:
        raise DecisionRuleError(f"unsupported multiplicity: {rule['multiplicity']}")

    detail = {}
    for p in order:
        rec = {"point": point[p], "tests": {}}
        for m in outcomes:
            lo = _quantile(draws[p][m], alpha)              # one-sided lower bound
            hi_diff = _quantile(diffs[p][m], 1 - alpha)     # one-sided upper bound on diff
            floor_ok = (lo is not None) and lo >= rule["tau"][m]
            if p == ref:
                ni_ok, pv = True, None
            else:
                ni_ok = bool(reject.get((p, m), False))
                pv = pvals[(p, m)]
            rec["tests"][m] = {
                "point": point[p][m], "ci_lower": lo, "diff_ci_upper": hi_diff,
                "tau": rule["tau"][m], "floor_ok": floor_ok,
                "noninferior": ni_ok, "p_value": pv,
                "passes": bool(floor_ok and ni_ok),
            }
        rec["qualifies"] = all(rec["tests"][m]["passes"] for m in outcomes)
        detail[p] = rec

    selected = next((p for p in order if detail[p]["qualifies"]), None)
    return {
        "primary_endpoint": selected or "ABSTAIN",
        "abstained": selected is None,
        "rule": {k: rule[k] for k in ("delta", "tau", "alpha", "multiplicity",
                                      "ci_estimator", "bootstrap_reps",
                                      "reference_profile", "gating_outcomes",
                                      "profile_cost_order")},
        "profiles": detail,
    }


def format_report(result):
    lines = []
    r = result["rule"]
    lines.append(f"Frozen rule: delta={r['delta']}  alpha={r['alpha']}  "
                 f"reference={r['reference_profile']}  multiplicity={r['multiplicity']}")
    lines.append(f"Gating outcomes: " + ", ".join(
        f"{m} (tau={r['tau'][m]})" for m in r["gating_outcomes"]))
    lines.append("")
    head = f"{'profile':<9}" + "".join(f"{m[:14]:>16}" for m in r["gating_outcomes"]) + "  qualifies"
    lines.append(head)
    lines.append("-" * len(head))
    for p in r["profile_cost_order"]:
        d = result["profiles"][p]
        cells = []
        for m in r["gating_outcomes"]:
            t = d["tests"][m]
            v = f"{t['point']:.3f}" if t["point"] is not None else "-"
            mark = "ok" if t["passes"] else ("floor" if not t["floor_ok"] else "NI")
            cells.append(f"{v} [{mark}]")
        lines.append(f"{p:<9}" + "".join(f"{c:>16}" for c in cells) +
                     ("      YES" if d["qualifies"] else "       no"))
    lines.append("")
    if result["abstained"]:
        lines.append("PRIMARY ENDPOINT: ABSTAIN - no profile met both the non-inferiority")
        lines.append("margin and the absolute adequacy floor. Report this as the result;")
        lines.append("it is not a failed study.")
    else:
        lines.append(f"PRIMARY ENDPOINT: MFLP = {result['primary_endpoint']}")
        lines.append("Report alongside the design operating characteristic (section 15A).")
    return "\n".join(lines)
