"""Strict blinding validator for MFLP investigator releases.

The original validate_release.py only searched for forbidden JSON *key names*
("case_id", "family", ...). It therefore passed packages whose *values* contained
internal case identifiers and poisoning markers. This module checks values, checks
cross-profile evidence leakage, and checks that each profile contains exactly the
evidence classes it is supposed to contain.

Exit code 0 = release is safe to hand to investigators.
"""
import json, re, sys, csv, collections
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

CASE_ID = re.compile(r"\b[DIRTXFB]\d{4}\b")
MARKERS = ("POISON", "INJECTION", "TEST TEXT", "malicious", "attack_success",
           "ground_truth", "/poison", "-P-C1", "pending_tool_call")
FORBIDDEN_KEYS = {"case_id", "family", "profile", "_class", "attack_success",
                  "injection_source", "injection_delivered", "template", "objective",
                  "force_deny", "force_safe"}

# which event_type values may appear at each profile
CLASS_OF = {"request": "E0", "model_invocation": "E1", "retrieval": "E2",
            "tool_call": "E3", "environment": "E4", "network_effect": "E4"}
PROFILE = {"L0": {"E0"}, "L1": {"E0", "E1"}, "L2": {"E0", "E1", "E2"},
           "L3": {"E0", "E1", "E2", "E3"}, "L4": {"E0", "E1", "E2", "E3", "E4"},
           "A_noE2": {"E0", "E1", "E3"}, "A_noE3": {"E0", "E1", "E2"}}


def load_map(root):
    p = root / "runtime/study_team_private/assignment_opaque_map.csv"
    if not p.exists():
        raise SystemExit("Missing assignment_opaque_map.csv; run the experiment first.")
    with open(p, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def check(root=ROOT, verbose=True):
    rel = root / "runtime/investigator_release"
    if not rel.exists():
        raise SystemExit("No investigator release found.")
    rows = load_map(root)
    by_token = {(r["investigator"], r["opaque_case_token"]): r for r in rows}

    failures = []
    counts = collections.Counter()
    doc_ids_by_case = collections.defaultdict(set)

    for pkg in sorted(rel.glob("I*/CASE-*")):
        inv = pkg.parent.name
        token = pkg.name
        meta = by_token.get((inv, token))
        if meta is None:
            failures.append((str(pkg), "package not present in assignment map"))
            continue
        profile = meta["profile"]
        counts[profile] += 1
        allowed = PROFILE[profile]

        blob = "\n".join(f.read_text(errors="ignore")
                         for f in pkg.glob("*") if f.is_file())

        # 1. forbidden key names
        for k in FORBIDDEN_KEYS:
            if f'"{k}"' in blob:
                failures.append((str(pkg), f"forbidden key present: {k}"))

        # 2. internal case identifiers leaked as VALUES
        hit = CASE_ID.search(blob)
        if hit:
            failures.append((str(pkg), f"internal case id leaked in content: {hit.group(0)}"))

        # 3. ground-truth / poisoning markers
        for m in MARKERS:
            if m in blob:
                failures.append((str(pkg), f"marker leaked: {m!r}"))

        # 4. the opaque token must be the only case handle
        if meta["case_id"] in blob:
            failures.append((str(pkg), "real case_id present in package"))

        # 5. evidence-class discipline
        ev_path = pkg / "events.jsonl"
        if not ev_path.exists():
            failures.append((str(pkg), "no events.jsonl"))
            continue
        events = [json.loads(l) for l in ev_path.read_text().splitlines() if l.strip()]
        for e in events:
            cls = CLASS_OF.get(e.get("event_type"))
            if cls is None:
                failures.append((str(pkg), f"unknown event_type {e.get('event_type')!r}"))
            elif cls not in allowed:
                failures.append((str(pkg), f"{profile} contains {cls} event {e.get('event_type')}"))

            # 6. cross-class content leakage through derived fields
            for c in e.get("context_components", []):
                if c.get("source_class") not in allowed:
                    failures.append((str(pkg),
                                     f"{profile} exposes {c.get('source_class')} content via context_components"))
            # assembled_context is rebuilt from retained components only, so it is
            # legitimate whenever those components are legitimate. Flag it only when
            # it exists with no component list to account for its contents.
            if "assembled_context" in e and "context_components" not in e:
                failures.append((str(pkg),
                                 f"{profile} has assembled_context with no component provenance"))

        # 7. document-id shape: collect for cross-case uniqueness check
        for e in events:
            for c in e.get("context_components", []):
                doc_ids_by_case[meta["case_id"]].add(str(c.get("component_id", "")).split("-C")[0])
            for h in e.get("hits", []):
                doc_ids_by_case[meta["case_id"]].add(h.get("document_id", ""))

        # 8. package hash manifest must match
        hp = pkg / "package_hashes.txt"
        if hp.exists():
            import hashlib
            for line in hp.read_text().splitlines():
                if not line.strip():
                    continue
                digest, name = line.split()[0], line.split()[-1]
                f = pkg / name
                if f.exists():
                    got = hashlib.sha256(f.read_bytes()).hexdigest()
                    if got != digest:
                        failures.append((str(pkg), f"hash mismatch for {name}"))

    # 9. no document id may appear in more than one case (would let investigators
    #    correlate packages and identify the odd-one-out document)
    seen = collections.Counter()
    for case, ids in doc_ids_by_case.items():
        for d in ids:
            if d:
                seen[d] += 1
    shared = [d for d, n in seen.items() if n > 1]
    if shared:
        failures.append(("<corpus>", f"{len(shared)} document ids shared across cases, "
                                     f"e.g. {shared[:3]}"))

    if verbose:
        print(f"Scanned {sum(counts.values())} packages: " +
              ", ".join(f"{k}={counts[k]}" for k in sorted(counts)))
    if failures:
        print(f"FAIL: {len(failures)} blinding problems")
        for f in failures[:25]:
            print("  -", f[0], "::", f[1])
        if len(failures) > 25:
            print(f"  ... and {len(failures)-25} more")
        return 1
    print("PASS: strict blinding validation clean.")
    return 0


if __name__ == "__main__":
    sys.exit(check())
