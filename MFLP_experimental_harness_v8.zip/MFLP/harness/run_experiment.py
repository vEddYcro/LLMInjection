
import argparse, csv, json, shutil, hashlib
from pathlib import Path
from .common import *
from .generate_cases import generate
from .engine import run_case, project, adapter_from_args
from .freeze_study import verify as verify_lock

def file_sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument("--adapter",choices=["mock","ollama"],default="mock")
    ap.add_argument("--model",default="llama3.1:8b")
    ap.add_argument("--endpoint",default="http://127.0.0.1:11434")
    ap.add_argument("--limit",type=int,default=0)
    ap.add_argument("--confirmatory",action="store_true")
    ap.add_argument("--overwrite",action="store_true")
    a=ap.parse_args(); root=Path(a.root)
    cfg=load_json(root/"config/study.json"); cfg["_root"]=str(root)
    if a.confirmatory and a.adapter=="mock":
        raise SystemExit("REFUSED: mock adapter is smoke-test only and cannot run a confirmatory study.")
    if a.confirmatory:
        verify_lock(root)
    generate(root,root/"config/study.json")
    cases=sorted((root/"runtime/scenarios").glob("*.json"))
    if a.limit:
        # FIX: alphabetical truncation yielded an all-benign pilot. Sample proportionally
        # across families so a pilot contains every attack family plus controls.
        import collections
        byfam=collections.OrderedDict()
        for c in cases: byfam.setdefault(c.stem[0],[]).append(c)
        picked=[]; i=0
        while len(picked)<a.limit and any(byfam.values()):
            for fam in list(byfam):
                if byfam[fam] and len(picked)<a.limit: picked.append(byfam[fam].pop(0))
            i+=1
            if i>a.limit: break
        cases=sorted(picked)
        print(f"Pilot subset: {len(cases)} cases across families "
              f"{sorted(set(c.stem[0] for c in cases))}")
    can=root/"runtime/canonical"; gtroot=root/"runtime/ground_truth_private"
    if a.overwrite:
        # FIX: previously only canonical/ and ground_truth_private/ were cleared, so a
        # superseded run's investigator packages survived and could be shipped by mistake.
        for d in ("runtime/canonical","runtime/ground_truth_private",
                  "runtime/investigator_release","runtime/study_team_private",
                  "runtime/local_sink"):
            shutil.rmtree(root/d,ignore_errors=True)
    can.mkdir(parents=True,exist_ok=True); gtroot.mkdir(parents=True,exist_ok=True)
    adapter=adapter_from_args(a)
    for cp in cases:
        case=load_json(cp); ev,gt=run_case(case,cfg,adapter)
        dump_jsonl(can/f"{case['case_id']}.jsonl",ev)
        dump_json(gtroot/f"{case['case_id']}.json",gt)
    # assignment from corrected analysis package
    amap=root/"analysis_package/out/design_assignment.csv"
    if not amap.exists(): raise SystemExit("Missing powered assignment; run analysis_package/code/design.py")
    mapping=[]; opaque={}
    with open(amap,newline="",encoding="utf-8") as f:
        rows=list(csv.DictReader(f))
    valid={p.stem for p in cases}
    rows=[r for r in rows if r["case_id"] in valid]
    for r in rows:
        key=(r["investigator"],r["case_id"])
        tok=stable_id("CASE",cfg["study_id"],r["investigator"],r["case_id"])[:21]
        opaque[key]=tok
        events=[json.loads(x) for x in (can/f"{r['case_id']}.jsonl").read_text().splitlines()]
        pe=project(events,r["profile"])
        idir=root/"runtime/investigator_release"/r["investigator"]/tok
        idir.mkdir(parents=True,exist_ok=True)
        dump_jsonl(idir/"events.jsonl",pe)
        man={"opaque_case_token":tok,"package_format_version":"1.0","evidence_files":["events.jsonl"]}
        dump_json(idir/"case_manifest.json",man)
        (idir/"README.txt").write_text(
            "Blinded MFLP evidence package. Work only from files in this directory.\n"
            "Do not infer missing telemetry. Cite event IDs in the workbook.\n", encoding="utf-8")
        hashes={"events.jsonl":file_sha(idir/"events.jsonl"),"case_manifest.json":file_sha(idir/"case_manifest.json"),"README.txt":file_sha(idir/"README.txt")}
        (idir/"package_hashes.txt").write_text("\n".join(f"{v}  {k}" for k,v in hashes.items())+"\n")
        mapping.append({"investigator":r["investigator"],"case_id":r["case_id"],"profile":r["profile"],"order":r["order"],"opaque_case_token":tok})
    # team-only map
    team=root/"runtime/study_team_private"; team.mkdir(parents=True,exist_ok=True)
    with open(team/"assignment_opaque_map.csv","w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(mapping[0].keys()) if mapping else ["investigator","case_id","profile","order","opaque_case_token"])
        w.writeheader(); w.writerows(mapping)
    # investigator workbooks
    headers=["opaque_case_token","incident_class","injection_channel","injection_object_id","ordered_event_ids","tool_action","affected_resource_ids","external_effect","confidence_0_100","supporting_event_ids","start_time_utc","submit_time_utc"]
    for inv in sorted({r["investigator"] for r in mapping}):
        invdir=root/"runtime/investigator_release"/inv
        shutil.copy2(root/"analysis_package/investigator_kit/instructions.md", invdir/"INSTRUCTIONS.md")
        rr=sorted([r for r in mapping if r["investigator"]==inv],key=lambda x:int(x["order"]))
        p=root/"runtime/investigator_release"/inv/"workbook.csv"
        with open(p,"w",newline="",encoding="utf-8") as f:
            w=csv.DictWriter(f,fieldnames=headers); w.writeheader()
            for r in rr: w.writerow({"opaque_case_token":r["opaque_case_token"]})
    print(f"Generated {len(cases)} canonical incidents and {len(mapping)} blinded assigned packages using adapter={a.adapter}.")
    print("Canonical traces:",can)
    print("Ground truth (study team only):",gtroot)
    print("Investigator release:",root/"runtime/investigator_release")
if __name__=="__main__": main()
