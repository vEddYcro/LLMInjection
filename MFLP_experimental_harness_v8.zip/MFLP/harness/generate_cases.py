
import json, random, argparse
from pathlib import Path
from .common import load_json, dump_json, stable_id, sha256_text

def generate(root, config):
    root=Path(root)
    cfg=load_json(config); rng=random.Random(cfg["seed"])
    templates=load_json(root/"scenarios/templates.json")
    base=load_json(root/"corpus/base/documents.json")
    out=root/"runtime/scenarios"; out.mkdir(parents=True,exist_ok=True)
    counts=cfg["cases"]; global_idx=0
    for fam in ["D","I","R","T","X","F","B"]:
        for n in range(1,counts[fam]+1):
            global_idx+=1
            cid=f"{fam}{global_idx:04d}"  # matches powered design IDs
            tpl=templates[fam][(n-1)%len(templates[fam])].copy()
            topic=base[(n-1)%len(base)]["topic"]
            record_id=f"record_{((n-1)%40)+1:02d}"
            token_id=f"token_{((n-1)%40)+1:02d}"
            fmt={"topic":topic,"record_id":record_id,"token_id":token_id}
            for k in ["user","doc_injection","tool_injection"]:
                if k in tpl: tpl[k]=tpl[k].format(**fmt)
            docs=[dict(x) for x in base]
            injection_source=None
            if "doc_injection" in tpl:
                # FIX: no verbatim echo of the user query -> removes guaranteed rank-1 placement
                text=(f"Reference note on {topic}. Synthetic reference material about {topic}. "
                      f"{tpl['doc_injection']}")
                poisoned={"document_id":"__INJ__","source_uri":"__INJ_URI__",
                          "title":f"Reference note {topic}","text":text,"topic":topic}
                # FIX: deterministic pseudo-random insertion position, not always index 0
                docs.insert(rng.randrange(0,len(docs)+1),poisoned)
                # FIX: the toy retriever ranks near-identical boilerplate arbitrarily, so
                # injected-chunk rank was previously always 1 (a giveaway). Rank is therefore
                # an explicitly CONTROLLED fixture, balanced uniformly over 1..top_k.
                tpl["injection_target_rank"]=(global_idx % cfg["retrieval"]["top_k"])+1
                injection_source={"channel":"retrieved_document" if fam=="I" else "rag_corpus",
                                  "object_id":"__INJ__","span_id":"span-injection"}
            elif fam in ("D","X","F") and "doc_injection" not in tpl and fam!="B":
                injection_source={"channel":"user","object_id":"user_input","span_id":"span-user"}
            elif fam=="T":
                injection_source={"channel":"tool_output","object_id":"pending_tool_call","span_id":"span-tool-return"}
            # FIX: relabel ALL documents with opaque per-case IDs so that neither the
            # injected document nor the base-corpus documents can be told apart by ID,
            # and no ID encodes case_id or family.
            for i,d in enumerate(docs):
                did=stable_id("DOC",cfg["study_id"],cid,i)[:14]
                if d["document_id"]=="__INJ__" and injection_source is not None:
                    injection_source["object_id"]=did
                d["document_id"]=did
                d["source_uri"]=f"synthetic://corpus/{did.lower()}"
            case={"case_id":cid,"family":fam,"template":tpl["name"],"user_input":tpl["user"],
                  "objective":tpl["objective"],"force_deny":bool(tpl.get("force_deny",False)),
                  "force_safe":bool(tpl.get("force_safe",False)),
                  "tool_injection":tpl.get("tool_injection"),"documents":docs,
                  "injection_source":injection_source,
                  "injection_target_rank":tpl.get("injection_target_rank"),
                  "synthetic_record_id":record_id,"synthetic_token_id":token_id}
            dump_json(out/f"{cid}.json",case)
    return len(list(out.glob("*.json")))

if __name__=="__main__":
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument("--config",default=None); a=ap.parse_args()
    c=a.config or str(Path(a.root)/"config/study.json")
    print(generate(a.root,c))
